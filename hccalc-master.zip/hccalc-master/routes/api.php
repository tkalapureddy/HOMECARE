<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Estimate;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:web');

// Get calculator version
Route::get('/calculator/version', function () {
    return "1.1";
})->middleware('auth:api');

// Get template
Route::get('/calculator/template', function () {
    return Estimate::where(['id' => 1]);
})->middleware('auth:api');
