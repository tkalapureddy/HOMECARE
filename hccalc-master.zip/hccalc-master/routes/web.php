<?php

use Illuminate\Support\Facades\Route;
use App\Models\ChangeLog;

use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ReportsController;
use App\Http\Controllers\EstimateController;
use App\Http\Controllers\PDFController;
use App\Http\Controllers\PDFDownloadController;
use App\Http\Controllers\CalculatorController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Registration ON
// Auth::routes();
// Registration OFF
// Auth::routes(['register' => false, 'reset' => false, 'verify' => false]);
// Login Routes... (they all go to SAML in some way - it could be done better than this)
Route::get('login', ['as' => 'login', 'uses' => 'App\Http\Controllers\Auth\LoginController@showLoginForm'])->middleware('auth');
Route::post('login', ['as' => 'login.post', 'uses' => 'App\Http\Controllers\Auth\LoginController@login']);
Route::post('logout', ['as' => 'logout', 'uses' => 'App\Http\Controllers\Auth\LoginController@logout']);

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('about', [AboutController::class, 'index'])->middleware('auth')->name('about');
Route::get('reports', [ReportsController::class, 'index'])->middleware('auth')->name('reports');

// Calculator special api group
Route::group([
    'guard' => 'web',
    'prefix' => '/calculator/api/',
    'middleware' => ['bindings', 'auth']
], function() {

    // Get calculator version
    Route::get('version', function () {
        $changelog = ChangeLog::select('version')->orderBy('id', 'desc')->first();
        $response = array('version' => $changelog->version);
        return response()->json($response);
    });

    // Get all users
    Route::get('all-users', [UserController::class, 'userList']);

    // Get current user permissions
    Route::get('my-permissions', [UserController::class, 'myPermissions']);

    // Get template
    Route::get('template', [EstimateController::class, 'getTemplate']);

    // Save template
    Route::post('template', [EstimateController::class, 'saveTemplate']);

    // Estimates
    Route::post('budgets', [EstimateController::class, 'budgetList']);

    // Load estimate
    Route::get('load-estimate/{estimate}', [EstimateController::class, 'show'])->where('estimate', '[0-9]+');

    // Save estimate
    Route::post('save-estimate', [EstimateController::class, 'store']);

    // PDF save and export
    Route::post('save-pdf', [PDFController::class, 'index'])->where('estimate', '[0-9]+');

});

// Calculator pages
Route::get('calculator/{path?}', [
    'uses' => 'App\Http\Controllers\CalculatorController@path',
    'as' => 'react',
    'where' => ['path' => '.*'],
    'middleware' => 'auth'
]);

// Protected pdf storage
Route::get('pdf/{filename}', [PDFDownloadController::class, 'checkUser'])->middleware('auth');
