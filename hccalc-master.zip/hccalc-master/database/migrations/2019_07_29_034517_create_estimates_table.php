<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEstimatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('estimates', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->tinyInteger('entry_type'); // 1 = Template, 2 = Estimate
            $table->unsignedInteger('estimate_number'); // 0 for template
            $table->unsignedInteger('revision'); // First version is 0, and 0 for template
            $table->unsignedInteger('user_id');
            $table->string('app_version');
            $table->unsignedInteger('template_id');
            $table->json('client');
            $table->json('plan');
            $table->json('services');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('estimates');
    }
}
