<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('username')->unique(); // DOESN'T HAVE A DEFAULT VALUE ERROR
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->boolean('homecarecalc'); // ADD NULLABLE
            $table->boolean('contentcalc');
            $table->boolean('calcadmin');
            $table->boolean('calcsuperadmin');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
