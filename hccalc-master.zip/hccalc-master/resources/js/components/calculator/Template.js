import React, { Component } from 'react';
import FullPageModal from './FullPageModal';
import { sendPageView } from './inc/Helpers';

export default class Template extends Component {

    constructor(props) {
        super(props);
        this.state = {
            clientTemplate: null,
            templateIdLatest: 0,
            saving: false,
            showSaved: false
        };
    }

    componentDidMount() {
        // Send a page view if necessary
        sendPageView(this.props.firstLoad, 'Template');
        this.props.updateFirstLoad();
        this.calcAPI('template')
    }

    calcAPI(item, method = 'GET', sendData = false) {
        const t = this;
        let token = document.head.querySelector("[name='csrf-token'][content]").content;
        const fetchData = {
            method: 'GET',
            withCredentials: true,
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': token
            }
        }
        if(method == 'POST') {
            fetchData.method = 'POST';
            fetchData.headers["Content-Type"] = "application/json";
            fetchData.headers["Accept"] = "application/json, text-plain, */*";
            fetchData.headers["X-Requested-With"] = "XMLHttpRequest";
            fetchData.credentials = "same-origin";
            fetchData.body = JSON.stringify(sendData);
        }
        fetch('/calculator/api/' + item, fetchData)
        .then(response => response.json())
        .then(data => {
            switch(item) {
                case 'template':
                    if(method === 'GET') {
                        t.setState({
                            clientTemplate: JSON.parse(data.clientDetails),
                            templateIdLatest: data.id
                        });
                    }
                    if(method === 'POST') {
                        t.setState({
                            templateIdLatest: data.templateId,
                            saving: false,
                            showSaved: true
                        });
                    }
                    break;
                }
        });
    }

    updateItem = (e) => {
        let ctString = JSON.stringify(this.state.clientTemplate);
        const ct = JSON.parse(ctString);
        const val = e.target.value;
        switch (e.target.id) {
            case 'hcpSubsidyLevel1Weekly':
                ct.level1Weekly = parseFloat(val);
                break;
            case 'hcpSubsidyLevel2Weekly':
                ct.level2Weekly = parseFloat(val);
                break;
            case 'hcpSubsidyLevel3Weekly':
                ct.level3Weekly = parseFloat(val);
                break;
            case 'hcpSubsidyLevel4Weekly':
                ct.level4Weekly = parseFloat(val);
                break;
            case 'pkgMgtDailyL1':
                ct.packageManagementDaily.level1 = parseFloat(val);
                break;
            case 'pkgMgtDailyL2':
                ct.packageManagementDaily.level2 = parseFloat(val);
                break;
            case 'pkgMgtDailyL3':
                ct.packageManagementDaily.level3 = parseFloat(val);
                break;
            case 'pkgMgtDailyL4':
                ct.packageManagementDaily.level4 = parseFloat(val);
                break;
            case 'careMgtDailyL1':
                ct.careManagementDaily.level1 = parseFloat(val);
                break;
            case 'careMgtDailyL2':
                ct.careManagementDaily.level2 = parseFloat(val);
                break;
            case 'careMgtDailyL3':
                ct.careManagementDaily.level3 = parseFloat(val);
                break;
            case 'careMgtDailyL4':
                ct.careManagementDaily.level4 = parseFloat(val);
                break;
            case 'careMgtSelfDailyL1':
                ct.careManagementDailySelfManaged.level1 = parseFloat(val);
                break;
            case 'careMgtSelfDailyL2':
                ct.careManagementDailySelfManaged.level2 = parseFloat(val);
                break;
            case 'careMgtSelfDailyL3':
                ct.careManagementDailySelfManaged.level3 = parseFloat(val);
                break;
            case 'careMgtSelfDailyL4':
                ct.careManagementDailySelfManaged.level4 = parseFloat(val);
                break;
            case 'basicDailyL1':
                ct.basicDailyFeeDaily.level1 = parseFloat(val);
                break;
            case 'basicDailyL2':
                ct.basicDailyFeeDaily.level2 = parseFloat(val);
                break;
            case 'basicDailyL3':
                ct.basicDailyFeeDaily.level3 = parseFloat(val);
                break;
            case 'basicDailyL4':
                ct.basicDailyFeeDaily.level4 = parseFloat(val);
                break;
            case 'suppDCWeeklyL1':
                ct.supplements.dementiaCognition.level1Weekly = parseFloat(val);
                break;
            case 'suppDCWeeklyL2':
                ct.supplements.dementiaCognition.level2Weekly = parseFloat(val);
                break;
            case 'suppDCWeeklyL3':
                ct.supplements.dementiaCognition.level3Weekly = parseFloat(val);
                break;
            case 'suppDCWeeklyL4':
                ct.supplements.dementiaCognition.level4Weekly = parseFloat(val);
                break;
            case 'suppVetWeeklyL1':
                ct.supplements.veterans.level1Weekly = parseFloat(val);
                break;
            case 'suppVetWeeklyL2':
                ct.supplements.veterans.level2Weekly = parseFloat(val);
                break;
            case 'suppVetWeeklyL3':
                ct.supplements.veterans.level3Weekly = parseFloat(val);
                break;
            case 'suppVetWeeklyL4':
                ct.supplements.veterans.level4Weekly = parseFloat(val);
                break;
            case 'suppOxygenWeekly':
                ct.supplements.oxygen.oxygen = parseFloat(val);
                break;
            case 'suppEnteralBolusWeekly':
                ct.supplements.enteralFeeding.enteralFeedingBolus = parseFloat(val);
                break;
            case 'suppEnteralNonBolusWeekly':
                ct.supplements.enteralFeeding.enteralFeedingNonBolus = parseFloat(val);
                break;
            case 'suppMMM4Weekly':
                ct.supplements.homeCareViability.mmm4 = parseFloat(val);
                break;
            case 'suppMMM5Weekly':
                ct.supplements.homeCareViability.mmm5 = parseFloat(val);
                break;
            case 'suppMMM6Weekly':
                ct.supplements.homeCareViability.mmm6 = parseFloat(val);
                break;
            case 'suppMMM7Weekly':
                ct.supplements.homeCareViability.mmm7 = parseFloat(val);
                break;
        }
        this.setState({
            clientTemplate: ct
        });
    }

    saveTemplate = () => {
        this.setState({
            saving: true,
            showSaved: false
        }, function() {
            this.calcAPI('template', 'POST', {client: this.state.clientTemplate});
        });
    }

    render() {
        return (
            this.state.clientTemplate === null ?
                <FullPageModal />
            :
                <div className="template">
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Template Changes</span>
                        </div>
                    </div>

                    <section className="section">
                        <div className="container">
                            <div className="columns">
                                <div className="column is-one-third">
                                    <h4>Template details</h4>
                                    <div>Currently editing template ID: {this.state.templateIdLatest}</div>
                                </div>
                                <div className="column is-one-third">
                                    <h4>Save new template</h4>
                                    {
                                        this.state.showSaved ?
                                        <button className="button is-success" onClick={this.saveTemplate}>
                                            <span className="icon is-small">
                                                <i className="fa fa-check"></i>
                                            </span>
                                            <span>Saved</span>
                                        </button>
                                        :
                                        <button className={this.state.saving ? "button is-primary is-loading" : "button is-primary"} onClick={this.saveTemplate}>Save</button>
                                    }
                                </div>
                            </div>
                        </div>
                    </section>

                    <section className="section">
                        <div className="container">
                            <div className="columns is-multiline">

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light has-background-light">
                                        <h4>Home Care Package Subsidy</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="hcpSubsidyLevel1Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.level1Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="hcpSubsidyLevel2Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.level2Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="hcpSubsidyLevel3Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.level3Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="hcpSubsidyLevel4Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.level4Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Package Management</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="pkgMgtDailyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.packageManagementDaily.level1} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="pkgMgtDailyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.packageManagementDaily.level2} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="pkgMgtDailyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.packageManagementDaily.level3} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="pkgMgtDailyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.packageManagementDaily.level4} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Care Management</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtDailyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDaily.level1} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtDailyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDaily.level2} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtDailyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDaily.level3} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtDailyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDaily.level4} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Care Management Self Managed</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtSelfDailyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDailySelfManaged.level1} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtSelfDailyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDailySelfManaged.level2} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtSelfDailyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDailySelfManaged.level3} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="careMgtSelfDailyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.careManagementDailySelfManaged.level4} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Basic Daily Fee</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="basicDailyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.basicDailyFeeDaily.level1} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="basicDailyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.basicDailyFeeDaily.level2} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="basicDailyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.basicDailyFeeDaily.level3} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Daily Rate</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="basicDailyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.basicDailyFeeDaily.level4} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Supp: Dementia and Cognition</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppDCWeeklyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.dementiaCognition.level1Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppDCWeeklyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.dementiaCognition.level2Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppDCWeeklyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.dementiaCognition.level3Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppDCWeeklyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.dementiaCognition.level4Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Supp: Veterans</h4>
                                        <div className="field">
                                            <label className="label">Level 1 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppVetWeeklyL1" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.veterans.level1Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 2 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppVetWeeklyL2" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.veterans.level2Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 3 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppVetWeeklyL3" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.veterans.level3Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Level 4 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppVetWeeklyL4" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.veterans.level4Weekly} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Supp: Oxygen</h4>
                                        <div className="field">
                                            <label className="label">Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppOxygenWeekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.oxygen.oxygen} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Supp: Enteral Feeding</h4>
                                        <div className="field">
                                            <label className="label">Bolus, Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppEnteralBolusWeekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.enteralFeeding.enteralFeedingBolus} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">Non-Bolus, Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppEnteralNonBolusWeekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.enteralFeeding.enteralFeedingNonBolus} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="column is-one-third">
                                    <div className="has-padding-10 has-background-light">
                                        <h4>Supp: Home Care Viability</h4>
                                        <div className="field">
                                            <label className="label">MMM4 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppMMM4Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.homeCareViability.mmm4} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">MMM5 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppMMM5Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.homeCareViability.mmm5} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">MMM6 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppMMM6Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.homeCareViability.mmm6} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <label className="label">MMM7 Weekly Rate (daily x 7)</label>
                                            <div className="control has-icons-left">
                                                <input type="text" className="input" id="suppMMM7Weekly" onKeyUp={this.updateItem} defaultValue={this.state.clientTemplate.supplements.homeCareViability.mmm7} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </section>
                    
                    <section className="section is-medium hide-for-print">
                        <div className="container">
                            <p>&nbsp;</p>
                        </div>
                    </section>

                </div>
        );
    }

}