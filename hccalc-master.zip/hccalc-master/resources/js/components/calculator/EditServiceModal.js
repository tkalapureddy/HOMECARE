import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HourSelector from './HourSelector';
import CustomServiceItem from './CustomServiceItem';
import { round, serviceTotalCost, thousands } from './inc/Helpers';

export default class EditServiceModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
            changes: false,
            onOffActive: true,
            flash: 0,
            timeout: false
        };
    }

    subService = (e) => {
        const data = {
            idx: parseInt(e.target.getAttribute('data-index'), 10),
            ste: e.target.checked
        };
        this.props.updateService("subService", data);
        this.setState({
            changes: true
        });
    }

    onOff = (e) => {
        if(this.state.onOffActive) {
            this.props.updateService("onOff", "toggle");
            this.setState({
                changes: false
            });
        }
    }
    
    updateHrs = (data) => {
        this.props.updateService("hrs", data);
        this.setState({
            changes: true
        });
    }

    updateNotes = (e) => {
        this.props.updateService("notes", e.target.value);
        this.setState({
            changes: true
        });
    }

    flash = () => {
        this.state.timeout = setTimeout(() => {
            var btn = document.getElementById("serviceOnOffBtn");
            var btnParent = btn.parentElement;
            btnParent.classList.toggle('has-text-primary');
            btnParent.classList.toggle('has-text-grey');
            btn.classList.toggle('fa-toggle-on');
            if(this.state.flash < 3) {
                this.setState({
                    flash: this.state.flash + 1
                });
                this.flash();
            } else {
                this.setState({
                    onOffActive: true
                });
            }
        }, 130);
    }

    customItem = (data) => {
        this.props.updateService("customServiceItem", data);
    }

    closeModal = () => {
        const c = this.props.serviceModal.category;
        const s = this.props.serviceModal.service;
        if(this.state.changes && !this.props.serviceDetails.category[c].services[s].included) {
            this.setState({
                changes: false,
                onOffActive: false,
                flash: 0
            });
            this.flash();
        } else {
            clearTimeout(this.state.timeout);
            this.props.closeModal();
        }
    }

    render() {
        const c = this.props.serviceModal.category;
        const s = this.props.serviceModal.service;
        const theService = this.props.serviceDetails.category[c].services[s];
        const totalServicePrice = round(serviceTotalCost(theService, this.props.clientDetails), 2, true);
        return (
            <div className="modal is-active edit-service-modal">
                <div className="modal-background"></div>
                <div className="modal-content">
                <header className="modal-card-head">
                    <span className="modal-card-title">{theService.name}</span>
                    <div id="serviceOnOffBtnWrap">
                        <div className="on-off-text">on/off</div>
                        <div className={theService.included ? "icon has-text-primary is-pulled-right is-large" : "icon has-text-grey is-pulled-right is-large"}>
                            <i id="serviceOnOffBtn" className={theService.included ? "fas fa-3x fa-toggle-on" : "fas fa-3x fa-toggle-off"} onClick={this.onOff}></i>
                        </div>
                    </div>
                    <button className="delete is-large has-background-grey" aria-label="close" onClick={this.closeModal}></button>
                </header>
                <section className="modal-card-body">
                    <div className="columns">
                        <div className="column is-one-third">
                            <p>{theService.description.split('\n').map((str, sti) => {
                                return <span key={sti}>{str}<br /></span>
                            })}</p>
                            {
                                theService.serviceSelection.length > 0 && theService.special != 'other' &&
                                    <React.Fragment>
                                        <div className="h5">Select your services</div>
                                        {
                                            theService.serviceSelection.map((svc, i) => 
                                                <div className="field edit-service-modal-checkbox-field" key={i}>
                                                    <div className="control">
                                                        <label className="checkbox edit-service-modal-checkbox">
                                                            <input type="checkbox" data-index={i} onChange={this.subService} defaultChecked={svc.selected} /> {svc.name}
                                                        </label>
                                                    </div>
                                                </div>
                                            )
                                        }
                                    </React.Fragment>
                            }
                        </div>
                        <div className="column is-two-thirds">
                            <div className="columns has-text-right">
                                <div className="column is-half margin-bottom-1">
                                    <span className="h4">{round(theService.totalHrs, 2) == 1 ? round(theService.totalHrs, 2) + " hour" : round(theService.totalHrs, 2) + " hours"}</span><br/>
                                    <span>total per week</span>
                                </div>
                                <div className="column is-half margin-bottom-1">
                                    <span className="h4">${thousands(totalServicePrice)}</span><br/>
                                    <span>total per week</span>
                                </div>
                            </div>
                            {
                                (theService.special == 'alliedHealth' || theService.special == 'spalliedHealth') &&
                                <React.Fragment>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="left"
                                        type="stdFrequency"
                                        showTitle={"6.30am-6.30pm M-F"}
                                    />
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="stdPerVisit"
                                        showTitle={"6.30am-6.30pm M-F"}
                                    />
                                    <div className="is-clearfix"></div>
                                    <div className="field">
                                        <label className="label">Notes</label>
                                        <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                                    </div>
                                </React.Fragment>
                            }
                            {
                                theService.special == 'respiteCentre' &&
                                <React.Fragment>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="stdFrequency"
                                        showTitle="Day"
                                    />
                                    <div className="is-clearfix"></div>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="satAHFrequency"
                                        showTitle="Overnight"
                                    />
                                    <div className="is-clearfix"></div>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="sunFrequency"
                                        showTitle="Overnight Weekend"
                                    />
                                    <div className="is-clearfix"></div>
                                    <div className="field">
                                        <label className="label">Notes</label>
                                        <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                                    </div>
                                </React.Fragment>
                            }
                            {
                                theService.special == 'flatFee' &&
                                <React.Fragment>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="stdFrequency"
                                        showTitle="6.30am-6.30pm M-F"
                                    />
                                    <div className="is-clearfix"></div>
                                    <div className="field">
                                        <label className="label">Notes</label>
                                        <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                                    </div>
                                </React.Fragment>
                            }
                            {
                                theService.special == 'flatFeeMulti' &&
                                <React.Fragment>
                                    {
                                        [...Array(theService.multiNum)].map((x, i) =>
                                            <React.Fragment key={i}>
                                                <HourSelector
                                                    serviceDetails={this.props.serviceDetails}
                                                    serviceModal={this.props.serviceModal}
                                                    updateHrs={(data) => this.updateHrs(data)}
                                                    pos={i%2 == 1 ? "right" : "left"}
                                                    type="flatFrequency"
                                                    idx={i}
                                                    showTitle={theService.selectDescriptors["flat"+i]}
                                                />
                                                {
                                                    i%2 == 1 &&
                                                    <div className="is-clearfix"></div>
                                                }
                                            </React.Fragment>
                                        )
                                    }
                                    <div className="field">
                                        <label className="label">Notes</label>
                                        <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                                    </div>
                                </React.Fragment>
                            }
                            {
                                (!theService.special
                                    || theService.special == "generalNursing"
                                    || theService.special == "complexNursing"
                                    || theService.special == "medicationManagementClinicalNursing"
                                    || theService.special == "dressingGrooming"
                                    || theService.special == "medicationManagement"
                                    || theService.special == "wellnessCheck"
                                    || theService.special == "transport"
                                    || theService.special == "mealsAndNutrition") &&
                                <React.Fragment>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="left"
                                        type="stdFrequency"
                                        showTitle="6.30am-6.30pm M-F"
                                    />
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="stdPerVisit"
                                        showTitle="6.30am-6.30pm M-F"
                                    />
                                    <div className="is-clearfix"></div>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="left"
                                        type="satAHFrequency"
                                        showTitle="Sat or A/H"
                                    />
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="satAHPerVisit"
                                        showTitle="Sat or A/H"
                                    />
                                    <div className="is-clearfix"></div>
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="left"
                                        type="sunFrequency"
                                        showTitle="Sunday"
                                    />
                                    <HourSelector
                                        serviceDetails={this.props.serviceDetails}
                                        serviceModal={this.props.serviceModal}
                                        updateHrs={(data) => this.updateHrs(data)}
                                        pos="right"
                                        type="sunPerVisit"
                                        showTitle="Sunday"
                                    />
                                    <div className="is-clearfix"></div>
                                    <div className="field">
                                        <label className="label">Notes</label>
                                        <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                                    </div>
                                </React.Fragment>
                            }
                        </div>
                    </div>
                    {
                        theService.special == 'other' &&
                        <React.Fragment>
                            <div className="other-list">
                                <div className="other-headers">
                                    <div className="other-headers-name">Item</div>
                                    <div className="other-headers-hours">Hrs/week</div>
                                    <div className="other-headers-amount">Cost/week</div>
                                </div>
                                {
                                    theService.otherItems.length > 0 ?
                                        theService.otherItems.map((item, i) => 
                                            <CustomServiceItem
                                                key={item.key}
                                                csidx={i}
                                                customItem={this.customItem.bind(this)}
                                                item={item}
                                            />
                                        )
                                    :
                                        <CustomServiceItem
                                            key={"abcdefg"}
                                            csidx={0}
                                            customItem={this.customItem.bind(this)}
                                            item={false}
                                        />
                                }
                            </div>
                            <div className="has-text-centered has-cursor-pointer" title="Add item" onClick={() => this.customItem(["addItem"])}>
                                <div className="icon is-medium">
                                    <i className="fa fa-plus" aria-hidden="true"></i>
                                </div>
                                <span>Add another item </span>
                            </div>
                            <div className="field">
                                <label className="label">Notes</label>
                                <textarea className="textarea" placeholder="Any specific details?" onChange={this.updateNotes} defaultValue={theService.notes}></textarea>
                            </div>
                        </React.Fragment>
                    }
                </section>
                <footer className="modal-card-foot">
                    <small>NOTE: Changes are automatically saved</small>
                </footer>
                </div>
            </div>
        )

    }

}
