import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { sendPageView } from './inc/Helpers';
import FullPageModal from './FullPageModal';

export default class StartNew extends Component {

    constructor(props) {
        super(props);
        this.state = {
            timeouts: []
        };
    }

    componentDidMount() {
        // Send a page view if necessary
        sendPageView(this.props.firstLoad, 'Start New');
        this.props.updateFirstLoad();
    }

    resetCalc() {
        window.onbeforeunload = null;
        window.location.href = "/calculator/client";
    }

    render() {
        return (
            this.props.loadingTemplate ?
                <FullPageModal />
            :
                <div className="start-new">
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">New client</span>
                        </div>
                    </div>
                    <section className="section is-medium">
                        <div className="container has-text-centered">
                            <p>This will reset the calculator.</p>
                            <button className="button" onClick={() => {
                                this.resetCalc();
                            }}>Reset &amp; Start New</button>
                        </div>
                    </section>
                </div>
        );
    }
}
