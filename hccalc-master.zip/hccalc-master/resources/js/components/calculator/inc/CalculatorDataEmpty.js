/**
 * Client Details
 */
export const ClientDetailsEmpty = JSON.stringify({
    name: "",
    phone: "",
    address: "",
    contactName: "",
    contactPhone: "",
    contactAddress: "",
    fundingType: "",
    fundingLevel: 1,
    level1Weekly: 171.22,
    level2Weekly: 301.21,
    level3Weekly: 655.41,
    level4Weekly: 993.58,
    contribution: 0,
    incomeTestedFee: 0,
    packageManagementDaily: {
        level1: 2.29,
        level2: 4.93,
        level3: 12.71,
        level4: 20.64
    },
    careManagementFullyManaged: true,
    careManagementDaily: {
        level1: 4.57,
        level2: 6.64,
        level3: 10.93,
        level4: 15.64
    },
    careManagementDailySelfManaged: {
        level1: 0.46,
        level2: 0.67,
        level3: 1.1,
        level4: 1.56
    },
    basicDailyFeePercent: 100,
    basicDailyFeeDaily: {
        level1: 9.63,
        level2: 10.19,
        level3: 10.48,
        level4: 10.75
    },
    supplements: {
        dementiaCognition: {
            level1Weekly: 19.67,
            level2Weekly: 34.65,
            level3Weekly: 75.39,
            level4Weekly: 114.24,
            selected: false
        },
        veterans: {
            level1Weekly: 19.67,
            level2Weekly: 34.65,
            level3Weekly: 75.39,
            level4Weekly: 114.24,
            selected: false
        },
        oxygen: {
            oxygen: 83.86,
            selected: false
        },
        enteralFeeding: {
            enteralFeedingBolus: 132.86,
            enteralFeedingNonBolus: 149.24,
            selected: ""
        },
        homeCareViability: {
            mmm4: 7.56,
            mmm5: 16.73,
            mmm6: 110.88,
            mmm7: 133.07,
            selected: ""
        }
    }
});

/**
 * Services
 */
export const ServiceDetailsEmpty = JSON.stringify({
    category: [
        {
            name: "Personal care",
            key: "cPersonalCare",
            class: "cat-personal-care",
            services: [
                {
                    name: "Dressing & grooming",
                    key: "sDressingGrooming",
                    special: "dressingGrooming",
                    description: "Staying healthy and active can be boosted by maintaining a positive appearance. We can help you shower, shave, style your hair and get dressed. This personal care makes the start to your day both positive and stress free.",
                    serviceSelection: [
                        {
                            name: "Showering",
                            selected: false
                        },
                        {
                            name: "Shaving",
                            selected: false
                        },
                        {
                            name: "Oral hygiene",
                            selected: false
                        },
                        {
                            name: "Dressing and undressing",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    hourlyRatesFunded: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Wellness check",
                    key: "sWellnessCheck",
                    special: "wellnessCheck",
                    description: "A support worker will visit you to check on your health and wellness.",
                    serviceSelection: [
                        {
                            name: "General check",
                            selected: false
                        },
                        {
                            name: "Blood pressure",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    hourlyRatesFunded: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Travel & social",
            key: "cTravelAndSocial",
            class: "cat-travel-social",
            services: [
                {
                    name: "Companionship",
                    key: "sCompanionship",
                    special: false,
                    description: "Staying actively involved in your community is a key way to maintain a sense of well being and independence.  We're here to support you so you can maintain and develop your social connections with friends and family. And if you want some company at an event, we'll be there too.",
                    serviceSelection: [
                        {
                            name: "Develop social connections",
                            selected: false
                        },
                        {
                            name: "Companionship in home",
                            selected: false
                        },
                        {
                            name: "Companionship to attend events and access community",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    minHrs: 1,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Transport",
                    key: "sTransport",
                    special: "transport",
                    description: "Our fully insured, air-conditioned vehicles come with licensed and friendly drivers to get you to and from your location on time and in comfort. They can also help you enter and exit the vehicle, and stay with you all the way to your appointment.",
                    serviceSelection: [
                        {
                            name: "Transport to and from social outings",
                            selected: false
                        },
                        {
                            name: "Transport to and from a respite centre",
                            selected: false
                        },
                        {
                            name: "Transport to and from hospital",
                            selected: false
                        },
                        {
                            name: "Transport to and from medical appointments",
                            selected: false
                        },
                        {
                            name: "Transport to and from hairdresser",
                            selected: false
                        },
                        {
                            name: "Collection of prescriptions from pharmacy",
                            selected: false
                        },
                        {
                            name: "Visiting family and friends",
                            selected: false
                        },
                        {
                            name: "Church visits",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    hourlyRatesFunded: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "General shopping",
                    key: "sGeneralShopping",
                    special: false,
                    description: "Staying on top of your weekly shop is really important. We'll help you select, receive and unpack your groceries, either ordered online or by visiting your local shopping centre with you.",
                    serviceSelection: [
                        {
                            name: "Visit shopping centre",
                            selected: false
                        },
                        {
                            name: "Visit other shops",
                            selected: false
                        },
                        {
                            name: "Visit cafe or restaurant",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    minHrs: 1,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Respite",
            key: "cRespite",
            class: "cat-respite",
            services: [
                {
                    name: "In-home respite",
                    key: "sInHomeRespite",
                    special: false,
                    description: "Our support workers can visit your home so carers can take a break.",
                    serviceSelection: [
                        {
                            name: "In-home respite",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    minHrs: 1,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Breakfast club",
                    key: "sBreakfastClub",
                    special: "flatFee",
                    description: "Only available at Bran Nue Dae respite centre in Broome",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 2,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 80
                    },
                    hourlyRatesFunded: {
                        flat: 80
                    },
                    totalHrs: 2,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Respite Centre",
                    key: "sRespiteCentre",
                    special: "respiteCentre",
                    description: "Our respite centres offer clients a 'home away from home' with plenty of activities designed to suit your interests, helps you make friends and stay connected, whilst overseen by trained carers.\n\n- Day respite 9am-3pm Monday to Friday.\n- Overnight respite (24 hours) Monday to Friday.\n- Overnight weekend respite (24 hours) Saturday and Sunday.",
                    serviceSelection: [
                        {
                            name: "Donovan House Forrestfield",
                            selected: false
                        },
                        {
                            name: "Tony Quinlan Respite Centre Hilton",
                            selected: false
                        },
                        {
                            name: "Bran Nue Dae Broome",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 0,
                    stdVisitFrequency: "month",
                    stdHrsPerVisit: 6,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "month",
                    satAHHrsPerVisit: 24,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "month",
                    sunHrsPerVisit: 24,
                    hourlyRatesPrivate: {
                        mToF9To3: 150,
                        mToF24hrs: 250,
                        satSun24hrs: 300
                    },
                    hourlyRatesFunded: {
                        mToF9To3: 125,
                        mToF24hrs: 200,
                        satSun24hrs: 250
                    },
                    totalHrs: 0,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Domestic assistance",
            key: "cDomesticAssistance",
            class: "cat-domestic-assistance",
            services: [
                {
                    name: "Cleaning & tidying",
                    key: "sCleaningTidying",
                    special: false,
                    description: "Maintaining your home can give you a real sense of pride in the place you love best. Receiving a little help from a team of carers you know and trust can help you keep on top of your jobs at home. Our support workers assist with cleaning and tidying.",
                    serviceSelection: [
                        {
                            name: "Cleaning kitchen and bathroom",
                            selected: false
                        },
                        {
                            name: "General house tidy up",
                            selected: false
                        },
                        {
                            name: "Making beds",
                            selected: false
                        },
                        {
                            name: "Linen change",
                            selected: false
                        },
                        {
                            name: "Dusting",
                            selected: false
                        },
                        {
                            name: "Vacuuming",
                            selected: false
                        },
                        {
                            name: "Mopping",
                            selected: false
                        },
                        {
                            name: "Washing and ironing",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    minHrs: 1,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Meals and nutrition",
                    key: "sMealsAndNutrition",
                    special: "mealsAndNutrition",
                    description: "We can provide a range of healthy and nutritional home-cooked meal preparation services to suit your lifestyle - from keeping your freezer or pantry stocked, to ensuring you buy the most nutritious and tasty products. We'll even give you a hand putting your favourite meals together.",
                    serviceSelection: [
                        {
                            name: "Meal preparation",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    hourlyRatesFunded: {
                        stdMins60: 69,
                        stdMins30: 78,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        sunMins60: 99,
                        sunMins30: 112
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Light gardening",
                    key: "sLightGardening",
                    special: false,
                    description: "We know that your garden is often your pride and joy, but it can be a little overwhelming too. We'll work alongside you to ensure it stays tidy and continues to grow and thrive!",
                    serviceSelection: [
                        {
                            name: "Mowing",
                            selected: false
                        },
                        {
                            name: "Raking",
                            selected: false
                        },
                        {
                            name: "Watering",
                            selected: false
                        },
                        {
                            name: "Sweeping",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    minHrs: 1,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Health & wellness (in-home)",
            key: "cHealthAndWellness",
            class: "cat-health-wellness",
            services: [
                {
                    name: "Medication management",
                    key: "sMedicationManagement",
                    special: "medicationManagement",
                    description: "Our care team can support you in the privacy of your own home to ensure you take your medications in line with your Doctor’s prescription directions.",
                    serviceSelection: [
                        {
                            name: "Support to manage your medication",
                            selected: false
                        },
                        {
                            name: "Medication prompts",
                            selected: false
                        },
                        {
                            name: "Administer medication",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins60: 69,
                        stdMins30: 78,
                        stdMins15: 116,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        satAHMins15: 156,
                        sunMins60: 99,
                        sunMins30: 112,
                        sunMins15: 196
                    },
                    hourlyRatesFunded: {
                        stdMins60: 69,
                        stdMins30: 78,
                        stdMins15: 116,
                        satAHMins60: 79,
                        satAHMins30: 90,
                        satAHMins15: 156,
                        sunMins60: 99,
                        sunMins30: 112,
                        sunMins15: 196
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Allied Health",
                    key: "sAlliedHealth",
                    special: "alliedHealth",
                    description: "Occupational Therapy to assist improving Activities of Daily Living.\n\nPhysiotherapy for pain management.\n\nExercise Physiology for an exercise prescription to manage health.",
                    serviceSelection: [
                        {
                            name: "Occupational therapy",
                            selected: false
                        },
                        {
                            name: "Exercise Physiology",
                            selected: false
                        },
                        {
                            name: "Physiotherapy",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        mins45: 119,
                        mins60: 159
                    },
                    hourlyRatesFunded: {
                        mins45: 119,
                        mins60: 159
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Therapy assistant",
                    key: "sTherapyAssistantIH",
                    special: "flatFee",
                    description: "To facilitate participation in a rehabilitation program following surgery or injury, or help you achieve general improvements in fitness and balance.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 0.75,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 60
                    },
                    hourlyRatesFunded: {
                        flat: 60
                    },
                    totalHrs: 0.75,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Clinical/nursing",
            key: "cClinicalNursing",
            class: "cat-clinical-nursing",
            services: [
                {
                    name: "General nursing",
                    key: "sGeneralNursing",
                    special: "generalNursing",
                    description: "A general nursing service includes both urgent and planned services, such as medication administration, vital sign checks, some wound care and continence support. It can be provided by both Enrolled and Registered Nurses.",
                    serviceSelection: [
                        {
                            name: "Enrolled and Registered Nurses",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins30: 138,
                        stdMins60: 99,
                        satAHMins30: 178,
                        satAHMins60: 129,
                        sunMins30: 218,
                        sunMins60: 149
                    },
                    hourlyRatesFunded: {
                        stdMins30: 138,
                        stdMins60: 99,
                        satAHMins30: 178,
                        satAHMins60: 129,
                        sunMins30: 218,
                        sunMins60: 149
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Complex nursing",
                    key: "sComplexNursing",
                    special: "complexNursing",
                    description: "Complex nursing can be provided by both Registered and Enrolled Nurses and includes review of a new health change, injury or illness, care coordination, liaison with acute services, outpatient, GP services, medication administration such as infusions or schedule 8 medications, specialised assessments and plans.",
                    serviceSelection: [
                        {
                            name: "Registered nurses and Enrolled Nurses",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins30: 178,
                        stdMins60: 129,
                        satAHMins30: 198,
                        satAHMins60: 139,
                        sunMins30: 238,
                        sunMins60: 159
                    },
                    hourlyRatesFunded: {
                        stdMins30: 178,
                        stdMins60: 129,
                        satAHMins30: 198,
                        satAHMins60: 139,
                        sunMins30: 238,
                        sunMins60: 159
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Nurse practitioner - Clinic visit & telehealth",
                    key: "sNurseClinicTelehealth",
                    special: "flatFeeMulti",
                    description: "Our nurse practitioner can see you via Telehealth or at our Health and Wellness Clinic in East Fremantle. We can assist with prescribing medications; diagnosing and treating a range of health conditions, including chronic diseases and referring to specialists.",
                    serviceSelection: [
                        {
                            name: "Clinic visit",
                            selected: false
                        },
                        {
                            name: "Telehealth",
                            selected: false
                        }
                    ],
                    multiNum: 4,
                    type0QtyVisits: 0,
                    type0VisitFrequency: "week",
                    type0HrsPerVisit: 0.08,
                    type1QtyVisits: 0,
                    type1VisitFrequency: "week",
                    type1HrsPerVisit: 0.25,
                    type2QtyVisits: 0,
                    type2VisitFrequency: "week",
                    type2HrsPerVisit: 0.5,
                    type3QtyVisits: 0,
                    type3VisitFrequency: "week",
                    type3HrsPerVisit: 0.67,
                    hourlyRatesPrivate: {
                        flat0: 25,
                        flat1: 69,
                        flat2: 90,
                        flat3: 110
                    },
                    hourlyRatesFunded: {
                        flat0: 25,
                        flat1: 69,
                        flat2: 90,
                        flat3: 110
                    },
                    selectDescriptors: {
                        flat0: "Short uncomplicated",
                        flat1: "Short complicated",
                        flat2: "Long",
                        flat3: "Extended"
                    },
                    totalHrs: 0,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Nurse practitioner (in-home)",
                    key: "sNursePractitionerInHome",
                    special: "flatFee",
                    description: "We support nursing advice and services such as wound care, medication, chronic condition management such as diabetes, continence and ensure we help you with education to become as healthy as possible. This is particularly important following a stay in hospital, managing and adjusting medications and supporting your recovery following serious injury or managing a wound. Our nurses will visit you at home saving you time travelling to appointments.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 179
                    },
                    hourlyRatesFunded: {
                        flat: 179
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Medication management",
                    key: "sMedicationManagementClinicalNursing",
                    special: "medicationManagementClinicalNursing",
                    description: "Our nurses can support you in the privacy of your own home to ensure you take your medications in line with your Doctor’s prescription directions.",
                    serviceSelection: [
                        {
                            name: "Support to manage your medication",
                            selected: false
                        },
                        {
                            name: "Medication prompts",
                            selected: false
                        },
                        {
                            name: "Administer medication",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        stdMins30: 138,
                        stdMins60: 99,
                        satAHMins30: 178,
                        satAHMins60: 129,
                        sunMins30: 218,
                        sunMins60: 149
                    },
                    hourlyRatesFunded: {
                        stdMins30: 138,
                        stdMins60: 99,
                        satAHMins30: 178,
                        satAHMins60: 129,
                        sunMins30: 218,
                        sunMins60: 149
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Southern Plus Health & Wellness Centre",
            key: "cSPHealthAndWellnessCentre",
            class: "cat-sp-health-wellness-centre",
            services: [
                {
                    name: "Allied health practitioner",
                    key: "sSPAlliedHealth",
                    special: "spalliedHealth",
                    description: "Stay well and achieve your goals as our qualified allied health practitioners work with you to restore, recover and rehabilitate.  Through treatment such as exercise, massage, hands on therapy and education, your allied health practitioner will help you achieve your health goals.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 0.75,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        mins30: 60,
                        mins45: 85
                    },
                    hourlyRatesFunded: {
                        mins30: 60,
                        mins45: 85
                    },
                    totalHrs: 0.75,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Therapy assistant",
                    key: "sTherapyAssistantHW",
                    special: "flatFee",
                    description: "To facilitate participation in a rehabilitation program following surgery or injury, or help you achieve general improvements in fitness and balance.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 0.75,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 60
                    },
                    hourlyRatesFunded: {
                        flat: 60
                    },
                    totalHrs: 0.75,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Living Longer Living Stronger T1",
                    key: "sLivingLongerT1",
                    special: "flatFee",
                    description: "The program is endorsed by the Centre of the Aged (COTA) and is an evidence based progressive strength training and exercise program designed specifically for the over 50's managing complex health conditions. Delivered by Allied Health staff.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 15
                    },
                    hourlyRatesFunded: {
                        flat: 15
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Living Longer Living Stronger T2",
                    key: "sLivingLongerT2",
                    special: "flatFee",
                    description: "The program is endorsed by the Centre of the Aged (COTA) and is an evidence based progressive strength training and exercise program designed specifically for the over 50'’'s managing complex health conditions. Delivered by accredited Exercise Instructors.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 10
                    },
                    hourlyRatesFunded: {
                        flat: 10
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Staying Strong",
                    key: "sStayingStrong",
                    special: "flatFee",
                    description: "This is a group based class dedicated for people with complex health conditions and care needs which require a targeted program with a higher degree of support and supervision. This class will help to increase your confidence as well as maintain your independence for your daily activities.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 20
                    },
                    hourlyRatesFunded: {
                        flat: 20
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Group Exercise",
                    key: "sGroupExercise",
                    special: "flatFee",
                    description: "AquaFit: AquaFit is a fun, low impact class designed for seniors.\n\nAquabalance: Aquatic exercise with an emphasis on improving balance and mindfulness.\n\nFunctional Fit: Land-based class focuses on all elements of fitness: Cardiovascular, muscle conditioning, flexibility and balance.\n\nTai Chi: controlled movement exercise for mindfulness and to stay mobile.",
                    serviceSelection: [
                        {
                            name: "Aqua Fit",
                            selected: false
                        },
                        {
                            name: "Aqua Balance",
                            selected: false
                        },
                        {
                            name: "Tai Chi",
                            selected: false
                        },
                        {
                            name: "Functional Fit",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 15
                    },
                    hourlyRatesFunded: {
                        flat: 15
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Aquatic hydrotherapy",
                    key: "sAquaticHydrotherapy",
                    special: "flatFee",
                    description: "Physiotherapy-led service to support evidence based rehabilitation in a heated indoor hydrotherapy pool.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 25
                    },
                    hourlyRatesFunded: {
                        flat: 25
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                },
                {
                    name: "Arthritis WA Joint Movement",
                    key: "sArthritisWAJointMovement",
                    special: "flatFee",
                    description: "The Joint Movement® is a group-based exercise program designed for people with arthritis and other chronic musculoskeletal conditions who are aged 65 years and over. The 12-week program is available as either a land-based or warm water program and is suitable for people of all levels of fitness, including beginners.",
                    serviceSelection: [],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 0,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 0,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        flat: 10
                    },
                    hourlyRatesFunded: {
                        flat: 10
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Other Products & Services",
            key: "cOther",
            class: "cat-other",
            services: [
                {
                    name: "Other Products & Services",
                    key: "sOtherProductsServices",
                    special: "other",
                    description: "Any other products or services, for example: Long check – Telehealth Nurse Practitioner; Quick check – Telehealth Nurse Practitioner; consumables; subscriptions; devices; etc.",
                    serviceSelection: [],
                    otherItems: [
                        {
                            title: "",
                            hours: 0,
                            amount: 0,
                            key: "firstEntry"
                        }
                    ],
                    totalHrs: 0,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        },
        {
            name: "Planning & management",
            key: "cPlanningAndManagement",
            special: false,
            class: "cat-planning-management",
            services: [
                {
                    name: "Care management",
                    key: "sCareManagement",
                    special: false,
                    description: "We can provide support and advice for ongoing conditions such as osteoarthritis, diabetes and heart and lung conditions. We also offer a coordinated service where we will work with you and your GP to develop a plan which supports you to gain the most from all our services and maximise your health. In end of life care planning, financial choices and decisions often need family discussion. We also help with facilitating family meetings and helping you book sessions with financial planners or pastoral care.",
                    serviceSelection: [
                        {
                            name: "Care management",
                            selected: false
                        }
                    ],
                    stdQtyVisits: 1,
                    stdVisitFrequency: "week",
                    stdHrsPerVisit: 1,
                    satAHQtyVisits: 1,
                    satAHVisitFrequency: "week",
                    satAHHrsPerVisit: 0,
                    sunQtyVisits: 1,
                    sunVisitFrequency: "week",
                    sunHrsPerVisit: 0,
                    hourlyRatesPrivate: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    hourlyRatesFunded: {
                        std: 69,
                        satAH: 79,
                        sun: 99
                    },
                    totalHrs: 1,
                    gst: false,
                    notes: "",
                    included: false
                }
            ]
        }
    ]
});