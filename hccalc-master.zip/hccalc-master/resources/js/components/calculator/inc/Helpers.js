/* Compare version numbers incase a page refresh is required
export function compareVersions(v1, v2) {
    if (typeof v1 !== 'string') return false;
    if (typeof v2 !== 'string') return false;
    v1 = v1.split('.');
    v2 = v2.split('.');
    const k = Math.min(v1.length, v2.length);
    for (let i = 0; i < k; ++ i) {
        v1[i] = parseInt(v1[i], 10);
        v2[i] = parseInt(v2[i], 10);
        if (v1[i] > v2[i]) return 1;
        if (v1[i] < v2[i]) return -1;        
    }
    return v1.length == v2.length ? 0 : (v1.length < v2.length ? -1 : 1);
}
*/

// For rounding value to x decimal places in a more accurate way
export function round(value, decimals, fixed = false) {
    let val = Number(Math.round(value+'e'+decimals)+'e-'+decimals);
    if(fixed) {
        return val.toFixed(2);
    } else {
        return val;
    }
}

// Frequency offset
export function frequencyOffset(f) {
    let freqFix;
    switch (f) {
        case "week":
            freqFix = 1;
            break;
        case "ftn":
            freqFix = 0.5;
            break;
        case "month":
            freqFix = 12 / (365 / 7);
    }
    return freqFix;
}

// Get total price for service
export function serviceTotalCost(service, cd, separated = false) {

    if(service.special == "alliedHealth") {

        let stdOffsetVisits = service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency);
        let stdHrs = service.stdHrsPerVisit * stdOffsetVisits;
        let mins = service.stdHrsPerVisit == 1 ? "mins60" : "mins45";
        let stdRate = cd.fundingType == "funded" ? service.hourlyRatesFunded[mins] : service.hourlyRatesPrivate[mins];
        let stdCost = stdRate * (service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency));

        if(separated) {
            return [stdHrs, stdCost];
        } else {
            return stdCost;
        }

    } else if(service.special == "spalliedHealth") {

        let stdOffsetVisits = service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency);
        let stdHrs = service.stdHrsPerVisit * stdOffsetVisits;
        let mins = service.stdHrsPerVisit == 0.50 ? "mins30" : "mins45";
        let stdRate = cd.fundingType == "funded" ? service.hourlyRatesFunded[mins] : service.hourlyRatesPrivate[mins];
        let stdCost = stdRate * (service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency));

        if(separated) {
            return [stdHrs, stdCost];
        } else {
            return stdCost;
        }

    } else if(service.special == "respiteCentre") {

        let stdOffsetVisits = service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency);
        let stdHrs = service.stdHrsPerVisit * stdOffsetVisits;
        let stdCost = cd.fundingType == "funded" ? stdOffsetVisits * service.hourlyRatesFunded.mToF9To3 : stdOffsetVisits * service.hourlyRatesPrivate.mToF9To3;

        let satAHOffsetVisits = service.satAHQtyVisits * frequencyOffset(service.satAHVisitFrequency);
        let satAHHrs = service.satAHHrsPerVisit * satAHOffsetVisits;
        let satAHCost = cd.fundingType == "funded" ? satAHOffsetVisits * service.hourlyRatesFunded.mToF24hrs : satAHOffsetVisits * service.hourlyRatesPrivate.mToF24hrs;

        let sunOffsetVisits = service.sunQtyVisits * frequencyOffset(service.sunVisitFrequency);
        let sunHrs = service.sunHrsPerVisit * sunOffsetVisits;
        let sunCost = cd.fundingType == "funded" ? sunOffsetVisits * service.hourlyRatesFunded.satSun24hrs : sunOffsetVisits * service.hourlyRatesPrivate.satSun24hrs;

        if(separated) {
            return [stdHrs, stdCost, satAHHrs, satAHCost, sunHrs, sunCost];
        } else {
            return round(stdCost + satAHCost + sunCost, 2);
        }

    } else if(service.special == "flatFee") {

        let stdOffsetVisits = service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency);
        let stdHrs = service.stdHrsPerVisit * stdOffsetVisits;
        let stdCost = cd.fundingType == "funded" ? stdOffsetVisits * service.hourlyRatesFunded.flat : stdOffsetVisits * service.hourlyRatesPrivate.flat;

        let satAHOffsetVisits = service.satAHQtyVisits * frequencyOffset(service.satAHVisitFrequency);
        let satAHHrs = service.satAHHrsPerVisit * satAHOffsetVisits;
        let satAHCost = cd.fundingType == "funded" ? satAHOffsetVisits * service.hourlyRatesFunded.flat : satAHOffsetVisits * service.hourlyRatesPrivate.flat;

        let sunOffsetVisits = service.sunQtyVisits * frequencyOffset(service.sunVisitFrequency);
        let sunHrs = service.sunHrsPerVisit * sunOffsetVisits;
        let sunCost = cd.fundingType == "funded" ? sunOffsetVisits * service.hourlyRatesFunded.flat : sunOffsetVisits * service.hourlyRatesPrivate.flat;

        if(separated) {
            return [stdHrs, stdCost, satAHHrs, satAHCost, sunHrs, sunCost];
        } else {
            return round(stdCost + satAHCost + sunCost, 2);
        }

    } else if (service.special == "generalNursing"
            || service.special == "complexNursing"
            || service.special == "medicationManagementClinicalNursing"
            || service.special == "dressingGrooming"
            || service.special == "medicationManagement"
            || service.special == "wellnessCheck"
            || service.special == "transport"
            || service.special == "mealsAndNutrition") {

        let stdOffsetVisits = service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency);
        let stdHrs = service.stdHrsPerVisit * stdOffsetVisits;
        let stdCost = 0;

        let satAHOffsetVisits = service.satAHQtyVisits * frequencyOffset(service.satAHVisitFrequency);
        let satAHHrs = service.satAHHrsPerVisit * satAHOffsetVisits;
        let satAHCost = 0;

        let sunOffsetVisits = service.sunQtyVisits * frequencyOffset(service.sunVisitFrequency);
        let sunHrs = service.sunHrsPerVisit * sunOffsetVisits;
        let sunCost = 0;

        if (cd.fundingType == "funded") {
            if(service.stdHrsPerVisit == 0.25) {
                stdCost = stdHrs * service.hourlyRatesFunded.stdMins15;
            } else {
                stdCost = service.stdHrsPerVisit == 0.5 ? stdHrs * service.hourlyRatesFunded.stdMins30 : stdHrs * service.hourlyRatesFunded.stdMins60;
            }
            if(service.satAHHrsPerVisit == 0.25) {
                satAHCost = satAHHrs * service.hourlyRatesFunded.satAHMins15;
            } else {
                satAHCost = service.satAHHrsPerVisit == 0.5 ? satAHHrs * service.hourlyRatesFunded.satAHMins30 : satAHHrs * service.hourlyRatesFunded.satAHMins60;
            }
            if(service.sunHrsPerVisit == 0.25) {
                sunCost = sunHrs * service.hourlyRatesFunded.sunMins15;
            } else {
                sunCost = service.sunHrsPerVisit == 0.5 ? sunHrs * service.hourlyRatesFunded.sunMins30 : sunHrs * service.hourlyRatesFunded.sunMins60;
            }
        }

        if (cd.fundingType == "private") {
            if(service.stdHrsPerVisit == 0.25) {
                stdCost = stdHrs * service.hourlyRatesPrivate.stdMins15;
            } else {
                stdCost = service.stdHrsPerVisit == 0.5 ? stdHrs * service.hourlyRatesPrivate.stdMins30 : stdHrs * service.hourlyRatesPrivate.stdMins60;
            }
            if(service.satAHHrsPerVisit == 0.25) {
                satAHCost = satAHHrs * service.hourlyRatesPrivate.satAHMins15;
            } else {
                satAHCost = service.satAHHrsPerVisit == 0.5 ? satAHHrs * service.hourlyRatesPrivate.satAHMins30 : satAHHrs * service.hourlyRatesPrivate.satAHMins60;
            }
            if(service.sunHrsPerVisit == 0.25) {
                sunCost = sunHrs * service.hourlyRatesPrivate.sunMins15;
            } else {
                sunCost = service.sunHrsPerVisit == 0.5 ? sunHrs * service.hourlyRatesPrivate.sunMins30 : sunHrs * service.hourlyRatesPrivate.sunMins60;
            }
        }

        if (separated) {
            return [stdHrs, stdCost, satAHHrs, satAHCost, sunHrs, sunCost];
        } else {
            return round(stdCost + satAHCost + sunCost, 2);
        }

    } else if(service.special == "other") {

        let stdCost = 0;
        let stdHrs = 0;
        service.otherItems.map((item, i) => {
            stdCost = stdCost + item.amount;
            stdHrs = stdHrs + item.hours;
        });

        if(separated) {
            return [stdHrs, stdCost];
        } else {
            return stdCost;
        }

    } else if(service.special == "flatFeeMulti") {

        const hrsAndCosts = {};
        let totalCost = 0;
        
        [...Array(service.multiNum)].map((x, i) => {
            let offsetVisits = service["type"+i+"QtyVisits"] * frequencyOffset(service["type"+i+"VisitFrequency"]);
            hrsAndCosts["type"+i+"Hrs"] = service["type"+i+"HrsPerVisit"] * offsetVisits;
            hrsAndCosts["type"+i+"Cost"] = cd.fundingType == "funded" ? offsetVisits * service.hourlyRatesFunded["flat"+i] : offsetVisits * service.hourlyRatesPrivate["flat"+i];
            totalCost = round(totalCost + hrsAndCosts["type"+i+"Cost"], 2);
        });
        
        if(separated) {
            return hrsAndCosts;
        } else {
            return round(totalCost, 2);
        }

    } else {

        let stdHrs = service.stdHrsPerVisit * (service.stdQtyVisits * frequencyOffset(service.stdVisitFrequency));
        let stdCost = cd.fundingType == "funded" ? stdHrs * service.hourlyRatesFunded.std : stdHrs * service.hourlyRatesPrivate.std;

        let satAHHrs = service.satAHHrsPerVisit * (service.satAHQtyVisits * frequencyOffset(service.satAHVisitFrequency));
        let satAHCost = cd.fundingType == "funded" ? satAHHrs * service.hourlyRatesFunded.satAH : satAHHrs * service.hourlyRatesPrivate.satAH;

        let sunHrs = service.sunHrsPerVisit * (service.sunQtyVisits * frequencyOffset(service.sunVisitFrequency));
        let sunCost = cd.fundingType == "funded" ? sunHrs * service.hourlyRatesFunded.sun : sunHrs * service.hourlyRatesPrivate.sun;

        if(separated) {
            return [stdHrs, stdCost, satAHHrs, satAHCost, sunHrs, sunCost];
        } else {
            return round(stdCost + satAHCost + sunCost, 2);
        }
    }
}

// Get total hours for category
export function categoryTotalHrs(category) {
    let totalHrs = 0;
    category.services.map((service) => {
        if(service.included) {
            totalHrs = round(totalHrs + service.totalHrs, 2);
        }  
    });
    return totalHrs;
}

// Get total funding for funded client
export function getTotalFunding(cd, contributionOnly, fixed = false) {
    let total = 0;
    if(cd.fundingType == "funded") {
        if(!contributionOnly) {
            total += cd["level"+cd.fundingLevel+"Weekly"];
        }
        let supplements = getSupplementsList(cd);
        total += supplements[1];
        total += dailyTo("week", getBasicDailyFee(cd));
        total += dailyTo("week", cd.incomeTestedFee);
    }
    total += cd.contribution;
    if (fixed) {
        total = round(total, 2, true);
    }
    return total;
}

// Get total hours for all services
export function getTotalHrs(sd) {
    // Total hrs from all services
    sd.category.map((cat) => {
        totalHrs += categoryTotalHrs(cat);
    });
    totalHrs = totalHrs;
    return totalHrs;
}

// Get list of supplements
export function getSupplementsList(cd, fixed = false) {
    const supplements = [];
    let amount = 0;
    if (cd.supplements.dementiaCognition.selected) {
        supplements.push("Dementia & Cognition");
        amount = round(amount + cd.supplements.dementiaCognition["level" + cd.fundingLevel + "Weekly"], 2);
    }
    if (cd.supplements.veterans.selected) {
        supplements.push("Veterans'");
        amount = round(amount + cd.supplements.veterans["level" + cd.fundingLevel + "Weekly"], 2);
    }
    if (cd.supplements.oxygen.selected) {
        supplements.push("Oxygen");
        amount = round(amount + cd.supplements.oxygen.oxygen, 2);
    }
    if (cd.supplements.enteralFeeding.selected != "") {
        switch (cd.supplements.enteralFeeding.selected) {
            case "enteralFeedingBolus":
                supplements.push("Enteral Feeding - Bolus");
                amount = round(amount + cd.supplements.enteralFeeding.enteralFeedingBolus, 2);
                break;
            case "enteralFeedingNonBolus":
                supplements.push("Enteral Feeding - Non-Bolus");
                amount = round(amount + cd.supplements.enteralFeeding.enteralFeedingNonBolus, 2);
                break;
        }
    }
    if (cd.supplements.homeCareViability.selected != "") {
        switch (cd.supplements.homeCareViability.selected) {
            case "mmm4":
                supplements.push("Home Care Viability - MMM4");
                amount = round(amount + cd.supplements.homeCareViability.mmm4, 2);
                break;
            case "mmm5":
                supplements.push("Home Care Viability - MMM5");
                amount = round(amount + cd.supplements.homeCareViability.mmm5, 2);
                break;
            case "mmm6":
                supplements.push("Home Care Viability - MMM6");
                amount = round(amount + cd.supplements.homeCareViability.mmm6, 2);
                break;
            case "mmm7":
                supplements.push("Home Care Viability - MMM7");
                amount = round(amount + cd.supplements.homeCareViability.mmm7, 2);
                break;
        }

    }
    if(fixed) {
        amount = amount.toFixed(2);
    }
    return [supplements, amount];
}

// Convert from weekly to x
export function weeklyTo(period, amount, fixed = false) {
    let newAmount;
    switch(period) {
        case "ftn":
            newAmount = round(amount * 2, 2);
            break;
        case "month":
            newAmount = round(amount / 7 * 365 / 12, 2);
            break;
    }
    if(fixed) {
        newAmount = newAmount.toFixed(2);
    }
    return newAmount;
}

// Convert from daily to x
export function dailyTo(period, amount, fixed = false) {
    let amt = parseFloat(amount);
    let newAmount;
    if (amt > 0) {
        newAmount = amt * 7;
        if(period != "week") {
            newAmount = weeklyTo(period, newAmount);
        }
    } else {
        newAmount = 0;
    }
    if (fixed) {
        newAmount = newAmount.toFixed(2);
    }
    return newAmount;
}

// Calculate the basic daily fee based on HCP level and percentage selected
export function getBasicDailyFee(cd) {
    let bdf = cd.basicDailyFeeDaily["level"+cd.fundingLevel];
    let newBdf;
    if(cd.basicDailyFeePercent > 0) {
        // If we get here, it's either 100% or 50%
        newBdf = cd.basicDailyFeePercent == 100 ? bdf : bdf / 2;
    } else {
        newBdf = 0;
    }
    return newBdf;
}

// Calculate package management fee
export function getPackageManagementWeekly(cd, fixed = false) {
    let pmDaily = cd.packageManagementDaily["level" + cd.fundingLevel];
    let pm = round(pmDaily * 7, 2);
    if(fixed) {
        pm = pm.toFixed(2);
    }
    return pm;
}

// Calculate case management fee
export function getCareManagementWeekly(cd, fixed = false) {
    let cmw = 0;
    if(cd.careManagementFullyManaged) {
        cmw = round(cd.careManagementDaily["level" + cd.fundingLevel] * 7, 2);
    } else {
        cmw = round(cd.careManagementDailySelfManaged["level" + cd.fundingLevel] * 7, 2);
    }
    if(fixed) {
        cmw = cmf.toFixed(2);
    }
    return cmw;
}

// Full list of categories with included services for estimate summary table
export function getCategoryList(sd, cd) {
    const categories = [];
    sd.category.map((cat, i) => {
        const s = [];
        let catHrs = 0;
        let catCost = 0;
        cat.services.map((service, x) => {
            if (service.included) {
                let selectedItems = "";
                if (service.serviceSelection.length > 0) {
                    service.serviceSelection.map((item, z) => {
                        if(item.selected) {
                            selectedItems = selectedItems + "(" + item.name + ") ";
                        }
                    });
                }
                if(service.special == "flatFeeMulti") {
                    const serviceItems = {items: []};
                    let hrsAndCosts = serviceTotalCost(service, cd, true);
                    let totalHrs = 0;
                    let totalCost = 0;
                    let totalHrsFtn = 0;
                    let totalCostFtn = 0;
                    let totalHrsMonth = 0;
                    let totalCostMonth = 0;

                    [...Array(service.multiNum)].map((q, r) => {

                        if(service["type"+r+"QtyVisits"] > 0) {

                            let itemVisits = service["type"+r+"QtyVisits"] + (service["type"+r+"QtyVisits"] == 1 ? " visit per " : " visits per ") + service["type"+r+"VisitFrequency"] + ", " + service["type"+r+"HrsPerVisit"] + (service["type"+r+"HrsPerVisit"] == 1 ? " hour" : " hours") + " per visit.";
                            
                            let hrs = hrsAndCosts["type"+r+"Hrs"];
                            let cost = hrsAndCosts["type"+r+"Cost"];
                            let hrsFtn = weeklyTo("ftn", hrs);
                            let costFtn = weeklyTo("ftn", cost);
                            let hrsMonth = weeklyTo("month", hrs);
                            let costMonth = weeklyTo("month", cost);
                            
                            serviceItems.items.push({
                                name: service.selectDescriptors["flat"+r],
                                visits: itemVisits,
                                hrs: hrs,
                                cost: cost,
                                hrsFtn: hrsFtn,
                                costFtn: costFtn,
                                hrsMonth: hrsMonth,
                                costMonth: costMonth
                            });

                            totalHrs = totalHrs + hrs;
                            totalCost = totalCost + cost;
                            totalHrsFtn = totalHrsFtn + hrsFtn;
                            totalCostFtn = totalCostFtn + costFtn;
                            totalHrsMonth = totalHrsMonth + hrsMonth;
                            totalCostMonth = totalCostMonth + costMonth;
                        }

                    });
                    
                    
                    let notes = selectedItems + service.notes.replace(/(\r\n|\n|\r)/gm," ");

                    s.push({
                        name: service.name,
                        special: service.special,
                        serviceItems: serviceItems.items,
                        totalHrs: totalHrs,
                        totalCost: totalCost,
                        totalHrsFtn: totalHrsFtn,
                        totalCostFtn: totalCostFtn,
                        totalHrsMonth: totalHrsMonth,
                        totalCostMonth: totalCostMonth,
                        notes: notes,
                        selectedItems: selectedItems,
                        otherItems: false
                    });

                    catHrs = round(catHrs + round(totalHrs, 2), 2);
                    catCost = round(catCost + round(totalCost, 2), 2);

                } else {
                    let stdVisits = service.stdQtyVisits + (service.stdQtyVisits == 1 ? " visit per " : " visits per ") + service.stdVisitFrequency + ", " + service.stdHrsPerVisit + (service.stdHrsPerVisit == 1 ? " hour" : " hours") + " per visit.";
                    let satAHVisits = service.satAHQtyVisits + (service.satAHQtyVisits == 1 ? " visit per " : " visits per ") + service.satAHVisitFrequency + ", " + service.satAHHrsPerVisit + (service.satAHHrsPerVisit == 1 ? " hour" : " hours") + " per visit.";
                    let sunVisits = service.sunQtyVisits + (service.sunQtyVisits == 1 ? " visit per " : " visits per ") + service.sunVisitFrequency + ", " + service.sunHrsPerVisit + (service.sunHrsPerVisit == 1 ? " hour" : " hours") + " per visit.";
                    let notes = selectedItems + service.notes.replace(/(\r\n|\n|\r)/gm," ");
                    let hrsAndCosts = serviceTotalCost(service, cd, true);
                    let stdHrs = hrsAndCosts[0];
                    let stdCost = hrsAndCosts[1];
                    let stdHrsFtn = 0;
                    let stdCostFtn = 0;
                    let stdHrsMonth = 0;
                    let stdCostMonth = 0;
                    if(service.special == 'other') {
                        service.otherItems.map((item, o) => {
                            stdHrsFtn = round(stdHrsFtn + weeklyTo("ftn", item.hours), 2);
                            stdCostFtn = round(stdCostFtn + weeklyTo("ftn", item.amount), 2);
                            stdHrsMonth = round(stdHrsMonth + weeklyTo("month", item.hours), 2);
                            stdCostMonth = round(stdCostMonth + weeklyTo("month", item.amount), 2);
                        });
                    } else {
                        stdHrsFtn = weeklyTo("ftn", hrsAndCosts[0]);
                        stdCostFtn = weeklyTo("ftn", hrsAndCosts[1]);
                        stdHrsMonth = weeklyTo("month", hrsAndCosts[0]);
                        stdCostMonth = weeklyTo("month", hrsAndCosts[1]);
                    }
                    let satAHHrs = 0;
                    let satAHCost = 0;
                    let satAHHrsFtn = 0;
                    let satAHCostFtn = 0;
                    let satAHHrsMonth = 0;
                    let satAHCostMonth = 0;
                    let sunHrs = 0;
                    let sunCost = 0;
                    let sunHrsFtn = 0;
                    let sunCostFtn = 0;
                    let sunHrsMonth = 0;
                    let sunCostMonth = 0;
                    const otherItems = service.special == 'other' ? service.otherItems : false;
                    if (service.special == "respiteCentre"
                            || service.special == "generalNursing"
                            || service.special == "complexNursing"
                            || service.special == "medicationManagementClinicalNursing"
                            || service.special == "dressingGrooming"
                            || service.special == "medicationManagement"
                            || service.special == "wellnessCheck"
                            || service.special == "transport"
                            || service.special == "mealsAndNutrition"
                            || !service.special) {
                        satAHHrs = hrsAndCosts[2];
                        satAHCost = hrsAndCosts[3];
                        satAHHrsFtn = weeklyTo("ftn", hrsAndCosts[2]);
                        satAHCostFtn = weeklyTo("ftn", hrsAndCosts[3]);
                        satAHHrsMonth = weeklyTo("month", hrsAndCosts[2]);
                        satAHCostMonth = weeklyTo("month", hrsAndCosts[3]);
                        sunHrs = hrsAndCosts[4];
                        sunCost = hrsAndCosts[5];
                        sunHrsFtn = weeklyTo("ftn", hrsAndCosts[4]);
                        sunCostFtn = weeklyTo("ftn", hrsAndCosts[5]);
                        sunHrsMonth = weeklyTo("month", hrsAndCosts[4]);
                        sunCostMonth = weeklyTo("month", hrsAndCosts[5]);
                    }
                    s.push({
                        name: service.name,
                        special: service.special,
                        stdHrs: stdHrs,
                        stdCost: stdCost,
                        stdHrsFtn: stdHrsFtn,
                        stdCostFtn: stdCostFtn,
                        stdHrsMonth: stdHrsMonth,
                        stdCostMonth: stdCostMonth,
                        stdVisits: stdVisits,
                        satAHHrs: satAHHrs,
                        satAHCost: satAHCost,
                        satAHHrsFtn: satAHHrsFtn,
                        satAHCostFtn: satAHCostFtn,
                        satAHHrsMonth: satAHHrsMonth,
                        satAHCostMonth: satAHCostMonth,
                        satAHVisits: satAHVisits,
                        sunHrs: sunHrs,
                        sunCost: sunCost,
                        sunHrsFtn: sunHrsFtn,
                        sunCostFtn: sunCostFtn,
                        sunHrsMonth: sunHrsMonth,
                        sunCostMonth: sunCostMonth,
                        sunVisits: sunVisits,
                        notes: notes,
                        selectedItems: selectedItems,
                        otherItems: otherItems
                    });

                    catHrs = round(catHrs + round(stdHrs + satAHHrs + sunHrs, 2), 2);
                    catCost = round(catCost + round(stdCost + satAHCost + sunCost, 2), 2);
                }
            }
        });
        if (s.length > 0) {
            categories.push({
                name: cat.name,
                services: s,
                totalHrs: catHrs,
                totalCost: catCost
            });
        }
    });
    return categories.length > 0 ? categories : false;
}

// Get funding list
export function getFundingList(cd, sl) {
    const funding = {};
    if (cd.fundingType == "funded") {
        funding.supplementsFtn = weeklyTo("ftn", sl[1]);
        funding.supplementsMonth = weeklyTo("month", sl[1]);
        funding.topUpFtn = weeklyTo("ftn", cd.contribution);
        funding.topUpMonth = weeklyTo("month", cd.contribution);
        funding.basicDailyFeeFtn = dailyTo("ftn", getBasicDailyFee(cd));
        funding.basicDailyFeeMonth = dailyTo("month", getBasicDailyFee(cd));
        funding.incomeTestedFeeFtn = dailyTo("ftn", cd.incomeTestedFee);
        funding.incomeTestedFeeMonth = dailyTo("month", cd.incomeTestedFee);
        funding.hcpFtn = weeklyTo("ftn", cd["level" + cd.fundingLevel + "Weekly"] - dailyTo("week", cd.incomeTestedFee));
        funding.hcpMonth = weeklyTo("month", cd["level" + cd.fundingLevel + "Weekly"] - dailyTo("week", cd.incomeTestedFee));
        funding.amountYouPayFtn = round(funding.topUpFtn + funding.basicDailyFeeFtn + funding.incomeTestedFeeFtn, 2);
        funding.amountYouPayMonth = round(funding.topUpMonth + funding.basicDailyFeeMonth + funding.incomeTestedFeeMonth, 2);
        funding.amountGovPayFtn = round(funding.hcpFtn + funding.supplementsFtn, 2);
        funding.amountGovPayMonth = round(funding.hcpMonth + funding.supplementsMonth, 2);
        funding.totalBudgetFtn = round(funding.hcpFtn + funding.supplementsFtn + funding.topUpFtn + funding.basicDailyFeeFtn + funding.incomeTestedFeeFtn, 2);
        funding.totalBudgetMonth = round(funding.hcpMonth + funding.supplementsMonth + funding.topUpMonth + funding.basicDailyFeeMonth + funding.incomeTestedFeeMonth, 2);
    } else {
        funding.totalBudgetFtn = weeklyTo("ftn", cd.contribution);
        funding.totalBudgetMonth = weeklyTo("month", cd.contribution);
    }
    return funding;
}

/**
 * Send pageview to Google Analytics
 */
export function sendPageView(firstLoad, title) {
    if(window.location.hostname == 'calc.southernplus.org.au') {
        if(firstLoad) {
            return true;
        } else {
            window.gtag('config', 'UA-143329837-1', {
                'page_title': title,
                'page_location': window.location.href,
                'page_path': window.location.pathname,
            });
            return false;
        }
    }
    return false;
}

/**
 * Send event to Google Analytics
 */
export function sendEvent(action, category, label) {
    if(window.location.hostname == 'calc.southernplus.org.au') {
        window.gtag('event', action, {
            'event_category': category,
            'event_label': label
        });
    }
}

/**
 * Format number with comma separator
 */
export function thousands(amt) {
    return (amt).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

/**
 * Merge template version
 * This will merge an existing template to match
 * the latest template, unless a used service has been removed or
 * changed to a different pricing model
 */
export function mergeTemplate(existingCD, existingSD, latestCD, latestSD) {
    
    // Change notes for the user
    var servicesRemoved = [];

    /**
     * Copy the user-entered data and options in Client Details
     */
    latestCD.name = existingCD.name;
    latestCD.phone = existingCD.phone;
    latestCD.address = existingCD.address;
    latestCD.contactName = existingCD.contactName;
    latestCD.contactPhone = existingCD.contactPhone;
    latestCD.contactAddress = existingCD.contactAddress;
    latestCD.fundingType = existingCD.fundingType;
    latestCD.fundingLevel = existingCD.fundingLevel;
    latestCD.contribution = existingCD.contribution;
    latestCD.incomeTestedFee = existingCD.incomeTestedFee;
    latestCD.careManagementFullyManaged = existingCD.careManagementFullyManaged;
    latestCD.basicDailyFeePercent = existingCD.basicDailyFeePercent;
    latestCD.supplements.dementiaCognition.selected = existingCD.supplements.dementiaCognition.selected;
    latestCD.supplements.veterans.selected = existingCD.supplements.veterans.selected;
    latestCD.supplements.oxygen.selected = existingCD.supplements.oxygen.selected;
    latestCD.supplements.enteralFeeding.selected = existingCD.supplements.enteralFeeding.selected;
    latestCD.supplements.homeCareViability.selected = existingCD.supplements.homeCareViability.selected;

    /**
     * Iterate through the new services and merge user-entered changes if the services match
     * 
     * Use the 'key' field to match categories and services because 'key' is more of a constant
     * than the name or any other field.
     * 
     * Since we'll be populating the latestSD with the old user-inputs, category and service
     * names will already be updated if they have changed.
     */
    latestSD.category.map((c, i) => {
        
        // Attempt to find a matching category in existingSD
        let exCat = existingSD.category.filter(category => category.key === c.key);

        // Was this category was in the existing budget? Or is it new?
        if(typeof(exCat[0]) === "undefined") {
            /**
             * No match, so it's either a new category or the key was changed
             * Add this to the changes array to notify the user
             */
        } else {
            // The category was matched, now we iterate through the services
            c.services.map((s, j) => {

                // Attempt to find a matching service in this existingSD category
                let exSer = exCat[0].services.filter(service => service.key === s.key);

                // Was this service in the existing budget? Or is it new?
                if(typeof(exSer[0]) === "undefined") {
                    /**
                     * No match, so it's either a new service or the key was changed
                     * Add this to the changes array to notify the user
                     */
                } else {
                    // The service was matched, now check if the service type has changed
                    if(s.special !== exSer[0].special) {
                        /**
                         * The service type/format has changed, and therefore too difficult to convert
                         * into the new format. For example if it changed from hourly rate to flat fee
                         */
                    } else {
                        /**
                         * If we get here, it should be ok to merge the user-created changes into
                         * the latestSD service
                         */
                        // Make changes relevant to ALL service types
                        if(s.serviceSelection.length > 0) {
                            s.serviceSelection.map((ss, k) => {
                                // Attempt to match the serviceSelection item
                                let exSS = exSer[0].serviceSelection.filter(selCheck => selCheck.name === ss.name);
                                // Does the serviceSelection exist?
                                if(typeof(exSS[0]) !== "undefined") {
                                    // Not reporting missing serviceSelections to user
                                    // Update the selection
                                    latestSD.category[i].services[j].serviceSelection[k].selected = exSS[0].selected;
                                }
                            });
                        }
                        latestSD.category[i].services[j].totalHrs = exSer[0].totalHrs;
                        latestSD.category[i].services[j].gst = exSer[0].gst;
                        latestSD.category[i].services[j].notes = exSer[0].notes;
                        latestSD.category[i].services[j].included = exSer[0].included;

                        // Make remainder of changes based on the service type
                        switch(s.special) {
                            case "flatFeeMulti":
                                let mn = latestSD.category[i].services[j].multiNum;
                                for(var x=0;x<mn;x++) {
                                    latestSD.category[i].services[j]["type"+x+"QtyVisits"] = exSer[0]["type"+x+"QtyVisits"];
                                    latestSD.category[i].services[j]["type"+x+"VisitFrequency"] = exSer[0]["type"+x+"VisitFrequency"];
                                    latestSD.category[i].services[j]["type"+x+"HrsPerVisit"] = exSer[0]["type"+x+"HrsPerVisit"];
                                }
                                break;
                            case "other":
                                latestSD.category[i].services[j].otherItems = exSer[0].otherItems;
                                break;
                            default:
                                latestSD.category[i].services[j].stdQtyVisits = exSer[0].stdQtyVisits;
                                latestSD.category[i].services[j].stdVisitFrequency = exSer[0].stdVisitFrequency;
                                latestSD.category[i].services[j].stdHrsPerVisit = exSer[0].stdHrsPerVisit;
                                latestSD.category[i].services[j].satAHQtyVisits = exSer[0].satAHQtyVisits;
                                latestSD.category[i].services[j].satAHVisitFrequency = exSer[0].satAHVisitFrequency;
                                latestSD.category[i].services[j].satAHHrsPerVisit = exSer[0].satAHHrsPerVisit;
                                latestSD.category[i].services[j].sunQtyVisits = exSer[0].sunQtyVisits;
                                latestSD.category[i].services[j].sunVisitFrequency = exSer[0].sunVisitFrequency;
                                latestSD.category[i].services[j].sunHrsPerVisit = exSer[0].sunHrsPerVisit;
                        }
                    }
                }
            })
        }
    });

    /**
     * Iterate through existingSD to find services the have been removed
     * and report these in the list of changes for the user
     */
    existingSD.category.map((ec) => {
        ec.services.map((es) => {
            let exists = false;
            let wasRemoved = false;
            latestSD.category.map((lc) => {
                lc.services.map((ls) => {
                    if(ls.key === es.key) {
                        // We have matched the service
                        exists = true;
                        if(es.included === true && ls.included === false) {
                            wasRemoved = true;
                        }
                    }
                })
            });
            if(exists === false) {
                if(es.included === true) {
                    wasRemoved = true;
                }
            }
            if(wasRemoved === true) {
                servicesRemoved.push(es);
            }
        });
    });


    /**
     * Return the latestCD and latestSD with the existing data added
     */
    return {cd: latestCD, sd: latestSD, sr: servicesRemoved};
}
