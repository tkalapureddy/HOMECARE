import React from 'react';

export const GlobalContext = React.createContext({
    goToServices: false,
    firstLoad: true
});
