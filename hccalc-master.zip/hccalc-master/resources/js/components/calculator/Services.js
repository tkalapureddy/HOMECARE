import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import RemoveServiceIcon from './RemoveServiceIcon';
import EditServiceModal from './EditServiceModal';
import ServicesSidebar from './ServicesSidebar';
import FullPageModal from './FullPageModal';
import { round, categoryTotalHrs, sendPageView } from './inc/Helpers';

export default class Services extends Component {

    constructor(props) {
        super(props);
        this.state = {
            serviceModal: {
                active: false,
                category: 0,
                service: 0
            }
        };
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        // Send a page view if necessary
        sendPageView(this.props.firstLoad, 'Services');
        this.props.updateFirstLoad();
    }

    editService = (cKey, sKey) => {
        const sd = this.props.serviceDetails;
        var category, service;
        sd.category.map((c, i) => {
            if(c.key == cKey) {
                category = i;
                c.services.map((s, x) => {
                    if(s.key == sKey) {
                        service = x;
                    }
                });
            }
        });
        this.setState({
            serviceModal: {
                active: true,
                category: category,
                service: service
            }
        });
    }

    closeModal() {
        this.setState({
            serviceModal: {
                active: false
            }
        });
    }

    updateClientDetails = (newDetails) => {
        this.props.updateClientDetails(newDetails);
    }

    updateService(dataType, data) {
        const sd = this.props.serviceDetails;
        const c = this.state.serviceModal.category;
        const s = this.state.serviceModal.service;
        switch(dataType) {
            case "onOff":
                if(data == "toggle") { // Switch service off from main services screen
                    sd.category[c].services[s].included = !sd.category[c].services[s].included;
                } else { // Switch service off from modal
                    const newData = this.getCatServ(data);
                    sd.category[newData.category].services[newData.service].included = false;
                }
                break;
            case "subService":
                sd.category[c].services[s].serviceSelection[data.idx].selected = data.ste;
                break;
            case "notes":
                sd.category[c].services[s].notes = data;
                break;
            case "hrs":
                switch(data.type) {
                    case "stdFrequency":
                        // Increase
                        if(data.increase) {
                            if(sd.category[c].services[s].stdVisitFrequency == "week") {
                                sd.category[c].services[s].stdQtyVisits = sd.category[c].services[s].stdQtyVisits + 1;
                            }
                            if(sd.category[c].services[s].stdQtyVisits == 1 && sd.category[c].services[s].stdVisitFrequency == "ftn") {
                                sd.category[c].services[s].stdVisitFrequency = "week";
                            }
                            if(sd.category[c].services[s].stdQtyVisits == 1 && sd.category[c].services[s].stdVisitFrequency == "month") {
                                sd.category[c].services[s].stdVisitFrequency = "ftn";
                            }
                            if(sd.category[c].services[s].special == "respiteCentre" && sd.category[c].services[s].stdQtyVisits == 0) {
                                sd.category[c].services[s].stdQtyVisits = 1;
                            }
                        } else {
                            // Decrease
                            let makeItZero = true;
                            if(sd.category[c].services[s].stdQtyVisits == 1 && sd.category[c].services[s].stdVisitFrequency == "ftn") {
                                sd.category[c].services[s].stdVisitFrequency = "month";
                                makeItZero = false;
                            }
                            if(sd.category[c].services[s].stdQtyVisits == 1 && sd.category[c].services[s].stdVisitFrequency == "week") {
                                sd.category[c].services[s].stdVisitFrequency = "ftn";
                            }
                            if(sd.category[c].services[s].stdQtyVisits > 1) {
                                sd.category[c].services[s].stdQtyVisits = sd.category[c].services[s].stdQtyVisits - 1;
                            } else {
                                if(sd.category[c].services[s].special == "respiteCentre") {
                                    if(sd.category[c].services[s].stdQtyVisits == 1 && sd.category[c].services[s].stdVisitFrequency == "month" && makeItZero) {
                                        sd.category[c].services[s].stdQtyVisits = 0;
                                    }
                                }
                            }
                        }
                        break;
                    case "stdPerVisit":
                        if(data.increase) {
                            if (sd.category[c].services[s].special == "alliedHealth") {
                                sd.category[c].services[s].stdHrsPerVisit = 1;
                            } else if (sd.category[c].services[s].special == "spalliedHealth") {
                                sd.category[c].services[s].stdHrsPerVisit = 0.75;
                            } else if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing"
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].stdHrsPerVisit == 0) {
                                    sd.category[c].services[s].stdHrsPerVisit = 0.5;
                                } else {
                                    sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit + 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].stdHrsPerVisit == 0) {
                                    sd.category[c].services[s].stdHrsPerVisit = 1;
                                } else {
                                    sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit + 0.25;
                                }
                            } else {
                                sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit + 0.25;
                            }
                        } else {
                            if (sd.category[c].services[s].special == "alliedHealth") {
                                sd.category[c].services[s].stdHrsPerVisit = 0.75;
                            } else if (sd.category[c].services[s].special == "spalliedHealth") {
                                sd.category[c].services[s].stdHrsPerVisit = 0.50;
                            } else if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing"
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].stdHrsPerVisit == 0.5) {
                                    sd.category[c].services[s].stdHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].stdHrsPerVisit !== 0) {
                                    sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit - 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].stdHrsPerVisit == 1) {
                                    sd.category[c].services[s].stdHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].stdHrsPerVisit !== 0) {
                                    sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit - 0.25;
                                }
                            } else {
                                if(sd.category[c].services[s].stdHrsPerVisit > 0) {
                                    sd.category[c].services[s].stdHrsPerVisit = sd.category[c].services[s].stdHrsPerVisit - 0.25;
                                }
                            }
                        }
                        break;
                    case "satAHFrequency":
                        // Increase
                        if(data.increase) {
                            if (sd.category[c].services[s].satAHVisitFrequency == "week") {
                                sd.category[c].services[s].satAHQtyVisits = sd.category[c].services[s].satAHQtyVisits + 1;
                            }
                            if (sd.category[c].services[s].satAHQtyVisits == 1 && sd.category[c].services[s].satAHVisitFrequency == "ftn") {
                                sd.category[c].services[s].satAHVisitFrequency = "week";
                            }
                            if (sd.category[c].services[s].satAHQtyVisits == 1 && sd.category[c].services[s].satAHVisitFrequency == "month") {
                                sd.category[c].services[s].satAHVisitFrequency = "ftn";
                            }
                            if(sd.category[c].services[s].special == "respiteCentre" && sd.category[c].services[s].satAHQtyVisits == 0) {
                                sd.category[c].services[s].satAHQtyVisits = 1;
                            }
                        } else {
                            // Decrease
                            let makeItZero = true;
                            if (sd.category[c].services[s].satAHQtyVisits == 1 && sd.category[c].services[s].satAHVisitFrequency == "ftn") {
                                sd.category[c].services[s].satAHVisitFrequency = "month";
                                makeItZero = false;
                            }
                            if (sd.category[c].services[s].satAHQtyVisits == 1 && sd.category[c].services[s].satAHVisitFrequency == "week") {
                                sd.category[c].services[s].satAHVisitFrequency = "ftn";
                            }
                            if (sd.category[c].services[s].satAHQtyVisits > 1) {
                                sd.category[c].services[s].satAHQtyVisits = sd.category[c].services[s].satAHQtyVisits - 1;
                            } else {
                                if(sd.category[c].services[s].special == "respiteCentre" && sd.category[c].services[s].satAHVisitFrequency == "month" && makeItZero) {
                                    sd.category[c].services[s].satAHQtyVisits = 0;
                                }
                            }
                        }
                        break;
                    case "satAHPerVisit":
                        if(data.increase) {
                            if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing"
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].satAHHrsPerVisit == 0) {
                                    sd.category[c].services[s].satAHHrsPerVisit = 0.5;
                                } else {
                                    sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit + 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].satAHHrsPerVisit == 0) {
                                    sd.category[c].services[s].satAHHrsPerVisit = 1;
                                } else {
                                    sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit + 0.25;
                                }
                            } else {
                                sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit + 0.25;
                            }
                        } else {
                            if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing"
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].satAHHrsPerVisit == 0.5) {
                                    sd.category[c].services[s].satAHHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].satAHHrsPerVisit !== 0) {
                                    sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit - 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].satAHHrsPerVisit == 1) {
                                    sd.category[c].services[s].satAHHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].satAHHrsPerVisit !== 0) {
                                    sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit - 0.25;
                                }
                            } else {
                                if(sd.category[c].services[s].satAHHrsPerVisit > 0) {
                                    sd.category[c].services[s].satAHHrsPerVisit = sd.category[c].services[s].satAHHrsPerVisit - 0.25;
                                }
                            }
                        }
                        break;
                    case "sunFrequency":
                        if(data.increase) {
                            // Increase
                            if (sd.category[c].services[s].sunVisitFrequency == "week") {
                                sd.category[c].services[s].sunQtyVisits = sd.category[c].services[s].sunQtyVisits + 1;
                            }
                            if (sd.category[c].services[s].sunQtyVisits == 1 && sd.category[c].services[s].sunVisitFrequency == "ftn") {
                                sd.category[c].services[s].sunVisitFrequency = "week";
                            }
                            if (sd.category[c].services[s].sunQtyVisits == 1 && sd.category[c].services[s].sunVisitFrequency == "month") {
                                sd.category[c].services[s].sunVisitFrequency = "ftn";
                            }
                            if(sd.category[c].services[s].special == "respiteCentre" && sd.category[c].services[s].sunQtyVisits == 0) {
                                sd.category[c].services[s].sunQtyVisits = 1;
                            }
                        } else {
                            // Decrease
                            let makeItZero = true;
                            if (sd.category[c].services[s].sunQtyVisits == 1 && sd.category[c].services[s].sunVisitFrequency == "ftn") {
                                sd.category[c].services[s].sunVisitFrequency = "month";
                                makeItZero = false;
                            }
                            if (sd.category[c].services[s].sunQtyVisits == 1 && sd.category[c].services[s].sunVisitFrequency == "week") {
                                sd.category[c].services[s].sunVisitFrequency = "ftn";
                            }
                            if (sd.category[c].services[s].sunQtyVisits > 1) {
                                sd.category[c].services[s].sunQtyVisits = sd.category[c].services[s].sunQtyVisits - 1;
                            } else {
                                if(sd.category[c].services[s].special == "respiteCentre" && sd.category[c].services[s].sunVisitFrequency == "month" && makeItZero) {
                                    sd.category[c].services[s].sunQtyVisits = 0;
                                }
                            }
                        }
                        break;
                    case "sunPerVisit":
                        if(data.increase) {
                            if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing"
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].sunHrsPerVisit == 0) {
                                    sd.category[c].services[s].sunHrsPerVisit = 0.5;
                                } else {
                                    sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit + 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].sunHrsPerVisit == 0) {
                                    sd.category[c].services[s].sunHrsPerVisit = 1;
                                } else {
                                    sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit + 0.25;
                                }
                            } else {
                                sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit + 0.25;
                            }
                        } else {
                            if (sd.category[c].services[s].special == "generalNursing"
                                    || sd.category[c].services[s].special == "complexNursing" 
                                    || sd.category[c].services[s].special == "medicationManagementClinicalNursing"
                                    || sd.category[c].services[s].special == "dressingGrooming"
                                    || sd.category[c].services[s].special == "wellnessCheck"
                                    || sd.category[c].services[s].special == "transport"
                                    || sd.category[c].services[s].special == "mealsAndNutrition") {
                                if (sd.category[c].services[s].sunHrsPerVisit == 0.5) {
                                    sd.category[c].services[s].sunHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].sunHrsPerVisit !== 0) {
                                    sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit - 0.25;
                                }
                            } else if (sd.category[c].services[s].minHrs !== undefined) {
                                if (sd.category[c].services[s].sunHrsPerVisit == 1) {
                                    sd.category[c].services[s].sunHrsPerVisit = 0;
                                } else if (sd.category[c].services[s].sunHrsPerVisit !== 0) {
                                    sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit - 0.25;
                                }
                            } else {
                                if(sd.category[c].services[s].sunHrsPerVisit > 0) {
                                    sd.category[c].services[s].sunHrsPerVisit = sd.category[c].services[s].sunHrsPerVisit - 0.25;
                                }
                            }
                        }
                        break;
                    case "flatFrequency":
                        // Increase
                        if(data.increase) {
                            if(sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "week") {
                                sd.category[c].services[s]["type" + data.idx + "QtyVisits"] = sd.category[c].services[s]["type" + data.idx + "QtyVisits"] + 1;
                            }
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] == 1 && sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "ftn") {
                                sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] = "week";
                            }
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] == 1 && sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "month") {
                                sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] = "ftn";
                            }
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] == 0 && sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "month") {
                                sd.category[c].services[s]["type" + data.idx + "QtyVisits"] = 1;
                            }
                        } else {
                            // Decrease
                            let makeItZero = true;
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] == 1 && sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "ftn") {
                                sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] = "month";
                                makeItZero = false;
                            }
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] == 1 && sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "week") {
                                sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] = "ftn";
                            }
                            if(sd.category[c].services[s]["type" + data.idx + "QtyVisits"] > 1) {
                                sd.category[c].services[s]["type" + data.idx + "QtyVisits"] = sd.category[c].services[s]["type" + data.idx + "QtyVisits"] - 1;
                            } else {
                                if(sd.category[c].services[s]["type" + data.idx + "VisitFrequency"] == "month" && makeItZero) {
                                    sd.category[c].services[s]["type" + data.idx + "QtyVisits"] = 0;
                                }
                            }
                        }
                        break;
                }
                // Update total hrs
                let std, satAH, sun;
                if(sd.category[c].services[s].special == "respiteCentre") {
                    /**
                     * Notes on respiteCentre
                     * Repurposing std, satAH and sun for the three types of respite centre stays
                     * If another type is created, will have to change how this all works
                     * (pressed for time)
                     */
                    std = 6 * (sd.category[c].services[s].stdQtyVisits * this.frequencyFix(sd.category[c].services[s].stdVisitFrequency));
                    satAH = 24 * (sd.category[c].services[s].satAHQtyVisits * this.frequencyFix(sd.category[c].services[s].satAHVisitFrequency));
                    sun = 24 * (sd.category[c].services[s].sunQtyVisits * this.frequencyFix(sd.category[c].services[s].sunVisitFrequency));
                } else if(sd.category[c].services[s].special == "flatFeeMulti") {
                    let totalHrs = 0;
                    [...Array(sd.category[c].services[s].multiNum)].map((x, i) => {
                        totalHrs = totalHrs + sd.category[c].services[s]["type"+i+"HrsPerVisit"] * (sd.category[c].services[s]["type"+i+"QtyVisits"] * this.frequencyFix(sd.category[c].services[s]["type"+i+"VisitFrequency"]));
                    });
                    sd.category[c].services[s].totalHrs = totalHrs;
                    break;
                } else {
                    std = sd.category[c].services[s].stdHrsPerVisit * (sd.category[c].services[s].stdQtyVisits * this.frequencyFix(sd.category[c].services[s].stdVisitFrequency));
                    satAH = sd.category[c].services[s].satAHHrsPerVisit * (sd.category[c].services[s].satAHQtyVisits * this.frequencyFix(sd.category[c].services[s].satAHVisitFrequency));
                    sun = sd.category[c].services[s].sunHrsPerVisit * (sd.category[c].services[s].sunQtyVisits * this.frequencyFix(sd.category[c].services[s].sunVisitFrequency));
                }
                sd.category[c].services[s].totalHrs = std + satAH + sun;
                break;
            case "customServiceItem":
                let newKey = Math.random().toString(36).substring(7);
                switch(data[0]) {
                    case "addItem":
                        sd.category[c].services[s].otherItems.push({title: "", hours: 0, amount: 0, key: newKey});
                        break;
                    case "updateItem":
                        if(data[1] == "itemTitle") {
                            sd.category[c].services[s].otherItems[data[2]].title = data[3];
                        } else if(data[1] == "itemHours") {
                            let itemHours = !isNaN(parseFloat(data[3])) ? round(parseFloat(data[3]), 2) : 0;
                            sd.category[c].services[s].otherItems[data[2]].hours = itemHours;
                        } else if(data[1] == "itemAmount") {
                            let itemAmount = !isNaN(parseFloat(data[3])) ? round(parseFloat(data[3]), 2) : 0;
                            sd.category[c].services[s].otherItems[data[2]].amount = itemAmount;
                        }
                        // Update total hours for service modal and service page category list (top right of the coloured sections)
                        let totalHrs = 0;
                        sd.category[c].services[s].otherItems.map((item, i) =>
                            totalHrs = round(totalHrs + item.hours, 2)
                        );
                        sd.category[c].services[s].totalHrs = totalHrs;
                        break;
                    case "deleteItem":
                        // If it's the last one, just empty the details and give it a new key
                        if(sd.category[c].services[s].otherItems.length == 1) {
                            sd.category[c].services[s].otherItems[0].title = "";
                            sd.category[c].services[s].otherItems[0].amount = 0;
                            sd.category[c].services[s].otherItems[0].key = newKey;
                        } else { // Delete it
                            sd.category[c].services[s].otherItems = sd.category[c].services[s].otherItems.filter((item, i) => i !== data[1]);
                        }
                        break;
                }
                break;
        }
        this.props.updateServiceDetails(sd);
    }

    frequencyFix(visitFrequency) {
        let freqFix = 0;
        switch (visitFrequency) {
            case "week":
                freqFix = 1;
                break;
            case "ftn":
                freqFix = 0.5;
                break;
            case "month":
                freqFix = 12 / (365 / 7);
        }
        return freqFix;
    }
    
    getCatServ = (data) => {
        const sd = this.props.serviceDetails;
        const newData = {
            category: 0,
            service: 0
        }
        sd.category.map((c, i) => {
            if(c.key == data.category) {
                newData.category = i;
                c.services.map((s, x) => {
                    if(s.key == data.service) {
                        newData.service = x;
                    }
                });
            }
        });
        return(newData);
    }

    render() {
        const sdCats = this.props.serviceDetails.category;
        return (
            this.props.loadingTemplate ?
                <FullPageModal />
            :
                <React.Fragment>
                    <div className="columns is-gapless services-page">
                        {
                            /* MODAL */
                            this.state.serviceModal.active &&
                            <EditServiceModal
                                serviceDetails={this.props.serviceDetails}
                                clientDetails={this.props.clientDetails}
                                serviceModal={this.state.serviceModal}
                                closeModal={this.closeModal.bind(this)}
                                updateService={this.updateService.bind(this)}
                            />
                        }
                        <div className="column services-main">
                            {
                                sdCats.map((cat, i) => {
                                    if (cat.class == "cat-planning-management" && this.props.clientDetails.fundingType == "funded") {
                                        return;
                                    } else {
                                        return (
                                            <div className={"services-section " + cat.class} key={cat.key}>
                                                <div className="services-section-title is-clearfix">
                                                    <div className="is-pulled-left">
                                                        {cat.name}
                                                    </div>
                                                    <div className="is-pulled-right">
                                                        {categoryTotalHrs(cat)} {categoryTotalHrs(cat) == 1 ? "hour/w" : "hours/w"}
                                                    </div>
                                                </div>
                                                <div className="services-section-service">
                                                    <ul>
                                                        {
                                                            cat.services.map((service, x) => 
                                                                <li key={service.key} id={service.key} className={service.included ? "included" : ""} onClick={() => this.editService(cat.key, service.key)}>
                                                                    {service.name}
                                                                    <RemoveServiceIcon
                                                                        categoryKey={cat.key}
                                                                        serviceKey={service.key}
                                                                        updateService={this.updateService.bind(this)}
                                                                    />
                                                                </li>
                                                            )
                                                        }
                                                    </ul>
                                                </div>
                                            </div>
                                        )
                                    }
                                })
                            }
                        </div>
                        <div className="column is-5 services-sidebar">
                            <div className="services-sidebar-container">
                                <ServicesSidebar
                                    clientDetails={this.props.clientDetails}
                                    serviceDetails={this.props.serviceDetails}
                                    updateClientDetails={this.updateClientDetails.bind(this)}
                                />
                            </div>
                        </div>
                    </div>
                    <section className="section is-medium hide-for-print">
                        <div className="container">
                            <p>&nbsp;</p>
                        </div>
                    </section>
                </React.Fragment>
        );
    }
}
