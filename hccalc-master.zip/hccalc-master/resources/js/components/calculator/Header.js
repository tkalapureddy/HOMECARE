import React from 'react';
import { NavLink } from 'react-router-dom';
import Tooltip from 'react-tooltip-lite';
import { thousands } from './inc/Helpers'

export function toggleCalcMenu(e) {

    // Get the target from the "data-target" attribute
    const target = e.target.dataset.target;
    const targetEl = document.getElementById(target);

    // Toggle the "is-active" class on both the "navbar-burger" and the "navbar-menu"
    e.target.classList.toggle('is-active');
    targetEl.classList.toggle('is-active');
    
}

function Header(props) {

    /**
     * This function adds an 's' for plural if 'num' is not '1'
     * @param {string} text 
     * @param {int} num 
     * @return {string}
     */
    const plural = (text, num) => {
        let res = num === 1 ? text : text + "s";
        return res;
    }

    /**
     * Populates an array to display as a tooltip for removed services
     * Enables user to know what to add in place of what was removed
     * @param {object} s 
     * @return {array}
     */
    const removedServiceContent = (s) => {
        let res = [];
        res.push("[REMOVED] " + s.name);
        switch(s.special) {
            case "flatFeeMulti":
                for(var x=0;x<s.multiNum;x++) {
                    if(s["type"+x+"QtyVisits"] > 0) {
                        res.push("[" + s.selectDescriptors["flat" + x] + "] " + s["type"+x+"QtyVisits"] + " " + plural("visit", s["type"+x+"QtyVisits"]) + " per " + s["type"+x+"VisitFrequency"] + ", " + s["type"+x+"HrsPerVisit"] + " " + plural("hour", s["type"+x+"HrsPerVisit"]) + " per visit");
                    }
                }
                break;
            case "other":
                s.otherItems.map((item, x) => {
                    res.push("[" + item.title + "] " + item.hours + " " + plural("hour", item.hours) + ", $" + thousands(item.amount.toFixed(2)));
                });
                break;
            default:
                if(s.stdHrsPerVisit > 0) {
                    res.push("[Standard] " + s.stdQtyVisits + " " + plural("visit", s.stdQtyVisits) + " per " + s.stdVisitFrequency + ", " + s.stdHrsPerVisit + " " + plural("hour", s.stdHrsPerVisit) + " per visit");
                }
                if(s.satAHHrsPerVisit > 0) {
                    res.push("[Sat/AH] " + s.satAHQtyVisits + " " + plural("visit", s.satAHQtyVisits) + " per " + s.satAHVisitFrequency + ", " + s.satAHHrsPerVisit + " " + plural("hour", s.satAHHrsPerVisit) + " per visit");
                }
                if(s.sunHrsPerVisit > 0) {
                    res.push("[Sun] " + s.sunQtyVisits + " " + plural("visit", s.sunQtyVisits) + " per " + s.sunVisitFrequency + ", " + s.sunHrsPerVisit + " " + plural("hour", s.sunHrsPerVisit) + " per visit");
                }
        }
        s.serviceSelection.map((item, x) => {
            if(item.selected) {
                res.push("[Checkbox] " + item.name);
            }
        });
        res.push("[Total hours per week] " + s.totalHrs.toFixed(2));
        if(s.notes !== "") {
            res.push("[Notes] " + s.notes);
        }
        return res;
    }

    /**
     * Copies any string to the clipboard
     * @param {string} notes 
     */
    function copyToClipboard(notes) {
        navigator.clipboard.writeText(notes);
    }
    
    return (
        <header className="calc-menu hide-for-print">
            <div className="calc-title level is-marginless">
                <div className="level-left is-clearfix">
                    <span className="is-pulled-left has-text-white is-marginless h1">Home Care Calculator</span>
                </div>
                <div className="level-right is-clearfix">
                    <span className="is-pulled-right has-text-white is-marginless h3">{props.clientDetails.name}</span>
                </div>
            </div>
            <nav className="navbar">
                <div className="navbar-brand">
                    <a role="button" className="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarCalc" onClick={toggleCalcMenu}>
                        <span aria-hidden="true"></span>
                        <span aria-hidden="true"></span>
                        <span aria-hidden="true"></span>
                    </a>
                </div>
                <div id="navbarCalc" className="navbar-menu">
                    <div className="navbar-start">
                        <NavLink exact to="/calculator" className="navbar-item" activeClassName="is-active">Start New</NavLink>
                        <NavLink exact to="/calculator/client" className="navbar-item" id="clientNav" activeClassName="is-active">Client</NavLink>
                        <NavLink exact to="/calculator/services" className="navbar-item" activeClassName="is-active" id="menuItemServices">Services</NavLink>
                        <NavLink exact to="/calculator/review-and-save" className="navbar-item" activeClassName="is-active" id="menuItemReviewSave">Review &amp; Save</NavLink>
                    </div>
                    <div className="navbar-end">
                        <div className="navbar-item has-dropdown is-hoverable">
                            <div className="navbar-link">Staff</div>
                            <div className="navbar-dropdown is-right">
                                <NavLink exact to="/calculator/budgets" className="navbar-item" activeClassName="is-active">Budgets</NavLink>
                                {
                                    props.permissionContent &&
                                    <NavLink exact to="/calculator/template" className="navbar-item" activeClassName="is-active">Template</NavLink>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            {
                props.templateId !== props.templateIdLatest &&
                <section className="section warning-bar-section">
                    <div className="container">
                        <div className="warning-bar level">
                            WARNING! This budget is using out-of-date pricing/fees/services.<br />
                            Please click the 'Update budget' button if you want to make changes. <button className="button" onClick={props.templateVersionMismatch}>Update budget</button>
                        </div>
                    </div>
                </section>
            }
            {
                props.templateChanges.length > 0 &&
                <section className="section changes-bar-section">
                    <div className="container">
                        <div className="changes-bar">
                            <div className="columns">
                                <div className="column is-6">
                                    The following services that were previously used in this budget were removed or cleared due to template changes.<br />
                                    If the services still exist you can add them in again.
                                </div>
                                <div className="column is-4">
                                    <span className="is-italic has-text-weight-semibold">Hover or tap each item for details</span><br />
                                    <span className="is-italic has-text-weight-semibold">Tap or click item to copy notes to clipboard</span>
                                    <ul className="removed-services-list">
                                        {
                                            props.templateChanges.map((change, i) => {
                                                return (
                                                    <li key={i} onClick={() => copyToClipboard(change.notes)}>
                                                        <Tooltip
                                                            content={(
                                                                <div>
                                                                    {removedServiceContent(change).map((c, j) => <div key={j}>{c}</div>)}
                                                                </div>
                                                            )}
                                                        >
                                                            {change.name}
                                                        </Tooltip>
                                                    </li>
                                                )
                                            })
                                        }
                                    </ul>
                                </div>
                                <div className="column is-2">
                                    <button className="button is-pulled-right" onClick={props.dismissTemplateChanges}>Dismiss</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            }
            {
                props.templateItemInfo !== false &&
                <section className="section changes-bar-section">
                    <div className="container">
                        <div className="changes-bar">
                            <div className="columns">
                                <div className="column is-half">
                                    {props.templateItemInfo.name}
                                </div>
                                <div className="column is-one-quarter">
                                    {props.templateItemInfo.notes}
                                </div>
                                <div className="column is-one-quarter">
                                    Total Hours: {props.templateItemInfo.totalHrs}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            }
        </header>
    );
}

export default Header