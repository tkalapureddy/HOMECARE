import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, withRouter, Redirect } from 'react-router-dom';
import './styles.scss';
import Header from './Header';
import StartNew from './StartNew';
import Client from './Client';
import Services from './Services';
import ReviewAndSave from './ReviewAndSave';
import Budgets from './Budgets';
import Template from './Template';
import FullPageModal from './FullPageModal';
import 'whatwg-fetch';
import { sendEvent, mergeTemplate } from './inc/Helpers';

/**
 * How to get a new version of the template:
 * Make changes as needed in ./inc/CalculatorDataEmpty.js
 * Follow the instructions below which will make the data
 * available in browser console when using the $r var e.g.
 * $r.state.clientDetailsEmpty
 * $r.state.serviceDetailsEmpty
 * Output those vars in the console and you can copy paste them directly
 * into a new db entry in the estimates table. This is temporary
 * until the functionality is developed for an administrator
 * to make changes in the UI
 * To import changed data, uncomment the following line
 * and the matching variables in the constructor state
 * |-----IMPORTANT-----| Make sure they're commented again
 * before compiling for production
 */
//import { ServiceDetailsEmpty, ClientDetailsEmpty } from './inc/CalculatorDataEmpty';

class Calculator extends Component {
    
    constructor(props) {
        super(props);
        this.state = {
            permissionContent: false,
            permissionAdmin: false,
            permissionSuperAdmin: false,
            estimateId: 0,
            estimateNum: "-",
            revision: "-",
            createdAt: "-",
            salesPerson: "",
            userId: 0,
            clientDetails: false,
            serviceDetails: false,
            loadingTemplate: true,
            appVersion: "0",
            templateId: 0,
            templateIdLatest: 0,
            templateChanges: [],
            templateItemInfo: false,
            firstLoad: true,
            changesMade: false,
            savingEstimate: false,
            pdfFilename: null,
            mergeTemplate: false,
            redirectToClient: false
            //clientDetailsEmpty: ClientDetailsEmpty,
            //serviceDetailsEmpty: ServiceDetailsEmpty
        };
    }

    componentDidMount() {
        /**
         * Retrieve the version to be output to the console
         * in the calcAPI function
         * Load the latest blank template into state
         */
        if(this.state.firstLoad) {
            this.loadTemplate();
            this.calcAPI('version');
            this.calcAPI('my-permissions');
        }
    }

    calcAPI(item, method = 'GET', sendData = false) {
        const t = this;
        let token = document.head.querySelector("[name='csrf-token'][content]").content;
        const fetchData = {
            method: 'GET',
            withCredentials: true,
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': token
            }
        }
        if(method == 'POST') {
            fetchData.method = 'POST';
            fetchData.headers["Content-Type"] = "application/json";
            fetchData.headers["Accept"] = "application/json, text-plain, */*";
            fetchData.headers["X-Requested-With"] = "XMLHttpRequest";
            fetchData.credentials = "same-origin";
            fetchData.body = JSON.stringify(sendData);
        }
        fetch('/calculator/api/' + item, fetchData)
        .then(response => response.json())
        .then(data => {
            switch(item) {
                case 'template':
                    if(t.state.mergeTemplate) { // Update an existing budget - merge in latest template
                        const latestCD = JSON.parse(data.clientDetails)
                        const latestSD = JSON.parse(data.serviceDetails)
                        var updatedTemplate = mergeTemplate(this.state.clientDetails, this.state.serviceDetails, latestCD, latestSD);
                        t.setState({
                            mergeTemplate: false,
                            loadingTemplate: false,
                            clientDetails: updatedTemplate.cd,
                            serviceDetails: updatedTemplate.sd,
                            templateId: this.state.templateIdLatest,
                            changesMade: true,
                            templateChanges: updatedTemplate.sr
                        });
                    } else { // Set template as usual
                        t.setState({
                            salesPerson: data.username,
                            userId: data.userId,
                            pdfFilename: data.pdfFilename,
                            clientDetails: JSON.parse(data.clientDetails),
                            serviceDetails: JSON.parse(data.serviceDetails),
                            templateId: data.id,
                            templateIdLatest: data.id
                        }, function() {
                            t.setState({
                                loadingTemplate: false
                            }, function() {
                                t.updateMenu();
                            })
                        });
                    }
                    break;
                case 'version':
                    t.setState({
                        appVersion: data.version
                    });
                    console.log('Home Care Calculator v' + data.version);
                    break;
                case 'save-estimate':
                    t.setState({
                        estimateId: data.estimateId,
                        estimateNum: data.estimateNum,
                        revision: data.revision,
                        createdAt: data.createdAt,
                        templateChanges: [],
                        changesMade: false
                    }, function() {
                        const sendEstimate = {
                            estimate: t.state.estimateId,
                            finalEstimate: t.state.finalEstimate,
                            finalFunding: t.state.finalFunding
                        }
                        t.calcAPI('save-pdf', 'POST', sendEstimate)
                    })
                    break;
                case 'save-pdf':
                    t.setState({
                        pdfFilename: data,
                        savingEstimate: false
                    })
                    break;
                case 'my-permissions':
                    t.setState({
                        permissionContent: data.content,
                        permissionAdmin: data.admin,
                        permissionSuperAdmin: data.superAdmin
                    })
                    break;
            }
        })
        .catch(function(error) {
            console.log("Error: " + error);
        });
    }

    loadTemplate() {
        this.setState({
            loadingTemplate: true
        }, function() {
            this.calcAPI('template');
        });
    }

    updateClientDetails = (newDetails) => {
        /**
         * Most of this data comes from the Client page
         * Some from the Services page sidebar
         * The changesMade var changes the state on the
         * Review & Save page - forces the user to save
         * changes before they can download a new PDF
         */
        this.setState({
            clientDetails: newDetails,
            changesMade: true
        }, () => {
            this.updateMenu();
        });
    }

    updateServiceDetails = (newDetails) => {
        /**
         * This data comes from the Services page
         */
        this.setState({
            serviceDetails: newDetails,
            changesMade: true
        });
    }

    updateMenu() {
        /**
         * This function updates the main menu buttons (show/hide)
         * according to the funding type. They're now all the same,
         * but previously the private funding showed an additional
         * page for private plans, which are no longer offered.
         */
        const ft = this.state.clientDetails.fundingType;
        const services = document.getElementById('menuItemServices');
        const reviewSave = document.getElementById('menuItemReviewSave');
        if (ft == 'funded') {
            services.classList.remove('hide');
            reviewSave.classList.remove('hide');
        } else if (ft == 'private') {
            services.classList.remove('hide');
            reviewSave.classList.remove('hide');
        } else {
            services.classList.add('hide');
            reviewSave.classList.add('hide');
        }
    }

    updateSupplement = (type, selection) => {
        /**
         * This data comes from the Client page
         */
        const cd = this.state.clientDetails;
        switch(type) {
            case "dementiaCognition":
                cd.supplements.dementiaCognition.selected = !cd.supplements.dementiaCognition.selected;
                cd.supplements.veterans.selected = false;
                break;
            case "veterans":
                cd.supplements.veterans.selected = !cd.supplements.veterans.selected;
                cd.supplements.dementiaCognition.selected = false;
                break;
            case "oxygen":
                cd.supplements.oxygen.selected = !cd.supplements.oxygen.selected;
                break;
            case "enteralFeedingBolus":
                cd.supplements.enteralFeeding.selected = selection ? "enteralFeedingBolus" : "";
                break;
            case "enteralFeedingNonBolus":
                cd.supplements.enteralFeeding.selected = selection ? "enteralFeedingNonBolus" : "";
                break;
            case "mmm4":
                cd.supplements.homeCareViability.selected = selection ? "mmm4" : "";
                break;
            case "mmm5":
                cd.supplements.homeCareViability.selected = selection ? "mmm5" : "";
                break;
            case "mmm6":
                cd.supplements.homeCareViability.selected = selection ? "mmm6" : "";
                break;
            case "mmm7":
                cd.supplements.homeCareViability.selected = selection ? "mmm7" : "";
                break;
        }
        this.setState({
            clientDetails: cd,
            changesMade: true
        });
    }

    updateFirstLoad = () => {
        /**
         * When the user is logged in and opens the app on any page,
         * we'll know to do the first tasks i.e. load the template
         * and send a page view to Google Analytics if necessary.
         */
        if(this.state.firstLoad) {
            this.setState({
                firstLoad: false
            });
        }
    }

    setEstimate = (data) => {
        /**
         * Populates the calculator with an existing budget from the
         * Staff > My Estimates page
         */
        this.setState({
            estimateId: parseInt(data.id, 10),
            estimateNum: parseInt(data.estimate_number, 10),
            revision: parseInt(data.revision, 10),
            createdAt: data.createdAt,
            appVersion: data.app_version,
            templateId: parseInt(data.template_id, 10),
            clientDetails: JSON.parse(data.client),
            serviceDetails: JSON.parse(data.services),
            salesPerson: data.username,
            pdfFilename: data.filename,
            changesMade: false,
            redirectToClient: true
        }, function() {
            this.updateMenu();
        });
    }

    saveEstimate = (estimate, funding) => {
        /**
         * Saves the budget and generates a new PDF
         * Also changes the state on the Review and Save page
         * switching out the save button to the download PDF button
         */
        sendEvent("Button Clicked", "Review and Save", "Save Budget");
        this.setState({
            savingEstimate: true,
            finalEstimate: estimate,
            finalFunding: funding
        }, function() {
            const data = {
                estimateNum: this.state.estimateNum,
                createdAt: this.state.createdAt,
                templateId: this.state.templateId,
                appVersion: this.state.appVersion,
                client: this.state.clientDetails,
                services: this.state.serviceDetails
            }
            this.calcAPI('save-estimate', 'POST', data);
        });
    }

    templateVersionMismatch = () => {
        this.setState({
            mergeTemplate: true,
            loadingTemplate: true
        }, function() {
            this.calcAPI('template');
        });
    }

    dismissTemplateChanges = () => {
        this.setState({
            templateChanges: []
        });
    }

    clearRedirectToClient = () => {
        this.setState({
            redirectToClient: false
        });
    }

    templateItemSet = (item) => {
        this.setState({
            templateItemInfo: item
        });
    }

    render() {
        return (
            this.state.loadingTemplate ?
                <FullPageModal />
            :
                <Router>
                    <Header
                        clientDetails={this.state.clientDetails}
                        templateId={this.state.templateId}
                        templateIdLatest={this.state.templateIdLatest}
                        templateVersionMismatch={this.templateVersionMismatch.bind(this)}
                        templateChanges={this.state.templateChanges}
                        dismissTemplateChanges={this.dismissTemplateChanges.bind(this)}
                        templateItemSet={this.templateItemSet.bind(this)}
                        templateItemInfo={this.state.templateItemInfo}
                        permissionContent={this.state.permissionContent}
                        permissionAdmin={this.state.permissionAdmin}
                        permissionSuperAdmin={this.state.permissionSuperAdmin}
                    />
                    <div className="calc-content" id="calcContent">
                        <Route
                            exact path="/calculator"
                            render={() => <StartNew
                                firstLoad={this.state.firstLoad}
                                updateFirstLoad={this.updateFirstLoad.bind(this)}
                                loadingTemplate={this.state.loadingTemplate}
                            />}
                        />
                        <Route
                            exact path="/calculator/client"
                            render={() => <Client
                                updateClientDetails={this.updateClientDetails.bind(this)}
                                clientDetails={this.state.clientDetails}
                                updateSupplement={this.updateSupplement.bind(this)}
                                firstLoad={this.state.firstLoad}
                                updateFirstLoad={this.updateFirstLoad.bind(this)}
                                loadingTemplate={this.state.loadingTemplate}
                                redirectToClient={this.state.redirectToClient}
                                clearRedirectToClient={this.clearRedirectToClient.bind(this)}
                            />}
                        />
                        <Route
                            exact path="/calculator/services"
                            render={() => <Services
                                updateClientDetails={this.updateClientDetails.bind(this)}
                                updateServiceDetails={this.updateServiceDetails.bind(this)}
                                clientDetails={this.state.clientDetails}
                                serviceDetails={this.state.serviceDetails}
                                firstLoad={this.state.firstLoad}
                                updateFirstLoad={this.updateFirstLoad.bind(this)}
                                loadingTemplate={this.state.loadingTemplate}
                            />}
                        />
                        <Route exact path="/calculator/review-and-save"
                            render={() => <ReviewAndSave
                                estimateNum={this.state.estimateNum}
                                revision={this.state.revision}
                                createdAt={this.state.createdAt}
                                clientDetails={this.state.clientDetails}
                                serviceDetails={this.state.serviceDetails}
                                salesPerson={this.state.salesPerson}
                                userId={this.state.userId}
                                saveEstimate={this.saveEstimate.bind(this)}
                                firstLoad={this.state.firstLoad}
                                updateFirstLoad={this.updateFirstLoad.bind(this)}
                                loadingTemplate={this.state.loadingTemplate}
                                changesMade={this.state.changesMade}
                                savingEstimate={this.state.savingEstimate}
                                pdfFilename={this.state.pdfFilename}
                            />}
                        />
                        <Route exact path="/calculator/budgets"
                            render={() => <Budgets
                                firstLoad={this.state.firstLoad}
                                updateFirstLoad={this.updateFirstLoad.bind(this)}
                                loadingTemplate={this.state.loadingTemplate}
                                setEstimate={this.setEstimate.bind(this)}
                                changesMade={this.state.changesMade}
                                templateIdLatest={this.state.templateIdLatest}
                                redirectToClient={this.state.redirectToClient}
                            />}
                        />
                        {
                            this.state.permissionContent &&
                            <Route exact path="/calculator/template"
                                render={() => <Template
                                    firstLoad={this.state.firstLoad}
                                    updateFirstLoad={this.updateFirstLoad.bind(this)}
                                />}
                            />
                        }
                    </div>
                </Router>
        );
    }
}
export default withRouter(props => <Calculator {...props} />);

/**
 * If leaving the calculator prompt for unsaved changes
 */
window.onbeforeunload = function () {
    if (location.pathname.startsWith("/calculator")) {
        return 'Are you sure you want to leave?';
    } else {
        return;
    }
};

if (document.getElementById('calculator')) {
    ReactDOM.render(<Calculator />, document.getElementById('calculator'));
}
