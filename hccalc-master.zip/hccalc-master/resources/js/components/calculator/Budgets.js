import React, { Component, Fragment } from 'react';
import { Redirect } from 'react-router-dom/cjs/react-router-dom.min';
import { sendPageView } from './inc/Helpers';
import FullPageModal from './FullPageModal';
import Pagination from './Pagination';
import 'whatwg-fetch';

export default class Budgets extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loadingBudgets: true,
            loadingEstimate: false,
            loadingUsers: true,
            loadingError: false,
            loadingOverlayText: "",
            search: "",
            group: true,
            page: 1,
            pageSize: 50,
            totalResults: 0,
            user: 0,
            allUsers: null,
            noResults: false
        };
    }

    componentDidMount() {
        // Send a page view if necessary
        sendPageView(this.props.firstLoad, 'Budgets');
        this.props.updateFirstLoad();
        const postData = {
            search: this.state.search,
            group: this.state.group,
            page: this.state.page,
            selectedUser: this.state.user,
            pageSize: this.state.pageSize
        }
        this.calcAPI('budgets', false, 'POST', postData);
        this.calcAPI('all-users');
    }

    calcAPI(item, extra = false, method = 'GET', postData = null) {
        const t = this;
        let token = document.head.querySelector("[name='csrf-token'][content]").content;
        let path = item;
        if(extra) {
            path += '/' + extra;
        }
        const fetchData = {
            method: method,
            withCredentials: true,
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': token
            }
        }
        if(method === 'POST') {
            fetchData.headers["Content-Type"] = "application/json";
            fetchData.headers["Accept"] = "application/json, text-plain, */*";
            fetchData.headers["X-Requested-With"] = "XMLHttpRequest";
            fetchData.body = JSON.stringify(postData);
        }
        fetch('/calculator/api/' + path, fetchData)
        .then(response => response.json())
        .then(data => {
            if(typeof(data.error) !== "null" && data.error === 'Unauthorised') {
                t.setState({
                    loadingOverlayText: "Your session has expired. Refresh the page to login.",
                    loadingError: true
                }, function() {
                    t.setState({
                        loadingBudgets: false
                    });
                });
                return;
            }
            switch(item) {
                case 'budgets':
                    if(typeof(data.error) !== "null" && data.error === 'No results') {
                        t.setState({
                            noResults: true,
                            loadingBudgets: false
                        });
                    } else {
                        t.setState({
                            noResults: false,
                            myEstimates: data.data,
                            totalResults: data.totalResults
                        }, function() {
                            t.setState({
                                loadingBudgets: false
                            })
                        });
                    }
                    break;
                case 'load-estimate':
                    t.setState({
                        loadingEstimate: false,
                        noResults: false
                    });
                    t.props.setEstimate(data);
                    break;
                case 'all-users':
                    t.setState({
                        allUsers: data,
                        loadingUsers: false
                    });
            }
        })
        .catch(function(error) {
            console.log(error);
        });
    }

    loadEstimate(estimateId, event = false) {
        if(event) {
            event.stopPropagation();
        }
        this.setState({
            loadingEstimate: true
        }, function() {
            this.calcAPI('load-estimate', estimateId);
        });
    }

    goToPage = (p) => {
        this.setState({
            page: p,
            loadingBudgets: true
        }, function() {
            const postData = {
                search: this.state.search,
                group: this.state.group,
                page: this.state.page,
                selectedUser: this.state.user,
                pageSize: this.state.pageSize
            }
            this.calcAPI('budgets', false, 'POST', postData);
        });
    }

    handleKeyUpSearch = (e) => {
        switch(e.key) {
            case 'Enter':
                this.goToPage(1)
                break;
            case 'Escape':
                this.setState({
                    search: ""
                }, function() {
                    this.goToPage(1);
                });
        }
    }

    updateGroup = (e) => {
        this.setState({
            group: e.target.checked
        }, function() {
            this.goToPage(1);
        });
    }

    updateStaff = (e) => {
        this.setState({
            user: parseInt(e.target.value)
        }, function() {
            this.goToPage(1);
        });
    }

    render() {

        let overlayText = this.state.loadingOverlayText != "" ? this.state.loadingOverlayText : "";

        return (
            this.props.loadingTemplate || this.state.loadingEstimate || this.state.loadingError || this.state.loadingUsers ?
                <FullPageModal
                    displayText={overlayText}
                />
            :
                this.props.redirectToClient === true ?
                   <Redirect to={"/calculator/client"} />
                :
                <div className="my-estimates">
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Budgets</span>
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            {
                                this.props.changesMade &&
                                    <div>
                                        <br />
                                        <div className="notification is-danger">
                                            You have unsaved changes which will be lost if you load an estimate from the list below.
                                        </div>
                                    </div>
                            }
                            <div className="level">
                                <div className="level-left">
                                    <div className="field level-item">
                                        <div className="control has-icons-right">
                                            <input
                                                className="input"
                                                type="text"
                                                placeholder="Search"
                                                value={this.state.search}
                                                onChange={(e) => this.setState({search: e.target.value})}
                                                onKeyUp={this.handleKeyUpSearch}
                                            />
                                            <span className="icon is-right is-action" onClick={() =>
                                                this.setState({search: ""}, function() {
                                                    this.goToPage(1)
                                                })
                                            }>
                                                <i className="fa fa-times"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <div className="field level-item">
                                        <div className="control">
                                            <div className="select">
                                                <select onChange={this.updateStaff}>
                                                    <option value="0">All staff</option>
                                                    {
                                                        this.state.allUsers.map((u, i) => 
                                                            <option value={u.id} key={i}>{u.first_name + " " + u.last_name}</option>
                                                        )
                                                    }
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="field level-item">
                                        <div className="control">
                                            <span className="button" onClick={() => this.goToPage(1)}>
                                                <i className="fa fa-search"></i>
                                            </span>
                                        </div>
                                    </div>
                                    <div className="field level-item">
                                        <div className="control">
                                            <label
                                                className={this.state.search !== "" ? "checkbox has-text-grey-light is-strikethrough" : "checkbox"}
                                                title={this.state.search !== "" ? "Clear the search to use this function" : ""}
                                                disabled={this.state.search !== "" ? true : false}
                                            >
                                                <input type="checkbox" id="grouped" onChange={this.updateGroup} defaultChecked={this.state.group} disabled={this.state.search !== "" ? true : false} /> Latest revision
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {
                                this.state.loadingBudgets ?
                                    <FullPageModal displayText={"Loading budgets"} />
                                :
                                this.state.noResults ?
                                    <div className="warning">No results</div>
                                :
                                    <Fragment>
                                        <table className="table is-fullwidth is-hoverable">
                                            <thead>
                                                <tr>
                                                    <th>Client</th>
                                                    <th>Contact</th>
                                                    <th>Date</th>
                                                    <th>Budget</th>
                                                    <th>Revision</th>
                                                    <th>Staff</th>
                                                    <th className="has-text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    typeof(this.state.myEstimates) != null &&
                                                    typeof(this.state.myEstimates.error) == 'undefined' &&
                                                    this.state.myEstimates.map((item, i) => 
                                                        <tr key={i}>
                                                            <td>{item.clientName}</td>
                                                            <td>{item.contactName}</td>
                                                            <td>{item.createdAt}</td>
                                                            <td>{item.estimateNum}</td>
                                                            <td>{item.revision}</td>
                                                            <td>{item.user}</td>
                                                            <td>
                                                                <div className="buttons is-right">
                                                                    {
                                                                        item.latest !== null &&
                                                                        <button
                                                                            className="button is-small"
                                                                            title={"By " + item.latest.user}
                                                                            onClick={(e) => this.loadEstimate(item.latest.id, e)}
                                                                        >Latest rev: {item.latest.revision}</button>
                                                                    }
                                                                    <button className="button is-small" onClick={() => this.loadEstimate(item.id)}>Load</button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    )
                                                }
                                            </tbody>
                                        </table>
                                        <Pagination
                                            totalResults={this.state.totalResults}
                                            pageSize={this.state.pageSize}
                                            currentPage={this.state.page}
                                            goToPage={this.goToPage}
                                        />
                                    </Fragment>
                            }
                        </div>
                    </section>
                </div>
        );
    }
}

