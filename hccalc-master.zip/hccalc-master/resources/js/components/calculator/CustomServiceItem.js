import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class CustomServiceItem extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    updateCustomItem = (e) => {
        let csidx = parseInt(e.target.dataset.csidx, 10);
        let theType = e.target.dataset.type;
        this.props.customItem(["updateItem", theType, csidx, e.target.value]);
    }
    deleteCustomItem = (e) => {
        let csidx;
        if(e.target.tagName == 'I') {
            csidx = parseInt(e.target.parentElement.dataset.csidx, 10);
        } else {
            csidx = parseInt(e.target.dataset.csidx, 10);
        }
        this.props.customItem(["deleteItem", csidx]);
    }

    render() {

        const itemTitle = this.props.item ? this.props.item.title : "";
        const itemHours = this.props.item ? this.props.item.hours : 0;
        const itemAmount = this.props.item ? this.props.item.amount : 0;
        
        return (

            <div className="other-list-item">
                <div className="field">
                    <div className="control">
                        <input className="input item-title" type="text" data-type="itemTitle" data-csidx={this.props.csidx} onKeyUp={this.updateCustomItem} defaultValue={itemTitle} placeholder="Item name" />
                    </div>
                </div>
                <div className="field">
                    <div className="control has-icons-right">
                        <input className="input item-hours" type="text" data-type="itemHours" data-csidx={this.props.csidx} onKeyUp={this.updateCustomItem} defaultValue={itemHours} placeholder={0} />
                        <span className="icon is-small is-right">hrs</span>
                    </div>
                </div>
                <div className="field is-grouped">
                    <div className="control has-icons-left is-expanded">
                        <input className="input item-amount"  type="text" data-type="itemAmount" data-csidx={this.props.csidx} onKeyUp={this.updateCustomItem} defaultValue={itemAmount} placeholder={0} />
                        <span className="icon is-small is-left">$</span>
                    </div>
                    <div className="control">
                        <div className="icon is-medium" title="Delete item" data-type="deleteItem" data-csidx={this.props.csidx} onClick={this.deleteCustomItem}>
                            <i className="fa fa-trash" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
            </div>

        );

    }

}
