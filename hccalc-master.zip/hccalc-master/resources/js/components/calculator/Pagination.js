import React, { Fragment } from 'react';

function Pagination(props) {
    
    let totalPages = Math.ceil(props.totalResults / props.pageSize);
    let startPage = 0;
    let endPage = 0;
    let maxPages = 5;

    if (totalPages <= maxPages) {
        // total pages less than max so show all pages
        startPage = 1;
        endPage = totalPages;
    } else {
        // total pages more than max so calculate start and end pages
        let maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
        let maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
        if (props.currentPage <= maxPagesBeforeCurrentPage) {
            // current page near the start
            startPage = 1;
            endPage = maxPages;
        } else if (props.currentPage + maxPagesAfterCurrentPage >= totalPages) {
            // current page near the end
            startPage = totalPages - maxPages + 1;
            endPage = totalPages;
        } else {
            // current page somewhere in the middle
            startPage = props.currentPage - maxPagesBeforeCurrentPage;
            endPage = props.currentPage + maxPagesAfterCurrentPage;
        }
    }

    // calculate start and end item indexes
    // let startIndex = (props.currentPage - 1) * props.pageSize;
    // let endIndex = Math.min(startIndex + props.pageSize - 1, props.totalResults - 1);

    // create an array of pages to ng-repeat in the pager control
    let pages = Array.from(Array((endPage + 1) - startPage).keys()).map(i => startPage + i);

    // return object with all pager properties required by the view
    // return {
    //     pageSize: props.pageSize,
    //     totalPages: totalPages,
    //     startPage: startPage,
    //     endPage: endPage,
    //     startIndex: startIndex,
    //     endIndex: endIndex,
    //     pages: pages
    // };

    return (
        <nav className="pagination" role="navigation" aria-label="pagination">
            <button className="pagination-previous button" disabled={props.currentPage === 1 ? true : false} onClick={() => props.goToPage((props.currentPage-1))}>Previous</button>
            <button className="pagination-next button" disabled={props.currentPage === totalPages ? true : false} onClick={() => props.goToPage((props.currentPage+1))}>Next page</button>
            <ul className="pagination-list">
                {
                    startPage > 1 &&
                    <Fragment>
                        <li>
                            <span className="pagination-link" aria-label="Goto page 1" onClick={() => props.goToPage(1)}>1</span>
                        </li>
                        {
                            startPage !== 2 &&
                            <li>
                                <span className="pagination-ellipsis">&hellip;</span>
                            </li>
                        }
                    </Fragment>
                }
                {
                    pages.map((page, i) =>
                        <li key={"k"+i}>
                            <span className={page === props.currentPage ? "pagination-link is-current" : "pagination-link is-clickable"}
                                aria-label={"Goto page " + page}
                                aria-current={page === props.currentPage ? "page" : "false"}
                                onClick={() => props.goToPage(page)}
                            >{page}</span>
                        </li>
                    )
                }
                {
                    endPage < totalPages &&
                    <Fragment>
                        {
                            endPage !== (totalPages - 1) &&
                            <li>
                                <span className="pagination-ellipsis">&hellip;</span>
                            </li>
                        }
                        <li>
                            <span className="pagination-link" aria-label={"Goto page " + totalPages} onClick={() => props.goToPage(totalPages)}>{totalPages}</span>
                        </li>
                    </Fragment>
                }
            </ul>
        </nav>
    );
    
}

export default Pagination;