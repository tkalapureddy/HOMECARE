import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { PieChart, Pie, Tooltip, ResponsiveContainer } from 'recharts';
import { categoryTotalHrs } from './inc/Helpers';

export default class ServicesByTypeChart extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    getFillColor = (catClass) => {
        switch (catClass) {
            case "cat-personal-care":
                return "rgba(203,80,127,1)";
            case "cat-domestic-assistance":
                return "rgba(231,172,41,1)";
            case "cat-health-wellness":
                return "rgba(230,107,99,1)";
            case "cat-sp-health-wellness-centre":
                return "rgba(157,204,143,1)";
            case "cat-clinical-nursing":
                return "rgba(155,161,203,1)";
            case "cat-travel-social":
                return "rgba(178,69,22,1)";
            case "cat-respite":
                return "rgba(183,23,56,1)";
            case "cat-planning-management":
                return "rgba(3,88,128,1)";
            case "cat-other":
                return "rgba(121,28,94,1)";
        }
        return null;
    }

    render() {

        const data = [];
        const classes = [];

        const sdCats = this.props.serviceDetails.category;
        
        sdCats.forEach(function(cat, i) {
            let cth = categoryTotalHrs(cat);
            if(cth > 0) {
                let fillColor = this.getFillColor(cat.class);
                data.push({name: cat.name, value: cth, fill: fillColor, catClass: cat.class});
                classes.push(cat.class);
            }
        }.bind(this));

        const RADIAN = Math.PI / 180;
        const renderCustomizedLabel = ({
            cx, cy, midAngle, innerRadius, outerRadius, percent, index,
        }) => {
            const radius = innerRadius + (outerRadius - innerRadius) * 2.2;
            const x = cx + radius * Math.cos(-midAngle * RADIAN);
            const y = cy + radius * Math.sin(-midAngle * RADIAN);
            return (
                <text x={x} y={y} fill="#000000" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
                    {`${(percent * 100).toFixed(0)}%`}
                </text>
            );
        };
        const CustomTooltip = ({ active, payload }) => {
            if (active) {
                return (
                <div className={"custom-tooltip " + payload[0].payload.catClass}>
                    <div>{payload[0].name}</div>
                    <div>{payload[0].value}{payload[0].value == 1 ? " hour" : " hours"}</div>
                </div>
                );
            }
            return null;
        };
        
        return (
            <ResponsiveContainer height={250} width="100%">
                <PieChart>
                    <Pie data={data} dataKey="value" innerRadius={50} outerRadius={70} fill="#82ca9d" label={renderCustomizedLabel} isAnimationActive={false} />
                    <Tooltip content={<CustomTooltip />} />
                </PieChart>
            </ResponsiveContainer>
        );
        
    }

}
