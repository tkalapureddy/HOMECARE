import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {
    round,
    getCategoryList,
    getSupplementsList,
    weeklyTo,
    getPackageManagementWeekly,
    getCareManagementWeekly,
    sendPageView,
    getFundingList,
    sendEvent,
    thousands
} from './inc/Helpers';
import FullPageModal from './FullPageModal';

export default class ReviewAndSave extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loadingPDF: false
        };
    }

    componentDidMount() {
        // Send a page view if necessary
        sendPageView(this.props.firstLoad, 'Review and Save');
        this.props.updateFirstLoad();
    }

    downloadPDF() {
        this.setState({
            loadingPDF: true
        }, function() {
            this.calcAPI('pdf', '42');
        });
    }

    calcAPI(item, extra = false) {
        const t = this;
        let token = document.head.querySelector("[name='csrf-token'][content]").content;
        let path = item;
        if(extra) {
            path += '/' + extra;
        }
        fetch('/calculator/api/' + path, {
            method: 'GET',
            withCredentials: true,
            credentials: 'include',
            headers: {
                'X-CSRF-TOKEN': token
            }
        })
        .then(response => response.json())
        .then(data => {
            if(typeof(data.error) != null && data.error == 'Unauthorised') {
                t.setState({
                    loadingOverlayText: "Your session has expired. Refresh the page to login.",
                    loadingError: true
                }, function() {
                    t.setState({
                        loadingPDF: false
                    });
                });
                return;
            }
            switch(item) {
                case 'pdf':
                    console.log(data);
                    t.setState({
                        loadingPDF: false
                    });
                    break;
            }
        })
        .catch(function(error) {
            console.log("Error: " + error);
        });
    }

    render() {

        const categoryList = getCategoryList(this.props.serviceDetails, this.props.clientDetails);
        const supplementsList = getSupplementsList(this.props.clientDetails, true);
        
        const estimate = {
            totalHrsFtn: 0,
            totalCostFtn: 0,
            totalHrsMonth: 0,
            totalCostMonth: 0
        };
        if (categoryList) {
            estimate.categoryList = [];
            categoryList.map((cat, i) => {
                estimate.categoryList.push({
                    name: cat.name,
                    ftn: i == 0 ? "Fortnightly" : "",
                    month: i == 0 ? "Monthly" : "",
                    services: []
                });
                cat.services.map((s, x) => {
                    if(s.special == 'flatFeeMulti') {
                        estimate.categoryList[i].services.push({
                            name: s.name,
                            special: s.special,
                            serviceItems: s.serviceItems,
                            totalHrs: s.totalHrs,
                            totalCost: s.totalCost,
                            notes: s.notes,
                            selectedItems: s.selectedItems,
                            otherItems: false
                        });
                        estimate.totalHrsFtn = round(estimate.totalHrsFtn + s.totalHrsFtn, 2);
                        estimate.totalCostFtn = round(estimate.totalCostFtn + s.totalCostFtn, 2);
                        estimate.totalHrsMonth = round(estimate.totalHrsMonth + s.totalHrsMonth, 2);
                        estimate.totalCostMonth = round(estimate.totalCostMonth + s.totalCostMonth, 2);
                    } else {
                        const otherItems = s.special == 'other' ? s.otherItems : false;
                        estimate.categoryList[i].services.push({
                            name: s.name,
                            special: s.special,
                            stdHrsFtn: s.stdHrsFtn,
                            stdCostFtn: s.stdCostFtn,
                            stdHrsMonth: s.stdHrsMonth,
                            stdCostMonth: s.stdCostMonth,
                            stdVisits: s.stdVisits,
                            satAHHrsFtn: s.satAHHrsFtn,
                            satAHCostFtn: s.satAHCostFtn,
                            satAHHrsMonth: s.satAHHrsMonth,
                            satAHCostMonth: s.satAHCostMonth,
                            satAHVisits: s.satAHVisits,
                            sunHrsFtn: s.sunHrsFtn,
                            sunCostFtn: s.sunCostFtn,
                            sunHrsMonth: s.sunHrsMonth,
                            sunCostMonth: s.sunCostMonth,
                            sunVisits: s.sunVisits,
                            notes: s.notes,
                            selectedItems: s.selectedItems,
                            otherItems: otherItems
                        });
                        estimate.totalHrsFtn = round(estimate.totalHrsFtn + round(s.stdHrsFtn + s.satAHHrsFtn + s.sunHrsFtn, 2), 2);
                        estimate.totalCostFtn = round(estimate.totalCostFtn + round(s.stdCostFtn + s.satAHCostFtn + s.sunCostFtn, 2), 2);
                        estimate.totalHrsMonth = round(estimate.totalHrsMonth + round(s.stdHrsMonth + s.satAHHrsMonth + s.sunHrsMonth, 2), 2);
                        estimate.totalCostMonth = round(estimate.totalCostMonth + round(s.stdCostMonth + s.satAHCostMonth + s.sunCostMonth, 2), 2);
                    }
                });
            });
        }
        
        if (this.props.clientDetails.fundingType == "funded") {
            estimate.packageManagementFtn = weeklyTo("ftn", getPackageManagementWeekly(this.props.clientDetails));
            estimate.packageManagementMonth = weeklyTo("month", getPackageManagementWeekly(this.props.clientDetails));
            estimate.totalCostFtn = round(estimate.totalCostFtn + estimate.packageManagementFtn, 2);
            estimate.totalCostMonth = round(estimate.totalCostMonth + estimate.packageManagementMonth, 2);
            estimate.careManagementFtn = weeklyTo("ftn", getCareManagementWeekly(this.props.clientDetails));
            estimate.careManagementMonth = weeklyTo("month", getCareManagementWeekly(this.props.clientDetails));
            estimate.totalCostFtn = round(estimate.totalCostFtn + estimate.careManagementFtn, 2);
            estimate.totalCostMonth = round(estimate.totalCostMonth + estimate.careManagementMonth, 2);
        }

        const funding = getFundingList(this.props.clientDetails, supplementsList);
        funding.remainingFtn = round(funding.totalBudgetFtn - estimate.totalCostFtn, 2);
        funding.remainingMonth = round(funding.totalBudgetMonth - estimate.totalCostMonth, 2);
        funding.supplementsList = supplementsList;

        let PDFUrl = "/pdf/" + this.props.pdfFilename;
        return (
            this.props.loadingTemplate || this.props.savingEstimate || this.state.loadingPDF ?
                <FullPageModal />
            :
                <div className="review-save">
                    <div className="title-bar">
                        <div className="container">
                            <div className="columns">
                                <div className="column is-two-thirds">
                                    <span className="h3">Client details</span>
                                </div>
                                <div className="column is-one-third">
                                    <span className="h3">Home Care Budget</span>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            <div className="columns">
                                <div className="column is-one-third">
                                    <div className="cd-title">Care recipient</div>
                                    <div className="cd-name">{this.props.clientDetails.name}</div>
                                    <div className="cd-title">Address</div>
                                    <div className="cd-content">{this.props.clientDetails.address}</div>
                                    <div className="cd-title">Phone</div>
                                    <div className="cd-content">{this.props.clientDetails.phone}</div>
                                </div>
                                <div className="column is-one-third">
                                    <div className="cd-title">Contact person</div>
                                    <div className="cd-name">{this.props.clientDetails.contactName}</div>
                                    <div className="cd-title">Address</div>
                                    <div className="cd-content">{this.props.clientDetails.contactAddress}</div>
                                    <div className="cd-title">Phone</div>
                                    <div className="cd-content">{this.props.clientDetails.contactPhone}</div>
                                </div>
                                <div className="column is-one-third">
                                    <div className="hide-for-print">
                                        <div className="cd-title">Save</div>
                                        {
                                            this.props.changesMade ?
                                                <div className="buttons">
                                                    <span className="button is-primary" onClick={() => this.props.saveEstimate(estimate, funding)}>
                                                        <span className="icon is-small">
                                                            <i className="fas fa-save"></i>
                                                        </span>
                                                        <span>Save</span>
                                                    </span>
                                                </div>
                                            :
                                                <div className="cd-content">Saved</div>
                                        }
                                        
                                        <div className="cd-title">Download</div>
                                        {
                                            this.props.changesMade ?
                                                <div className="cd-content save-first">Save changes to download</div>
                                            :
                                                <React.Fragment>
                                                    <a className="button is-primary" href={PDFUrl} download>
                                                        <span className="icon is-small">
                                                            <i className="fas fa-file-pdf"></i>
                                                        </span>
                                                        <span>Download PDF</span>
                                                    </a>
                                                    <br /><br />
                                                </React.Fragment>
                                        }
                                    </div>
                                    <div className="cd-content">
                                        Document #: {this.props.estimateNum}<br/>
                                        Revision #: {this.props.revision}<br/>
                                        Date: {this.props.createdAt}
                                    </div>
                                    <div className="cd-title">Prepared by</div>
                                    <div className="cd-content">{this.props.salesPerson}</div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Funding</span>
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            <table className="table is-fullwidth" id="funding-table">
                                <tbody>
                                    <tr className="category-name">
                                        <td colSpan="2">All funding</td>
                                        <td>Fortnightly</td>
                                        <td>Monthly</td>
                                    </tr>
                                    <tr>
                                        <td>Funding type</td>
                                        <td>{
                                            this.props.clientDetails.fundingType == "funded" ?
                                                <span>HCP {"Level " + this.props.clientDetails.fundingLevel}</span>
                                                :
                                                <span>Private</span>
                                        }</td>
                                        <td>{
                                            this.props.clientDetails.fundingType == "funded" ?
                                                <span>${thousands(funding.hcpFtn.toFixed(2))}</span>
                                                :
                                                <span>${thousands(funding.totalBudgetFtn.toFixed(2))}</span>
                                        }</td>
                                        <td>{
                                            this.props.clientDetails.fundingType == "funded" ?
                                                <span>${thousands(funding.hcpMonth.toFixed(2))}</span>
                                                :
                                                <span>${thousands(funding.totalBudgetMonth.toFixed(2))}</span>
                                        }</td>
                                    </tr>
                                    {
                                        this.props.clientDetails.fundingType == "funded" && supplementsList[0].length > 0 &&
                                        <tr>
                                            <td>Supplements</td>
                                            <td>
                                                <ul>
                                                    {supplementsList[0].map((s, i) =>
                                                        <li key={i}>{"" + s}</li>
                                                    )}
                                                </ul>
                                            </td>
                                            <td>${funding.supplementsFtn.toFixed(2)}</td>
                                            <td>${funding.supplementsMonth.toFixed(2)}</td>
                                        </tr>
                                    }
                                    {
                                        this.props.clientDetails.fundingType == "funded" &&
                                        <React.Fragment>
                                            <tr>
                                                <td>Top up</td>
                                                <td></td>
                                                <td>${thousands(funding.topUpFtn.toFixed(2))}</td>
                                                <td>${thousands(funding.topUpMonth.toFixed(2))}</td>
                                            </tr>
                                            <tr>
                                                <td>Basic daily fee</td>
                                                <td></td>
                                                <td>${thousands(funding.basicDailyFeeFtn.toFixed(2))}</td>
                                                <td>${thousands(funding.basicDailyFeeMonth.toFixed(2))}</td>
                                            </tr>
                                            <tr>
                                                <td>Income tested fee</td>
                                                <td></td>
                                                <td>${thousands(funding.incomeTestedFeeFtn.toFixed(2))}</td>
                                                <td>${thousands(funding.incomeTestedFeeMonth.toFixed(2))}</td>
                                            </tr>
                                        </React.Fragment>
                                    }
                                    <tr className="category-name">
                                        <td colSpan="2">Total</td>
                                        <td>Fortnightly</td>
                                        <td>Monthly</td>
                                    </tr>
                                    {
                                        this.props.clientDetails.fundingType == "funded" &&
                                        <React.Fragment>
                                            <tr>
                                                <td>Amount you pay</td>
                                                <td></td>
                                                <td>${thousands(funding.amountYouPayFtn.toFixed(2))}</td>
                                                <td>${thousands(funding.amountYouPayMonth.toFixed(2))}</td>
                                            </tr>
                                            <tr>
                                                <td>Amount government pays</td>
                                                <td></td>
                                                <td>${thousands(funding.amountGovPayFtn.toFixed(2))}</td>
                                                <td>${thousands(funding.amountGovPayMonth.toFixed(2))}</td>
                                            </tr>
                                        </React.Fragment>
                                    }
                                    <tr className={funding.remainingFtn < 0 ? "has-background-danger" : "total"}>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>Total budget</td>
                                        <td>{
                                            funding.remainingFtn < 0 &&
                                            <span className="tag is-white"><span className="icon has-text-warning"><i className="fas fa-exclamation-triangle"></i></span>&nbsp;You have gone over budget!</span>
                                        }</td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>${thousands(funding.totalBudgetFtn.toFixed(2))}</td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>${thousands(funding.totalBudgetMonth.toFixed(2))}</td>
                                    </tr>
                                    <tr className={funding.remainingFtn < 0 ? "remaining-bad" : "remaining-good"}>
                                        <td>Remaining</td>
                                        <td></td>
                                        <td>${thousands(funding.remainingFtn.toFixed(2))}</td>
                                        <td>${thousands(funding.remainingMonth.toFixed(2))}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Home Care to be provided</span>
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            <table className="table is-fullwidth" id="estimate-table">
                                <tbody>
                                    {
                                        estimate.categoryList &&
                                            estimate.categoryList.map((cat,i) =>
                                                <React.Fragment key={i}>
                                                    <tr className="category-name">
                                                        <td>{cat.name}</td>
                                                        <td colSpan="2">{cat.ftn}</td>
                                                        <td colSpan="2">{cat.month}</td>
                                                    </tr>
                                                    {
                                                        cat.services.map((s,x) => 
                                                            s.special == 'other' || s.special == 'flatFeeMulti' ?
                                                                s.special == 'other' ?
                                                                    s.otherItems.map((o, i) =>
                                                                        <tr key={o.key}>
                                                                            <td>{o.title}</td>
                                                                            <td>{o.hours > 0 && thousands(weeklyTo('ftn', o.hours, true)) + " hrs"}</td>
                                                                            <td>${thousands(weeklyTo('ftn', o.amount, true))}</td>
                                                                            <td>{o.hours > 0 && thousands(weeklyTo('month', o.hours, true)) + " hrs"}</td>
                                                                            <td>${thousands(weeklyTo('month', o.amount, true))}</td>
                                                                        </tr>
                                                                    )
                                                                :
                                                                    s.serviceItems.map((si, d) =>
                                                                        <tr key={d}>
                                                                            <td>{s.name + " - " + si.name}</td>
                                                                            <td>{si.hrsFtn.toFixed(2)} hrs</td>
                                                                            <td>${thousands(si.costFtn.toFixed(2))}</td>
                                                                            <td>{si.hrsMonth.toFixed(2)} hrs</td>
                                                                            <td>${thousands(si.costMonth.toFixed(2))}</td>
                                                                        </tr>
                                                                    )
                                                            :
                                                                <React.Fragment key={x}>
                                                                    {
                                                                        s.stdHrsFtn > 0 &&
                                                                        <tr>
                                                                            <td>{s.name} {s.special == "respiteCentre" && "(Day)"}</td>
                                                                            <td>{s.stdHrsFtn.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.stdCostFtn.toFixed(2))}</td>
                                                                            <td>{s.stdHrsMonth.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.stdCostMonth.toFixed(2))}</td>
                                                                        </tr>
                                                                    }
                                                                    {
                                                                        s.satAHHrsFtn > 0 &&
                                                                        <tr>
                                                                            <td>{s.name} {s.special == "respiteCentre" ? "(Overnight)" : "(Sat or A/H)"}</td>
                                                                            <td>{s.satAHHrsFtn.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.satAHCostFtn.toFixed(2))}</td>
                                                                            <td>{s.satAHHrsMonth.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.satAHCostMonth.toFixed(2))}</td>
                                                                        </tr>
                                                                    }
                                                                    {
                                                                        s.sunHrsFtn > 0 &&
                                                                        <tr>
                                                                            <td>{s.name} {s.special == "respiteCentre" ? "(Overnight Weekend)" : "(Sun)"}</td>
                                                                            <td>{s.sunHrsFtn.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.sunCostFtn.toFixed(2))}</td>
                                                                            <td>{s.sunHrsMonth.toFixed(2)} hrs</td>
                                                                            <td>${thousands(s.sunCostMonth.toFixed(2))}</td>
                                                                        </tr>
                                                                    }  
                                                                </React.Fragment>
                                                            )
                                                    }
                                                </React.Fragment>
                                            )
                                    }
                                    {
                                        this.props.clientDetails.fundingType == "funded" &&
                                        <React.Fragment>
                                            <tr className="category-name">
                                                <td>Planning &amp; management</td>
                                                <td colSpan="2"></td>
                                                <td colSpan="2"></td>
                                            </tr>
                                            <tr>
                                                <td>Package management</td>
                                                <td></td>
                                                <td>${thousands(estimate.packageManagementFtn.toFixed(2))}</td>
                                                <td></td>
                                                <td>${thousands(estimate.packageManagementMonth.toFixed(2))}</td>
                                            </tr>
                                            {
                                                estimate.careManagementFtn > 0 &&
                                                <tr>
                                                    <td>Care management</td>
                                                    <td></td>
                                                    <td>${thousands(estimate.careManagementFtn.toFixed(2))}</td>
                                                    <td></td>
                                                    <td>${thousands(estimate.careManagementMonth.toFixed(2))}</td>
                                                </tr>
                                            }
                                        </React.Fragment>
                                    }
                                    <tr className="category-name">
                                        <td>TOTAL</td>
                                        <td colSpan="2">Fortnightly</td>
                                        <td colSpan="2">Monthly</td>
                                    </tr>
                                    <tr className={funding.remainingFtn < 0 ? "has-background-danger" : "total"}>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>
                                            All services
                                            {
                                                funding.remainingFtn < 0 &&
                                                <span className="tag is-white"><span className="icon has-text-warning"><i className="fas fa-exclamation-triangle"></i></span>&nbsp;You have gone over budget!</span>
                                            }
                                        </td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>{estimate.totalHrsFtn.toFixed(2)} hrs</td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>${thousands(estimate.totalCostFtn.toFixed(2))}</td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>{estimate.totalHrsMonth.toFixed(2)} hrs</td>
                                        <td className={funding.remainingFtn < 0 ? "has-text-white" : ""}>${thousands(estimate.totalCostMonth.toFixed(2))}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                    <section className="section">
                        <div className="container">
                            <p>If you need help to understand this document please don't hesitate to contact our friendly team on 1300 000 161.</p>
                            <p>We will review and, if necessary, revise this budget if:</p>
                            <ol type="a" className="standard-list">
                                <li>a change to the care and services to be provided is proposed; or</li>
                                <li>the costs of providing the care and services change; or</li>
                                <li>you request a revision</li>
                            </ol>
                            <p>You will be provided with a revised copy of the budget if any changes are made.</p>
                            {
                                this.props.clientDetails.fundingType == "funded" &&
                                    <div>
                                        <h4 className="is-size-5">Care Fees</h4>
                                        <p>The My Aged Care Fee Estimator may have been utilised to provide you with an estimate of fees (basic daily fee &amp; income tested fee) for your Home Care Package. This estimate is based on the information you provided and should be utilised as a guide for your general information only.</p>
                                        <p>The actual amount of fees payable will depend on your personal situation, the time you enter care, the information you provide to the relevant Australian Government Departments and your personal and financial information at the time of the assessment.</p>
                                        <p>You should consider obtaining independent legal, financial, taxation or other advice to check how the My Aged Care website information relates to your particular circumstances.</p>
                                    </div>
                            }
                        </div>
                    </section>
                    <section className="section is-medium hide-for-print">
                        <div className="container">
                            <p>&nbsp;</p>
                        </div>
                    </section>
                </div>
        );
    }
}
