import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class FullPageModal extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    render() {
        let displayText = this.props.displayText ? this.props.displayText : 'Loading...';
        return (
            <div className="overlay">
                <div className="overlay-content">
                    {displayText}
                </div>
            </div>
        );
    }
}
