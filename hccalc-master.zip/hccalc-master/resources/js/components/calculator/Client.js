import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { sendPageView } from './inc/Helpers';

export default class Client extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        // Send a page view to Google Analytics if necessary
        sendPageView(this.props.firstLoad, 'Client Details');
        this.props.updateFirstLoad();
        this.props.clearRedirectToClient();
    }

    updateClient = (e) => {
        let cd = this.props.clientDetails;
        const val = e.target.value;
        switch (e.target.id) {
            case 'salesName':
                cd.salesName = val;
                break;
            case 'clientName':
                cd.name = val;
                break;
            case 'clientPhone':
                cd.phone = val;
                break;
            case 'clientAddress':
                cd.address = val;
                break;
            case 'clientContactName':
                cd.contactName = val;
                break;
            case 'clientContactPhone':
                cd.contactPhone = val;
                break;
            case 'clientContactAddress':
                cd.contactAddress = val;
                break;
            case 'fundingType':
                cd.fundingType = val;
                break;
            case 'fundingLevel':
                cd.fundingLevel = parseInt(val);
                break;
        }
        this.props.updateClientDetails(cd);
    }

    checkFunded() {
        return this.props.clientDetails.fundingType == "funded" ? "show" : "hide";
    }

    updateSupplement = (type, selection = false) => {
        // Make sure there are no double-ups
        // This is just visually unchecking checkboxes
        // as the dom is not re-rendered
        switch(type) {
            case "dementiaCognition":
                document.getElementById("veterans").checked = false;
                break;
            case "veterans":
                document.getElementById("dementiaCognition").checked = false;
                break;
            case "enteralFeedingBolus":
                selection = document.getElementById("enteralFeedingBolus").checked;
                document.getElementById("enteralFeedingNonBolus").checked = false;
                break;
            case "enteralFeedingNonBolus":
                selection = document.getElementById("enteralFeedingNonBolus").checked;
                document.getElementById("enteralFeedingBolus").checked = false;
                break;
            case "mmm4":
                selection = document.getElementById("mmm4").checked;
                document.getElementById("mmm5").checked = false;
                document.getElementById("mmm6").checked = false;
                document.getElementById("mmm7").checked = false;
                break;
            case "mmm5":
                selection = document.getElementById("mmm5").checked;
                document.getElementById("mmm4").checked = false;
                document.getElementById("mmm6").checked = false;
                document.getElementById("mmm7").checked = false;
                break;
            case "mmm6":
                selection = document.getElementById("mmm6").checked;
                document.getElementById("mmm4").checked = false;
                document.getElementById("mmm5").checked = false;
                document.getElementById("mmm7").checked = false;
                break;
            case "mmm7":
                selection = document.getElementById("mmm7").checked;
                document.getElementById("mmm4").checked = false;
                document.getElementById("mmm5").checked = false;
                document.getElementById("mmm6").checked = false;
                break;
        }
        this.props.updateSupplement(type, selection);
    }

    render() {
        let cd = this.props.clientDetails;
        return (
            this.props.loadingTemplate ?
                <div className="loading">Loading...</div>
            :
                <div className="client">
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Client details</span>
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            <div className="columns">
                                <div className="column is-one-third">
                                    <h4>Care recipient</h4>
                                    <div className="field">
                                        <label className="label">Name</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientName" onKeyUp={this.updateClient} defaultValue={cd.name} autoComplete="off" />
                                        </div>
                                    </div>
                                    <div className="field">
                                        <label className="label">Phone</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientPhone" onKeyUp={this.updateClient} defaultValue={cd.phone} autoComplete="off" />
                                        </div>
                                    </div>
                                    <div className="field">
                                        <label className="label">Address</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientAddress" onKeyUp={this.updateClient} defaultValue={cd.address} autoComplete="off" />
                                        </div>
                                    </div>
                                </div>
                                <div className="column is-one-third">
                                    <h4>Contact Person</h4>
                                    <div className="field">
                                        <label className="label">Name</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientContactName" onKeyUp={this.updateClient} defaultValue={cd.contactName} autoComplete="off" />
                                        </div>
                                    </div>
                                    <div className="field">
                                        <label className="label">Phone</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientContactPhone" onKeyUp={this.updateClient} defaultValue={cd.contactPhone} autoComplete="off" />
                                        </div>
                                    </div>
                                    <div className="field">
                                        <label className="label">Address</label>
                                        <div className="control">
                                            <input type="text" className="input" id="clientContactAddress" onKeyUp={this.updateClient} defaultValue={cd.contactAddress} autoComplete="off" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <div className="title-bar">
                        <div className="container">
                            <span className="h3">Funding</span>
                        </div>
                    </div>
                    <section className="section">
                        <div className="container">
                            <div className="columns">
                                <div className="column is-one-third">
                                    <h4>Funding</h4>
                                    <label className="label">Choose funding type</label>
                                    <div className="select">
                                        <select id="fundingType" onChange={this.updateClient} defaultValue={cd.fundingType}>
                                            <option value="">Please select</option>
                                            <option value="funded">Home Care Package</option>
                                            <option value="private">Private</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="column is-one-third">
                                    <div className={this.checkFunded()}>
                                        <h4>Approved package</h4>
                                        <label className="label">Choose package level</label>
                                        <div className="select">
                                            <select id="fundingLevel" onChange={this.updateClient} defaultValue={cd.fundingLevel}>
                                                <option value="1">Level 1</option>
                                                <option value="2">Level 2</option>
                                                <option value="3">Level 3</option>
                                                <option value="4">Level 4</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div className="column is-one-third">
                                    <div className={this.checkFunded()}>
                                        <h4>Supplements</h4>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="dementiaCognition" onChange={() => this.updateSupplement("dementiaCognition")} defaultChecked={cd.supplements.dementiaCognition.selected} /> Dementia &amp; Cognition
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="veterans" onChange={() => this.updateSupplement("veterans")} defaultChecked={cd.supplements.veterans.selected} /> Veterans'
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="oxygen" onChange={() => this.updateSupplement("oxygen")} defaultChecked={cd.supplements.oxygen.selected} /> Oxygen
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="enteralFeedingBolus" onChange={() => this.updateSupplement("enteralFeedingBolus")} defaultChecked={cd.supplements.enteralFeeding.selected == "enteralFeedingBolus" ? true : false} /> Enteral Feeding - Bolus
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="enteralFeedingNonBolus" onChange={() => this.updateSupplement("enteralFeedingNonBolus")} defaultChecked={cd.supplements.enteralFeeding.selected == "enteralFeedingNonBolus" ? true : false} /> Enteral Feeding - Non-Bolus
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="mmm4" onChange={() => this.updateSupplement("mmm4")} defaultChecked={cd.supplements.homeCareViability.selected == "mmm4" ? true : false} /> Home Care Viability - MMM4
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="mmm5" onChange={() => this.updateSupplement("mmm5")} defaultChecked={cd.supplements.homeCareViability.selected == "mmm5" ? true : false} /> Home Care Viability - MMM5
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="mmm6" onChange={() => this.updateSupplement("mmm6")} defaultChecked={cd.supplements.homeCareViability.selected == "mmm6" ? true : false} /> Home Care Viability - MMM6
                                                </label>
                                            </div>
                                        </div>
                                        <div className="field">
                                            <div className="control">
                                                <label className="checkbox">
                                                    <input type="checkbox" id="mmm7" onChange={() => this.updateSupplement("mmm7")} defaultChecked={cd.supplements.homeCareViability.selected == "mmm7" ? true : false} /> Home Care Viability - MMM7
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section className="section is-medium hide-for-print">
                        <div className="container">
                            <p>&nbsp;</p>
                        </div>
                    </section>
                </div>
        );
    }
}
