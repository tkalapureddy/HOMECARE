import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class HourSelector extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    hrsTextSize = (top) => {
        if(top) {
            if (this.props.type == "stdFrequency" || this.props.type == "satAHFrequency" || this.props.type == "sunFrequency" || this.props.type == "flatFrequency") {
                return "small";
            } else {
                return "big";
            }
        } else {
            if (this.props.type == "stdFrequency" || this.props.type == "satAHFrequency" || this.props.type == "sunFrequency" || this.props.type == "flatFrequency") {
                return "big";
            } else {
                return "small";
            }
        }
    }

    hrsText = (top) => {
        const c = this.props.serviceModal ? this.props.serviceModal.category : false;
        const s = this.props.serviceModal ? this.props.serviceModal.service : false;
        const theService = this.props.serviceDetails ? this.props.serviceDetails.category[c].services[s] : false;
        switch(this.props.type) {
            case "stdFrequency":
                if(top) {
                    return (theService.stdQtyVisits == 1 ? "VISIT PER" : "VISITS PER");
                } else {
                    return theService.stdVisitFrequency.toUpperCase();
                }
            case "stdPerVisit":
                if(top) {
                    return (theService.stdHrsPerVisit == 1 ? "HOUR" : "HOURS");
                } else {
                    return "PER VISIT";
                }
            case "satAHFrequency":
                if (top) {
                    return (theService.satAHQtyVisits == 1 ? "VISIT PER" : "VISITS PER");
                } else {
                    return theService.satAHVisitFrequency.toUpperCase();
                }
            case "satAHPerVisit":
                if(top) {
                    return (theService.satAHHrsPerVisit == 1 ? "HOUR" : "HOURS");
                } else {
                    return "PER VISIT";
                }
            case "sunFrequency":
                if (top) {
                    return (theService.sunQtyVisits == 1 ? "VISIT PER" : "VISITS PER");
                } else {
                    return theService.sunVisitFrequency.toUpperCase();
                }
            case "sunPerVisit":
                if(top) {
                    return (theService.sunHrsPerVisit == 1 ? "HOUR" : "HOURS");
                } else {
                    return "PER VISIT";
                }
            case "flatFrequency":
                if(top) {
                    return (theService["type" + this.props.idx + "QtyVisits"] == 1 ? "VISIT PER" : "VISITS PER");
                } else {
                    return theService["type" + this.props.idx + "VisitFrequency"].toUpperCase();
                }
        }
    }

    hrsNum = () => {
        const c = this.props.serviceModal ? this.props.serviceModal.category : false;
        const s = this.props.serviceModal ? this.props.serviceModal.service : false;
        const theService = this.props.serviceDetails ? this.props.serviceDetails.category[c].services[s] : false;
        switch(this.props.type) {
            case "stdFrequency":
                return theService.stdQtyVisits;
            case "stdPerVisit":
                return theService.stdHrsPerVisit;
            case "satAHFrequency":
                return theService.satAHQtyVisits;
            case "satAHPerVisit":
                return theService.satAHHrsPerVisit;
            case "sunFrequency":
                return theService.sunQtyVisits;
            case "sunPerVisit":
                return theService.sunHrsPerVisit;
            case "flatFrequency":
                return theService["type" + this.props.idx + "QtyVisits"];
        }
    }

    change = (increase) => {
        let idx = typeof(this.props.idx) !== undefined ? this.props.idx : false;
        const data = {
            increase: increase,
            type: this.props.type,
            idx: idx
        }
        this.props.updateHrs(data);
    }

    render() {
        
        return (
            <div className={"service-section-hrs" + (this.props.pos ? " is-pulled-" + this.props.pos : "")}>
                {
                    this.props.showTitle &&
                    <span className="hrs-title">
                        {this.props.showTitle}
                    </span>
                }
                <div className="hrs-block">
                    <div className="hrs-btns">
                        <div className="hrs-btn-up">
                            <span className="icon has-text-white" onClick={() => this.change(true)}>
                                <i className="fas fa-2x fa-angle-up"></i>
                            </span>
                        </div>
                        <div className="hrs-btn-down">
                            <span className="icon has-text-white" onClick={() => this.change(false)}>
                                <i className="fas fa-2x fa-angle-down"></i>
                            </span>
                        </div>
                    </div>
                    <div className="hrs-box">
                        <div className="hrs-box-content">
                            <div className="hrs-text-box is-pulled-right">
                                <div className={"hrs-text-box-top hrs-text-" + this.hrsTextSize(true)}>
                                    {this.hrsText(true)}
                                </div>
                                <div className={"hrs-text-box-bottom hrs-text-" + this.hrsTextSize(false)}>
                                    {this.hrsText(false)}
                                </div>
                            </div>
                            <div className="hrs-number">
                                {this.hrsNum()}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
