import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ServicesByTypeChart from './ServicesByTypeChart';
import {
    round,
    getCategoryList,
    getSupplementsList,
    getBasicDailyFee,
    dailyTo,
    getPackageManagementWeekly,
    getCareManagementWeekly,
    thousands
} from './inc/Helpers';

export default class ServicesSidebar extends Component {

    constructor(props) {
        super(props);
        this.state = {
            serviceModal: {
                active: false,
                category: 0,
                service: 0
            }
        };
    }

    updateClient = (e) => {
        let cd = this.props.clientDetails;
        const val = e.target.value;
        switch (e.target.id) {
            case 'contribution':
                cd.contribution = parseFloat(val) > 0 ? round(parseFloat(val), 2) : 0;
                break;
            case 'basicDailyFeePercent':
                cd.basicDailyFeePercent = parseInt(val);
                break;
            case 'incomeTestedFee':
                cd.incomeTestedFee = parseFloat(val) > 0 ? round(parseFloat(val), 2) : 0;
                break;
            case 'careManagement':
                cd.careManagementFullyManaged = !cd.careManagementFullyManaged;
                break;
        }
        this.props.updateClientDetails(cd);
    }

    render() {
        const categoryList = getCategoryList(this.props.serviceDetails, this.props.clientDetails);
        const supplementsList = getSupplementsList(this.props.clientDetails);

        const estimate = {
            totalHrsWeek: 0,
            totalCostWeek: 0
        };
        if (categoryList) {
            categoryList.map((cat, i) => {
                cat.services.map((s, x) => {
                    if(s.special == "flatFeeMulti") {
                        estimate.totalHrsWeek = round(estimate.totalHrsWeek + round(s.totalHrs, 2), 2);
                        estimate.totalCostWeek = round(estimate.totalCostWeek + round(s.totalCost, 2), 2);
                    } else {
                        estimate.totalHrsWeek = round(estimate.totalHrsWeek + round(s.stdHrs + s.satAHHrs + s.sunHrs, 2), 2);
                        estimate.totalCostWeek = round(estimate.totalCostWeek + round(s.stdCost + s.satAHCost + s.sunCost, 2), 2);
                    }
                });
            });
        }
        if (this.props.clientDetails.fundingType == "funded") {
            estimate.packageManagementWeek = getPackageManagementWeekly(this.props.clientDetails);
            estimate.totalCostWeek = round(estimate.totalCostWeek + estimate.packageManagementWeek, 2);
            estimate.careManagementWeek = getCareManagementWeekly(this.props.clientDetails);
            estimate.totalCostWeek = round(estimate.totalCostWeek + estimate.careManagementWeek, 2);
        }

        const funding = {};
        if (this.props.clientDetails.fundingType == "funded") {
            funding.basicDailyFeeWeek = dailyTo("week", getBasicDailyFee(this.props.clientDetails));
            funding.incomeTestedFeeWeek = dailyTo("week", this.props.clientDetails.incomeTestedFee);
            funding.hcpWeek = this.props.clientDetails["level" + this.props.clientDetails.fundingLevel + "Weekly"] - funding.incomeTestedFeeWeek;
            funding.amountYouPay = round(this.props.clientDetails.contribution + funding.basicDailyFeeWeek + funding.incomeTestedFeeWeek, 2);
            funding.amountGovPay = round(funding.hcpWeek + supplementsList[1], 2);
            funding.totalBudget = round(funding.amountYouPay + funding.amountGovPay, 2);
        } else {
            funding.totalBudget = this.props.clientDetails.contribution;
        }
        funding.remaining = round(funding.totalBudget - estimate.totalCostWeek, 2);

        return (
            <React.Fragment>
                <div className="total-weekly-box">
                    <div className="is-clearfix">
                        <div className="is-size-4 is-pulled-left is-marginless">{estimate.totalHrsWeek}{estimate.totalHrsWeek == 1 ? " hour" : " hours"}</div>
                        <div className="is-size-4 is-pulled-right is-marginless">${thousands(estimate.totalCostWeek.toFixed(2))}</div>
                    </div>
                    <div className="twb-divider"></div>
                    <div className="has-text-centered">Services Total weekly</div>
                </div>
                <table className="table is-fullwidth funding-table">
                    <tbody>
                        <tr className="category-name">
                            <td colSpan="2">Funding</td>
                            <td className="has-text-right">weekly</td>
                        </tr>
                        <tr>
                            <td>Funding type</td>
                            <td>{
                                this.props.clientDetails.fundingType == "funded" ?
                                    <span>HCP {"Level " + this.props.clientDetails.fundingLevel}</span>
                                    :
                                    <span>Private</span>
                            }</td>
                            <td>{
                                this.props.clientDetails.fundingType == "funded" ?
                                    <span>${thousands(funding.hcpWeek.toFixed(2))}</span>
                                    :
                                    <span></span>
                            }</td>
                        </tr>
                        {
                            this.props.clientDetails.fundingType == "funded" && supplementsList[0].length > 0 &&
                            <tr>
                                <td>Supplements</td>
                                <td>
                                    <ul>
                                        {supplementsList[0].map((s, i) =>
                                            <li key={i}>{"" + s}</li>
                                        )}
                                    </ul>
                                </td>
                                <td>${thousands(supplementsList[1].toFixed(2))}</td>
                            </tr>
                        }
                        <tr>
                            <td>{this.props.clientDetails.fundingType == "funded" ? "Top up" : "Budget"}</td>
                            <td></td>
                            <td>
                                <div className="field">
                                    <p className="control has-icons-left is-marginless">
                                        <input className="input" type="text" id="contribution" onKeyUp={this.updateClient} defaultValue={this.props.clientDetails.contribution} autoComplete="off" />
                                        <span className="icon is-small is-left">$</span>
                                    </p>
                                </div>
                            </td>
                        </tr>
                        {
                            this.props.clientDetails.fundingType == "funded" &&
                            <React.Fragment>
                                <tr>
                                    <td>Basic daily fee ${this.props.clientDetails.basicDailyFeeDaily["level" + this.props.clientDetails.fundingLevel]}</td>
                                    <td>
                                        <div className="select">
                                            <select id="basicDailyFeePercent" onChange={this.updateClient} defaultValue={this.props.clientDetails.basicDailyFeePercent}>
                                                <option value="100">100%</option>
                                                <option value="50">50%</option>
                                                <option value="0">0%</option>
                                            </select>
                                        </div>
                                    </td>
                                    <td>${funding.basicDailyFeeWeek.toFixed(2)}</td>
                                </tr>
                                <tr>
                                    <td>Income tested fee</td>
                                    <td>
                                        <div className="field">
                                            <label className="label">Daily amt</label>
                                            <p className="control has-icons-left is-marginless">
                                                <input className="input" type="text" id="incomeTestedFee" onKeyUp={this.updateClient} defaultValue={this.props.clientDetails.incomeTestedFee} autoComplete="off" />
                                                <span className="icon is-small is-left">$</span>
                                            </p>
                                        </div>
                                    </td>
                                    <td>${thousands(funding.incomeTestedFeeWeek.toFixed(2))}</td>
                                </tr>
                            </React.Fragment>
                        }
                        <tr className="category-name">
                            <td colSpan="2">Totals</td>
                            <td className="has-text-right">weekly</td>
                        </tr>
                        {
                            this.props.clientDetails.fundingType == "funded" &&
                            <React.Fragment>
                                <tr>
                                    <td colSpan="2">Amount you pay</td>
                                    <td>${thousands(funding.amountYouPay.toFixed(2))}</td>
                                </tr>
                                <tr>
                                    <td colSpan="2">Amount government pays</td>
                                    <td>${thousands(funding.amountGovPay.toFixed(2))}</td>
                                </tr>
                            </React.Fragment>
                        }
                        <tr className={funding.remaining < 0 ? "has-background-danger has-text-white warning" : "total"}>
                            <td colSpan="2">Total budget</td>
                            <td>${thousands(funding.totalBudget.toFixed(2))}</td>
                        </tr>
                        <tr className={funding.remaining < 0 ? "remaining-bad" : "remaining-good"}>
                            <td>Remaining</td>
                            <td></td>
                            <td>${thousands(funding.remaining.toFixed(2))}</td>
                        </tr>
                        {
                            this.props.clientDetails.fundingType == "funded" &&
                            <React.Fragment>
                                <tr className="category-name">
                                    <td colSpan="2">Management</td>
                                    <td className="has-text-right">weekly</td>
                                </tr>
                                <tr>
                                    <td colSpan="2">Package management</td>
                                    <td>${thousands(estimate.packageManagementWeek.toFixed(2))}</td>
                                </tr>
                                <tr>
                                    <td>Care management</td>
                                    <td>
                                        <div className="select">
                                            <select id="careManagement" onChange={this.updateClient} defaultValue={this.props.clientDetails.careManagementFullyManaged ? "fullyManaged" : "selfManaged"}>
                                                <option value="fullyManaged">Fully Managed</option>
                                                <option value="selfManaged">Self Managed</option>
                                            </select>
                                        </div>
                                    </td>
                                    <td>${thousands(estimate.careManagementWeek.toFixed(2))}</td>
                                </tr>
                            </React.Fragment>
                        }
                    </tbody>
                </table>
                {
                    estimate.totalHrsWeek > 0 &&
                    <div>
                        <h4>Hours by type</h4>
                        <ServicesByTypeChart
                            serviceDetails={this.props.serviceDetails}
                        />
                    </div>
                }
            </React.Fragment>
        );
    }

}
