import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class RemoveServiceIcon extends Component {

    constructor(props) {
        super(props);
        this.state = {
        };
    }

    removeService = (e) => {
        e.stopPropagation();
        const data = {
            category: this.props.categoryKey,
            service: this.props.serviceKey
        }
        this.props.updateService("onOff", data);
    }

    render() {

        return(
            <i className="fas fa-minus-square is-pulled-right" onClick={this.removeService} alt="Remove" title="Remove"></i>
        )

    }

}
