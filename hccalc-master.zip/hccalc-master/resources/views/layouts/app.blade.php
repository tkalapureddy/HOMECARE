<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @if(config('app.env') == 'production')
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-143329837-1"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'UA-143329837-1');
        </script>
    @endif
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="author" content="Paul Groth">
    <title>{{ __('common.app-name') }}</title>
    <script src="{{ mix('js/app.js') }}" defer></script>
    <link href="{{ mix('css/app.css') }}" rel="stylesheet">
</head>
<body>
    @if(config('app.env') != 'production')
        <div class="{{ config('app.env') }}">
            You are in the {{ strtoupper(config('app.env')) }} environment
        </div>
    @endif
    <div id="app">
        @include('inc.navbar')
        @include('inc.messages')
        @yield('content')
    </div>
</body>
</html>
