@extends('layouts.app')

@section('content')
    <section class="section has-border-top">
        <div class="container">
            <div class="columns">
                <div class="column is-half">
                    <h1>About</h1>
                    <h4>Current version: {{ $changelog[0]->version }}</h4>
                    <div>Released: {{ date('d M Y', strtotime($changelog[0]->created_at)) }}</div>
                    <h4>Support</h4>
                    <div>ITC Helpdesk</div>
                    <div>Ph: (08) 9282 9913</div>
                    <div>Email: <a href="mailto:helpdesk@scrosswa.org.au">helpdesk@scrosswa.org.au</a></div>
                    <h4>Change request contacts</h4>
                    <div>Lindy Caporn <span class="is-italic">(Head of Home Care)</span></div>
                    <div>Tracey King <span class="is-italic">(Head of Marketing)</span></div>
                    <div>Paul Groth <span class="is-italic">(Senior Digital Manager)</span></div>
                </div>
                <div class="column is-half">
                    <h2>Change Log</h2>
                    @foreach($changelog as $log)
                        <div class="changelog">
                            <h4>v{{ $log->version }}<br/><small>{{ date('d M Y', strtotime($log->created_at)) }}</small></h4>
                            <p>{!! nl2br($log->log) !!}</p>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
@endsection