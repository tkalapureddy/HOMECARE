@extends('layouts.app')

@section('content')
    <section class="section has-border-top">
        <div class="container">
            @if(isset($estimates))
                <div class="columns">
                    <div class="column is-half">
                        <h1>Budgets</h1>
                        <p>From {{ $estimates['dateFrom'] }} to {{ $estimates['dateTo'] }}</p>
                        <table>
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Qty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Home Care Package</td>
                                    <td>{{ $estimates['totalHCP'] }}</td>
                                </tr>
                                <tr>
                                    <td>Private</td>
                                    <td>{{ $estimates['totalPrivate'] }}</td>
                                </tr>
                            </tbody>
                        </table>
                        <p>&nbsp;</p>
                        <p>Staff who have created <strong>PRIVATE</strong> budgets during this time</p>
                        <ul>
                            @foreach ($estimates['privateUserNames'] as $pun)
                                <li>{{ $pun }}</li>
                            @endforeach
                        </ul>
                        <p>&nbsp;</p>
                        <p>Staff who have created <strong>HCP</strong> budgets during this time</p>
                        <ul>
                            @foreach ($estimates['hcpUserNames'] as $fun)
                                <li>{{ $fun }}</li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="column is-half">
                        
                    </div>
                </div>
            @else
                <div class="error">{{ $error }}</div>
            @endif
        </div>
    </section>
@endsection