@extends('layouts.app')

@section('content')

<section class="section">
    <div class="container">
        <div class="columns">
            <div class="column is-6">

                <h1 class="title">{{ __('common.login') }}</h1>
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div class="field">
                        {{Form::label('email', __("E-Mail Address"), ['class' => 'label'])}}

                        <div class="control">
                            @php
                                $emailErrors = $errors->has('email') ? ' is-invalid' : '';
                                $oldEmail = old("email");
                            @endphp
                            {{Form::text('email', '', ['class' => "input is-medium is-primary form-control$emailErrors", 'type' => 'email', 'placeholder' => 'Email address', 'value' => $oldEmail, 'required'])}}

                            @if ($errors->has('email'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>

                    <div class="field">
                        {{Form::label('password', __('Password'), ['class' => 'label'])}}

                        <div class="control">
                            @php
                                $passwordErrors = $errors->has('password') ? ' is-invalid' : '';
                                $oldPassword = old('email');
                            @endphp
                            {{Form::password('password', ['class' => "input is-medium is-primary form-control$passwordErrors", 'type' => 'password', 'value' => $oldPassword, 'required'])}}

                            @if ($errors->has('password'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                        </div>
                    </div>

                    <div class="field-body margin-bottom-20">
                        <div class="field">
                            <div class="control">
                                    <label for="remember" class="checkbox">
                                        <input class="checkbox is-medium is-primary form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                        {{ __('Remember Me') }}
                                    </label>
                            </div>
                        </div>
                    </div>

                    <div class="field">
                        <div class="control">
                            {{Form::submit('Submit', ['class' => 'button is-success'])}}
                        </div>
                        <div class="margin-top-20">
                            @if (Route::has('password.request'))
                                <a href={{ route('password.request') }}>
                                    {{ __('Forgot Your Password?') }}
                                </a>
                            @endif
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>

        </div>
    </div>
</section>

@endsection