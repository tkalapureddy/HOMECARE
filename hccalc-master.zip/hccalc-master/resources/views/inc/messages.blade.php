@if(count($errors) > 0)
    @foreach($errors->all() as $error)
        <section class="section">
            <div class="container">
                <div class="notification is-danger">
                    {{$error}}
                </div>
            </div>
        </section>
    @endforeach
@endif

@if(session('success'))
        <section class="section">
            <div class="container">
                <div class="notification is-success">
                    {{session('success')}}
                </div>
            </div>
        </section>
@endif

@if(session('error'))
        <section class="section">
            <div class="container">
                <div class="notification is-danger">
                    {{session('error')}}
                </div>
            </div>
        </section>
@endif

@if(Session::has('warning'))
        <section class="section">
            <div class="container">
                <div class="notification is-danger">
                    {{ Session::get('warning') }}
                </div>
            </div>
        </section>
@endif