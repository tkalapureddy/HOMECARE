<nav class="navbar navbar-admin" role="navigation">
    <div class="navbar-brand">
        <a class="navbar-item" href="{{ url('/') }}">
            <img src="/images/southern-plus-logo-blue.svg" width="250" alt="Southern Plus Logo">
        </a>
        <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarMain">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
        </a>
    </div>
    
    <div id="navbarMain" class="navbar-menu">

        <div class="navbar-start"></div>

        <div class="navbar-end">
            @guest
                <a class="navbar-item" href="/login">
                    {{ __('common.login') }}
                </a>
            @else
                <div class="navbar-item has-dropdown is-hoverable">
                    <div class="navbar-link">
                        {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
                    </div>
                    <div class="navbar-dropdown is-right">
                            <a class="navbar-item" href='/calculator/client'>Calculator</a>
                            <a class="navbar-item" href={{ route('about') }}>About</a>
                            <a class="navbar-item" href={{ route('reports') }}>Reports</a>
                        <a class="navbar-item" href={{ route('logout') }} onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            {{ __('Logout') }}
                        </a>
                        <form id="logout-form" action={{ route('logout') }} method="POST" style="display: none;">
                            @csrf
                        </form>
                    </div>
                </div>
            @endguest
        </div>
    </div>

</nav>