@extends('layouts.app')

@section('content')
    <section class="section">
        <div class="container has-text-centered">
            <h1>Home Care Calculator</h1>
            <p><a href="/calculator/client">Start Calculator</a></p>
        </div>
    </section>
@endsection
