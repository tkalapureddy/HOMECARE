@extends('layouts.app')

@section('content')
    <div id="calculator"></div>
@endsection
