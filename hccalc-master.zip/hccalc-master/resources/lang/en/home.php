<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Homepage Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used in the homepage.
    |
    */

    'asdf'      => 'Some stuff',

];
