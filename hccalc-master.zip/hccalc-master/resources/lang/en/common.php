<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Common Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for common terms throughout the app.
    |
    */

    'app-name'          => 'Home Care Calculator',
    'login'             => 'Login',
    'logout'            => 'Logout',
    'register'          => 'Register',
    'name'              => 'Name',
    'email'             => 'Email',
    'password'          => 'Password',
    'confirm-password'  => 'Confirm Password',

];
