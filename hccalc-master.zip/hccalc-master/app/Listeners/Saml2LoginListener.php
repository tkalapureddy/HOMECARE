<?php

namespace App\Listeners;

use Aacotroneo\Saml2\Events\Saml2LoginEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Carbon\Carbon;
use Log;
use App\Models\User;
use Auth;
use Session;
use Redirect;
use Saml2MessageId;

class Saml2LoginListener
{

    public function handle(Saml2LoginEvent $event)
    {

        // Get user from response
        $user = $event->getSaml2User();

        // All permission groups
        $groups = $user->getAttributes()["http://schemas.xmlsoap.org/claims/Group"];
        // Calculator permission groups
        $homecarecalc = in_array('homecarecalc', $groups) ? true : false;
        $contentcalc = in_array('contentcalc', $groups) ? true : false;
        $calcadmin = in_array('calcadmin', $groups) ? true : false;
        $calcsuperadmin = in_array('calcsuperadmin', $groups) ? true : false;


        // Prevent replay attacks
        $messageId = $event->getSaml2Auth()->getLastMessageId();
        $replay = Saml2MessageId::where('message_id', '=', $messageId)->first();
        if(!is_null($replay)) {
            // If we get here it's a possible replay attack
            Log::debug('-----------------------');
            Log::debug('POSSIBLE REPLAY ATTACK!');
            Log::debug('UTC ' . Carbon::now());
            Log::debug('REMOTE_ADDR: ' . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''));
            Log::debug('HTTP_X_FORWARDED_FOR: ' . (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : ''));
            Log::debug('HTTP_USER_AGENT: ' . $_SERVER['HTTP_USER_AGENT']);
            Log::debug('Saml2 message ID: ' . $messageId);
            Log::debug('username: ' . $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier"][0]);
            Log::debug('homecarecalc: ' . $homecarecalc);
            Log::debug('contentcalc: ' . $contentcalc);
            Log::debug('calcadmin: ' . $calcadmin);
            Log::debug('calcsuperadmin: ' . $calcsuperadmin);
            Log::debug('firstname: ' . $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"][0]);
            Log::debug('lastname: ' . $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"][0]);
            Log::debug('email: ' . $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"][0]);
            Log::debug('assertion: ' . $user->getRawSamlAssertion());
            Log::debug('END OF REPLAY ATTACK LOG');
            Log::debug('-----------------------');
            // Make sure they're logged out and redirected to home
            Auth::logout();
            Session::save();
            Redirect::to('/')->withWarning("An error occurred with the login.");
            return;
        } else {
            $mid = new Saml2MessageId;
            $mid->message_id = $messageId;
            $mid->save();
        }
        // Cleanup Saml2 entries older than 24 hours
        // As long as the time subtracted is longer than the ADFS session (8 hours), it is safe to delete the record
        Saml2MessageId::where('created_at', '<=', Carbon::now()->subHours(24))->delete();


        // All user data
        $userData = [
            'username' => $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier"][0],
            'homecarecalc' => $homecarecalc,
            'contentcalc' => $contentcalc,
            'calcadmin' => $calcadmin,
            'calcsuperadmin' => $calcsuperadmin,
            'firstname' => $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"][0],
            'lastname' => $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"][0],
            'email' => $user->getAttributes()["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"][0],
            'assertion' => $user->getRawSamlAssertion()
        ];

        if(!$userData['homecarecalc']) { // If user is not in main group return them to the home screen with a message about permissions
            
            Log::debug('Not in the main group ' . $userData['username']);
            Auth::logout();
            Session::save();
            Redirect::to('/')->withWarning("You don't have the correct permissions in your account.");

        } else { // If user is in the main group log them in or create new account if not exists

            $laravelUser = User::where('username', $userData['username'])->first();

            // If the environment is NOT currently available for internal testing
            // Redirect without logging the user in, unless it is Paul
            if(env('APP_ENV') != 'production' && !env('TESTING_ENABLED') && $laravelUser->id != 1) {
                Redirect::to('/')->withWarning("Testing has been switched off.");
            } else {
                
                if($laravelUser) { // Update existing user
                    $laravelUser->username = $userData['username'];
                    $laravelUser->first_name = $userData['firstname'];
                    $laravelUser->last_name = $userData['lastname'];
                    $laravelUser->email = $userData['email'];
                    $laravelUser->homecarecalc = $userData['homecarecalc'];
                    $laravelUser->contentcalc = $userData['contentcalc'];
                    $laravelUser->calcadmin = $userData['calcadmin'];
                    $laravelUser->calcsuperadmin = $userData['calcsuperadmin'];
                    $laravelUser->save();
                } else { // Create new user
                    $newUser = new User;
                    $newUser->username = $userData['username'];
                    $newUser->first_name = $userData['firstname'];
                    $newUser->last_name = $userData['lastname'];
                    $newUser->email = $userData['email'];
                    $newUser->homecarecalc = $userData['homecarecalc'];
                    $newUser->contentcalc = $userData['contentcalc'];
                    $newUser->calcadmin = $userData['calcadmin'];
                    $newUser->calcsuperadmin = $userData['calcsuperadmin'];
                    $newUser->save();
                    Log::debug($userData['username'] . ' created');
                    $laravelUser = User::where('username', $userData['username'])->first();
                }
                Log::debug($userData['username'] . ' logged in. Saml2 Message ID: ' . $messageId);
                Auth::login($laravelUser);
            
            }

        }
    }
}