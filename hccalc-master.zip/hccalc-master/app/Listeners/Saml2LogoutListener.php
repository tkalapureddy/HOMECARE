<?php

namespace App\Listeners;

use Aacotroneo\Saml2\Events\Saml2LogoutEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Log;
use Auth;
use Session;
use Redirect;

class Saml2LogoutListener
{

    public function handle($event)
    {
        Auth::logout();
        Session::save();
        Redirect::to('/')->withWarning("Logged out");
    }
}