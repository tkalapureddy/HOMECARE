<?php

namespace App\Http\Controllers;

use ChangeLog;
use Illuminate\Http\Request;

class AboutController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $changelog = ChangeLog::orderBy('created_at', 'desc')->get();
        return view('about')->with('changelog', $changelog);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ChangeLog  $changeLog
     * @return \Illuminate\Http\Response
     */
    public function show(ChangeLog $changeLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ChangeLog  $changeLog
     * @return \Illuminate\Http\Response
     */
    public function edit(ChangeLog $changeLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ChangeLog  $changeLog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ChangeLog $changeLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ChangeLog  $changeLog
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChangeLog $changeLog)
    {
        //
    }
}
