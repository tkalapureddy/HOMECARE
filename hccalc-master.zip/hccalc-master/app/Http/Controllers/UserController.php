<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use User;
use Auth;

class UserController extends Controller
{
    public function userList()
    {
        $allUsers = User::select('id', 'first_name', 'last_name')->get();
        return response()->json($allUsers);
    }

    public function myPermissions()
    {
        $user = Auth::user();
        $permissions = array(
            'content' => $user->contentcalc == 1 ? true : false,
            'admin' => $user->calcadmin == 1 ? true : false,
            'superAdmin' => $user->calcsuperadmin == 1 ? true : false
        );
        return response()->json($permissions);
    }
}
