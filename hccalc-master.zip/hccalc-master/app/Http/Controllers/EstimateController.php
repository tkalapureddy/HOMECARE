<?php

namespace App\Http\Controllers;

use Estimate;
use Illuminate\Http\Request;
use Auth;
use User;
use Log;
use Exception;
use DB;

class EstimateController extends Controller
{

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(Auth::user()) {
            // Create and add all the common values
            $estimate = new Estimate;
            $estimate->entry_type = 2;
            $estimate->user_id = Auth::user()->id;
            $estimate->app_version = $request->input('appVersion');
            $estimate->template_id = (int)$request->input('templateId');
            $estimate->client = json_encode($request->input('client'));
            $estimate->plan = 'null'; // null as a string, just to represent that we never used this and one day can delete the 'plan' column from the table
            $estimate->services = json_encode($request->input('services'));

            if($request->input('estimateNum') > 0) { // Save next revision of existing estimate
                $estimate->estimate_number = (int)$request->input('estimateNum');
                $old = Estimate::select('revision')->where('estimate_number', $estimate->estimate_number)->orderBy('created_at', 'desc')->first();
                $estimate->revision = $old->revision + 1;
            } else { // Create new estimate
                $lastEntered = Estimate::select('estimate_number')->orderBy('estimate_number', 'desc')->first();
                $estimate->estimate_number = $lastEntered->estimate_number + 1;
                $estimate->revision = 0;
            }
            
            // Save it
            $estimate->save();

            // Respond with updated stuff
            $response = array(
                'estimateId' => $estimate->id,
                'estimateNum' => $estimate->estimate_number,
                'revision' => $estimate->revision,
                'createdAt' => date('j M, Y', strtotime($estimate->created_at))
            );
            return response()->json($response);
        } else {
            return response()->json(['error' => 'Unauthorised']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Estimate  $estimate
     * @return \Illuminate\Http\Response
     */
    public function show(Estimate $estimate)
    {
        if(Auth::user()) {
            if($estimate && $estimate->entry_type == 2) {
                $estimate->createdAt = date('j M, Y', strtotime($estimate->created_at));
                $eUser = User::where('id', '=', $estimate->user_id)->first();
                $estimate->username = $eUser->first_name . " " . $eUser->last_name;
                return response()->json($estimate);
            } else {
                return response()->json(['error' => 'No results']);
            }
        } else {
            return response()->json(['error' => 'Unauthorised']);
        }
    }

    public function getTemplate() {
        if(Auth::user()) {
            $estimate = Estimate::where('entry_type', 1)->orderBy('created_at', 'desc')->first();
            if($estimate) {
                $username = Auth::user()->first_name . " " . Auth::user()->last_name;
                $userId = Auth::user()->id;
                $response = array(
                    'id' => $estimate->id,
                    'userId' => $userId,
                    'username' => $username,
                    'pdfFilename' => $estimate->filename,
                    'clientDetails' => $estimate->client,
                    'serviceDetails' => $estimate->services,
                    'created_at' => $estimate->created_at
                );
                return response()->json($response);
            } else {
                return response()->json(['Error' => 'There was an error retrieving the template.']);
            }
        } else {
            return response()->json(['error' => 'Unauthorised']);
        }
    }

    public function saveTemplate(Request $request) {
        if(Auth::user()) {
            $user = Auth::user();
            if($user->contentcalc == '1') {

                $template = Estimate::where('entry_type', 1)->orderBy('created_at', 'desc')->first();

                $newTemplate = new Estimate;
                $newTemplate->entry_type = 1;
                $newTemplate->estimate_number = 0;
                $newTemplate->revision = 0;
                $newTemplate->user_id = $user->id;
                $newTemplate->app_version = "";
                $newTemplate->template_id = 0;
                $newTemplate->filename = NULL;
                $newTemplate->client = json_encode($request->input('client'));
                $newTemplate->plan = $template->plan;
                $newTemplate->services = $template->services;
                $newTemplate->save();

                return response()->json(array('success' => true, 'templateId' => $newTemplate->id));

            } else {
                return response()->json(['error' => 'Unauthorised']);
            }
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Estimate  $estimate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Estimate $estimate)
    {
        //
    }

    /**
     * Get list of estimates.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Estimate  $estimate
     * @return \Illuminate\Http\Response
     */
    public function budgetList(Request $request)
    {
        // Validate request details
        $request->validate([
            'search' => 'string|max:255',
            'group' => 'bool|required',
            'page' => 'required|integer',
            'selectedUser' => 'required|integer',
            'pageSize' => 'required|integer'
        ]);

        $search = isset($request->search) && strlen($request->search) > 1 ? $request->search : false;
        $page = (int)$request->page;
        $group = (bool)$request->group;
        $pageSize = (int)$request->pageSize;
        $from = $pageSize * $page - $pageSize;
        $u = (int)$request->selectedUser;

        if($search) {

            $estimates = DB::table('estimates')
                ->join('users', 'estimates.user_id', '=', 'users.id')
                ->select('estimates.*', 'users.first_name', 'users.last_name')
                ->when($u > 0, function($query) use ($u) {
                    $query->where('estimates.user_id', '=', $u);
                })
                ->where(function($query) use ($search) {
                    $query->where('client->name', 'like', '%' . $search . '%')
                        ->orWhere('client->phone', 'like', '%' . $search . '%')
                        ->orWhere('client->address', 'like', '%' . $search . '%')
                        ->orWhere('client->contactName', 'like', '%' . $search . '%')
                        ->orWhere('client->contactPhone', 'like', '%' . $search . '%')
                        ->orWhere('client->contactAddress', 'like', '%' . $search . '%');
                })
                ->orderBy('estimates.id', 'desc')
                ->offset($from)
                ->limit($pageSize)
                ->get();

            // Count total results
            $estimatesCount = DB::table('estimates')
                ->join('users', 'estimates.user_id', '=', 'users.id')
                ->when($u > 0, function($query) use ($u) {
                    $query->where('estimates.user_id', '=', $u);
                })
                ->where(function($query) use ($search) {
                    $query->where('client->name', 'like', '%' . $search . '%')
                        ->orWhere('client->phone', 'like', '%' . $search . '%')
                        ->orWhere('client->address', 'like', '%' . $search . '%')
                        ->orWhere('client->contactName', 'like', '%' . $search . '%')
                        ->orWhere('client->contactPhone', 'like', '%' . $search . '%')
                        ->orWhere('client->contactAddress', 'like', '%' . $search . '%');
                })
                ->count();
            $totalResults = $estimatesCount;

        } else {

            $sqlInQuery = "";
            $queryVars = array();
            $entryType = 2;

            if($group) {
                $sqlInQuery .= "SELECT MAX(id) FROM estimates WHERE entry_type = ?";
            } else {
                $sqlInQuery .= "SELECT id FROM estimates WHERE entry_type = ?";
            }
            $queryVars[] = 2;

            if($u > 0) { // For a specific user
                $sqlInQuery .= " AND user_id = ?";
                $queryVars[] = $u;
            }

            if($group) {
                $sqlInQuery .= " GROUP BY estimate_number";
            }

            $queryVarsCount = $queryVars;
            $queryVars[] = $from;
            $queryVars[] = $pageSize;

            $estimates = DB::select("SELECT estimates.*, users.first_name, users.last_name
                FROM estimates JOIN users
                WHERE estimates.user_id = users.id
                AND estimates.id IN ($sqlInQuery)
                ORDER BY estimates.id DESC
                LIMIT ?, ?", $queryVars);

            // Count total results
            $estimatesCount = DB::select("SELECT COUNT(*) as total
                FROM estimates JOIN users
                WHERE estimates.id IN ($sqlInQuery)
                AND estimates.user_id = users.id", $queryVarsCount);
            $totalResults = $estimatesCount[0]->total;

        }
        
        // Check each result, if not the latest revision, get the latest
        if(sizeof($estimates) > 0) {

            $latestEstimateNumbers = array();
            foreach($estimates as $e) {
                if(!in_array($e->estimate_number, $latestEstimateNumbers)) {
                    $latestEstimateNumbers[] = $e->estimate_number;
                }
            }
            $numBind = count($latestEstimateNumbers);
            
            $latestEstimates = DB::select("SELECT estimates.id, estimates.estimate_number, estimates.revision, users.first_name, users.last_name
                FROM estimates JOIN users
                WHERE estimates.user_id = users.id
                AND estimates.id IN (SELECT MAX(id) FROM estimates WHERE estimate_number IN (".str_pad('',$numBind*2-1,'?,').") GROUP BY estimate_number)",
                $latestEstimateNumbers);

        }
        
        $responseData = array();

        if(sizeof($estimates) > 0) {
            foreach($estimates as $estimate) {

                // Get latest revision details for each if necessary
                $latest = null;
                foreach($latestEstimates as $le) {
                    if($estimate->estimate_number == $le->estimate_number && $estimate->revision != $le->revision) {
                        $latest = array(
                            "id" => $le->id,
                            "estimateNum" => $le->estimate_number,
                            "revision" => $le->revision,
                            "user" => $le->first_name . " " . $le->last_name
                        );
                        break;
                    }
                }

                $clientDetails = json_decode($estimate->client, true);
                $responseData[] = array(
                    'id' => $estimate->id,
                    'user' => $estimate->first_name . " " . $estimate->last_name,
                    'estimateNum' => $estimate->estimate_number,
                    'revision' => $estimate->revision,
                    'clientName' => $clientDetails['name'],
                    'contactName' => $clientDetails['contactName'],
                    'createdAt' => date('j M, Y', strtotime($estimate->created_at)),
                    'latest' => $latest
                );
            }
            $response = array(
                'totalResults' => $totalResults,
                'data' => $responseData
            );
            return response()->json($response);
        } else {
            return response()->json(array('error' => 'No results'));
        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Estimate  $estimate
     * @return \Illuminate\Http\Response
     */
    public function destroy(Estimate $estimate)
    {
        //
    }
}
