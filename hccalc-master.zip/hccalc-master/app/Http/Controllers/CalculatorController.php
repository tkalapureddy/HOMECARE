<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculatorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the calculator.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('calculator.calculator');
    }

    /**
     * Go to other page in the calculator.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function path()
    {
        return view('calculator.calculator');
    }

}
