<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use Estimate;

class ReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $userAccess = Auth::user()->calcsuperadmin;
        if($userAccess != 1) {
            return response()->json(array('error' => 'Not authorised'));
        }

        try {

            $from = date('2019-10-01 00:00:00');
            $to = date('2019-12-31 23:59:59');

            $estimates = Estimate::whereBetween('created_at', [$from, $to])->orderBy('created_at', 'asc')->get();
            
            $response = array();
            $hcpCount = 0;
            $privateCount = 0;
            $hcpUserNames = array();
            $privateUserNames = array();
            $budgetIds = array();

            if($estimates->count() > 0) {

                foreach ($estimates as $estimate) {

                    if($estimate->entry_type == 2) {

                        $clientDetails = json_decode($estimate->client, true);
                        
                        $user = User::where('id', $estimate->user_id)->first();
                        $pun = $user->first_name . ' ' . $user->last_name;

                        if($clientDetails['fundingType'] == 'funded') {
                            $funding = 'Home Care Package';
                            if(!in_array($pun, $hcpUserNames)) {
                                $hcpUserNames[] = $pun;
                            }
                            if(!in_array($estimate->estimate_number, $budgetIds)) {
                                $hcpCount++;
                            }
                        } else {
                            $funding = 'Private';
                            if(!in_array($pun, $privateUserNames)) {
                                $privateUserNames[] = $pun;
                            }
                            if(!in_array($estimate->estimate_number, $budgetIds)) {
                                $privateCount++;
                            }
                        }

                        $budgetIds[] = $estimate->estimate_number;

                        $response['dateFrom'] = date('d M Y', strtotime($from));
                        $response['dateTo'] = date('d M Y', strtotime($to));
                        $response['totalHCP'] = $hcpCount;
                        $response['totalPrivate'] = $privateCount;
                        $response['privateUserNames'] = $privateUserNames;
                        $response['hcpUserNames'] = $hcpUserNames;

                    }
                    
                }

                return view('reports')->with('estimates', $response);

            } else {
                return view('reports')->with('error', 'No results');
            }

        } catch(Exception $e) {
            return view('reports')->with('error', 'Unauthorised');
        }
    }
}
