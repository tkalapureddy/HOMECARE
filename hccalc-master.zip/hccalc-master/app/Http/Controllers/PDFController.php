<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Estimate;
use Auth;
use Log;
use Exception;
use URL;
use Storage;
use Str;

class PDFController extends Controller
{

    /**
     * Get the estimate
     * Save it as a pdf
     * Return a pdf with force download
     */

    private $estimateId;
    private $pdf;
    private $estimate;
    private $pdfFilename;

    // Use the final data that was calculated in react
    // so there are no differences between js and php calculations
    private $finalEstimate;
    private $finalFunding;

    public function index(Request $request)
    {

        // Set the estimate ID
        $this->estimateId = (int)$request->estimate;

        // Get final estimate data from react
        $this->finalEstimate = $request->finalEstimate;

        // Get final funding data from react
        $this->finalFunding = $request->finalFunding;

        // Get the estimate from the db
        $this->getEstimateArray();

        // Create the pdf
        $this->createPDF();

        // Generate the filename
        $this->generatePDFFilename();

        // Save filename in db
        $this->saveFilename();

        // Save the pdf
        $this->savePDF();

        // Return the filename
        return response()->json($this->pdfFilename);

    }

    private function getEstimateArray()
    {

        try {

            $est1 = Estimate::where('id', $this->estimateId)->first();

            $this->estimate = json_decode($est1, true);

            // Decode the client array (don't need the services array here)
            $this->estimate['client'] = json_decode($this->estimate['client'], true);

            return;

        } catch(Exception $e) {
            return response()->json(array('error' => 'Unauthorised'));
        }

    }

    private function savePDF()
    {

        // Path to file
        $pathToFile = 'public/pdf/';

        // Full path to pdf
        $pdfFullPath = $pathToFile . $this->pdfFilename;

        // Get the pdf as a string
        $pdfFile = $this->pdf->Output('', "S");
        
        // Save the pdf
        Storage::put($pdfFullPath, $pdfFile);

    }

    private function generatePDFFilename()
    {
        
        // Get client name
        $clientName = Str::slug($this->estimate['client']['name'], '-');

        // Build the path to save the file
        $this->pdfFilename = 'SPlus-Budget-' . $this->estimate['estimate_number'] . '-' . $this->estimate['revision'] . '-' . $clientName . '.pdf';

        return;

    }

    private function saveFilename()
    {
        Estimate::where('id', $this->estimateId)->update(['filename' => $this->pdfFilename]);
    }

    private function createPDF()
    {

        $this->pdf = new \Mpdf\Mpdf([
            'dpi'           => 96,
            'setAutoTopMargin' => 'pad',
            'setAutoBottomMargin' => 'pad',
            'margin_header' => 12,
            'margin_footer' => 10,
            'fontDir'       => ['../app/Custom/PDF/css/fonts'],
            'fontdata'      => [
                'milo-serif'    => [
                    'R' => 'MiloSerifOffc-MediumIta.ttf'
                ],
                'zona-pro'      => [
                    'R' => 'ZonaPro-Regular.ttf',
                    'B' => 'ZonaPro-Bold.ttf'
                ],
                'droid-sans-mono'   => [ // Monospaced font for numbers in table
                    'R' => 'DroidSansMono.ttf'
                ]
            ],
            'default_font'  => 'zona-pro',
            'debug'         => true
        ]);

        $this->pdf->SetCreator("Southern Plus - Home Care Calculator");
        $this->pdf->SetAuthor("Paul Groth");
        $this->pdf->SetTitle("Home Care Budget");

        // A/B test this if necessary
        // Reduce memory (at the expense of processing time)
        // $this->pdf->packTableData = true;

        // CSS
        $style = file_get_contents('../app/Custom/PDF/css/pdf-style.css');
        $this->pdf->WriteHTML($style, 1);

        $headerFooter = '<!--mpdf
            <htmlpageheader name="splusHeader">
                <table class="header-table">
                    <tr>    
                        <td class="header-left">
                            <img src="images/southern-plus-logo-blue-for-pdf.svg" width="250" />
                        </td>
                        <td class="header-right" align="right">
                            15 Rowe Avenue<br/>
                            Rivervale WA 6103<br/>
                            Phone: 1300 000 161<br/>
                        </td>
                    </tr>
                </table>
            </htmlpageheader>
        <htmlpagefooter name="splusFooter">
            <table class="footer-table">
                <tr>    
                    <td class="footer-left">
                        Home Care Budget
                    </td>
                    <td class="footer-middle">
                        Doc: ' . $this->estimate['estimate_number'] . ' | Rev: ' . $this->estimate['revision'] . ' | ' . date('j M Y', strtotime($this->estimate['created_at'])) . '
                    </td>
                    <td class="footer-right" align="right">
                        Page {PAGENO} of {nb}
                    </td>
                </tr>
            </table>
        </htmlpagefooter> mpdf-->';

        $funded = $this->estimate['client']['fundingType'] == 'funded' ? true : false;

        $content = '<div class="main-content-container">';
            $content .= '<h1>Home Care Budget</h1>';
            $content .= '<div class="contacts-and-details">';
                $content .= '<div class="col1">';
                    $content .= '<div>';
                        $content .= '<span>CARE RECIPIENT</span>';
                        $content .= '<h3 style="margin-top:2mm; margin-bottom:0;">' . $this->estimate['client']['name'] . '</h3>';
                        $content .= '<p><span style="font-weight:bold;">Address</span><br/>' . $this->estimate['client']['address'] . '</p>';
                        $content .= '<p><span style="font-weight:bold;">Phone</span><br/>' . $this->estimate['client']['phone'] . '</p>';
                    $content .= '</div>';
                $content .= '</div>';
                $content .= '<div class="col2">';
                    $content .= '<div>';
                        $content .= '<span>CONTACT PERSON</span>';
                        $content .= '<h3 style="margin-top:2mm; margin-bottom:0;">' . $this->estimate['client']['contactName'] . '</h3>';
                        $content .= '<p><span style="font-weight:bold;">Address</span><br/>' . $this->estimate['client']['contactAddress'] . '</p>';
                        $content .= '<p><span style="font-weight:bold;">Phone</span><br/>' . $this->estimate['client']['contactPhone'] . '</p>';
                    $content .= '</div>';
                $content .= '</div>';
                $content .= '<div class="col3">';
                    $content .= '<div>';
                        $content .= '<p>Document #: ' . $this->estimate['estimate_number'] . '</p>';
                        $content .= '<p>Revision #: ' . $this->estimate['revision'] . '</p>';
                        $content .= '<p>Date: ' . date('j M Y', strtotime($this->estimate['created_at'])) . '</p>';
                        $content .= '<p>Prepared by: ' . Auth::user()->first_name . ' ' . Auth::user()->last_name . '</p>';
                    $content .= '</div>';
                $content .= '</div>';
                $content .= '<div style="clear:both;"></div>';
            $content .= '</div>';
            $content .= '<hr/>';

            $content .= '<h2>Funding</h2>';
            $content .= '<table class="funding-table">';
                $content .= '<thead>';
                    $content .= '<tr>';
                        $content .= '<th class="col1h">All funding</th>';
                        $content .= '<td class="col2h"></td>';
                        $content .= '<th class="col3h">Fortnightly</th>';
                        $content .= '<th class="col4h">Monthly</th>';
                    $content .= '</tr>';
                 $content .= '</thead>';
                $content .= '<tr>';
                    $content .= '<td class="col1">Funding type</td>';
                    $content .= $funded ? '<td class="col2">HCP Level ' . $this->estimate['client']['fundingLevel'] . '</td>' : '<td class="col2">Private</td>';
                    $content .= $funded ? '<td class="col3">$' . number_format($this->finalFunding['hcpFtn'], 2) . '</td>' : '<td class="col3">$' . number_format($this->finalFunding['totalBudgetFtn'], 2) . '</td>';
                    $content .= $funded ? '<td class="col4">$' . number_format($this->finalFunding['hcpMonth'], 2) . '</td>' : '<td class="col4">$' . number_format($this->finalFunding['totalBudgetMonth'], 2) . '</td>';
                $content .= '</tr>';
                if($funded && sizeof($this->finalFunding['supplementsList'][0]) > 0) {
                    $content .= '<tr>';
                        $content .= '<td class="col1">Supplements</td>';
                        $content .= '<td class="col2">';
                            foreach($this->finalFunding['supplementsList'][0] as $val) {
                                $content .= $val . '<br/>';
                            }
                        $content .= '</td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['supplementsFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['supplementsMonth'], 2) . '</td>';
                    $content .= '</tr>';
                }
                if($funded) {
                    $content .= '<tr>';
                        $content .= '<td class="col1">Top up</td>';
                        $content .= '<td class="col2"></td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['topUpFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['topUpMonth'], 2) . '</td>';
                    $content .= '</tr>';
                    $content .= '<tr>';
                        $content .= '<td class="col1">Basic daily fee</td>';
                        $content .= '<td class="col2"></td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['basicDailyFeeFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['basicDailyFeeMonth'], 2) . '</td>';
                    $content .= '</tr>';
                    $content .= '<tr>';
                        $content .= '<td class="col1">Income tested fee</td>';
                        $content .= '<td class="col2"></td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['incomeTestedFeeFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['incomeTestedFeeMonth'], 2) . '</td>';
                    $content .= '</tr>';
                }
                $content .= '<tr>';
                    $content .= '<th class="col1h">Total</th>';
                    $content .= '<th class="col2h"></th>';
                    $content .= '<th class="col3h"></th>';
                    $content .= '<th class="col4h"></th>';
                $content .= '</tr>';
                if($funded) {
                    $content .= '<tr>';
                        $content .= '<td class="col1">Amount you pay</td>';
                        $content .= '<td class="col2"></td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['amountYouPayFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['amountYouPayMonth'], 2) . '</td>';
                    $content .= '</tr>';
                    $content .= '<tr>';
                        $content .= '<td class="col1">Amount government pays</td>';
                        $content .= '<td class="col2"></td>';
                        $content .= '<td class="col3">$' . number_format($this->finalFunding['amountGovPayFtn'], 2) . '</td>';
                        $content .= '<td class="col4">$' . number_format($this->finalFunding['amountGovPayMonth'], 2) . '</td>';
                    $content .= '</tr>';
                }
                $content .= '<tr>';
                    $content .= '<th class="col1 total">Total budget</th>';
                    $content .= '<th class="col2 total"></th>';
                    $content .= '<th class="col3 total">$' . number_format($this->finalFunding['totalBudgetFtn'], 2) . '</th>';
                    $content .= '<th class="col4 total">$' . number_format($this->finalFunding['totalBudgetMonth'], 2) . '</th>';
                $content .= '</tr>';
                $content .= '<tr>';
                    $content .= '<td class="col1">Remaining</td>';
                    $content .= '<td class="col2"></td>';
                    $content .= '<td class="col3">$' . number_format($this->finalFunding['remainingFtn'], 2) . '</td>';
                    $content .= '<td class="col4">$' . number_format($this->finalFunding['remainingMonth'], 2) . '</td>';
                $content .= '</tr>';
            $content .= '</table>';

            $content .= '<div class="same-face-promise-container">';
                $content .= '<img src="images/same-face-promise-logo.svg" />';
            $content .= '</div>';

            // PAGE BREAK
            $content .= '<pagebreak>';

            $content .= '<h2>Home Care to be provided</h2>';
            $content .= '<table class="budget-table">';
                $content .= '<thead>';
                    $content .= '<tr>';
                        $content .= '<th class="col2h" colspan="3">Fortnightly</th>';
                        $content .= '<th class="col3h" colspan="2">Monthly</th>';
                    $content .= '</tr>';
                $content .= '</thead>';
                $content .= '<tbody>';
                    if($this->finalEstimate['categoryList']) {
                        $cls = sizeof($this->finalEstimate['categoryList']);
                        // Category loop
                        for($i=0;$i<$cls;$i++) {
                            $content .= '<tr>';
                                $content .= '<th class="col1h table-heading">' . $this->finalEstimate['categoryList'][$i]['name'] . '</th>';
                                $content .= '<th class="col2h table-heading" colspan="2"></th>';
                                $content .= '<th class="col3h table-heading" colspan="2"></th>';
                            $content .= '</tr>';
                            $ss = sizeof($this->finalEstimate['categoryList'][$i]['services']);
                            // Services loop
                            for($j=0;$j<$ss;$j++) {
                                // Other items
                                if($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems']) {
                                    if(!empty($this->finalEstimate['categoryList'][$i]['services'][$j]['notes'])) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                // Service notes
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['notes'] . '</td></tr>';
                                                $content .= '</table>';
                                            $content .= '</td>';
                                            $content .= '<td class="col2"></td>';
                                            $content .= '<td class="col3"></td>';
                                            $content .= '<td class="col4"></td>';
                                            $content .= '<td class="col5"></td>';
                                        $content .= '</tr>';
                                    }
                                    $ois = sizeof($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems']);
                                    for($k=0;$k<$ois;$k++) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                // Service name
                                                $content .= $this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems'][$k]['title'];
                                            $content .= '</td>';
                                            $content .= '<td class="col2">' . number_format(($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems'][$k]['hours'] * 2), 2) . 'hrs</td>';
                                            $content .= '<td class="col3">$' . number_format(($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems'][$k]['amount'] * 2), 2) . '</td>';
                                            $content .= '<td class="col4">' . number_format(($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems'][$k]['hours'] / 7 * 365 / 12), 2) . 'hrs</td>';
                                            $content .= '<td class="col5">$' . number_format(($this->finalEstimate['categoryList'][$i]['services'][$j]['otherItems'][$k]['amount'] / 7 * 365 / 12), 2) . '</td>';
                                        $content .= '</tr>';
                                    }
                                } elseif(isset($this->finalEstimate['categoryList'][$i]['services'][$j]['special']) && $this->finalEstimate['categoryList'][$i]['services'][$j]['special'] == 'flatFeeMulti') {
                                    // Flat fee multi
                                    $content .= '<tr>';
                                        $content .= '<td class="col1 extra-padding">';
                                            // Service name
                                            $content .= $this->finalEstimate['categoryList'][$i]['services'][$j]['name'];
                                            // Service notes
                                            if(!empty($this->finalEstimate['categoryList'][$i]['services'][$j]['notes'])) {
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent notes">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['notes'] . '</td></tr>';
                                                $content .= '</table>';
                                            }
                                        $content .= '</td>';
                                        $content .= '<td class="col2"></td>';
                                        $content .= '<td class="col3"></td>';
                                        $content .= '<td class="col4"></td>';
                                        $content .= '<td class="col5"></td>';
                                    $content .= '</tr>';
                                    $ois = sizeof($this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems']);
                                    for($k=0;$k<$ois;$k++) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                // Service name
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['name'] . '</td></tr>';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['visits'] . '</td></tr>';
                                                $content .= '</table>';
                                            $content .= '</td>';
                                            $content .= '<td class="col2">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['hrsFtn'], 2) . 'hrs</td>';
                                            $content .= '<td class="col3">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['costFtn'], 2) . '</td>';
                                            $content .= '<td class="col4">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['hrsMonth'], 2) . 'hrs</td>';
                                            $content .= '<td class="col5">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['serviceItems'][$k]['costMonth'], 2) . '</td>';
                                        $content .= '</tr>';
                                    }
                                } else {
                                    // Normal items
                                    $content .= '<tr>';
                                        $content .= '<td class="col1 extra-padding">';
                                            // Service name
                                            $content .= $this->finalEstimate['categoryList'][$i]['services'][$j]['name'];
                                            // Service notes
                                            if(!empty($this->finalEstimate['categoryList'][$i]['services'][$j]['notes'])) {
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent notes">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['notes'] . '</td></tr>';
                                                $content .= '</table>';
                                            }
                                        $content .= '</td>';
                                        $content .= '<td class="col2"></td>';
                                        $content .= '<td class="col3"></td>';
                                        $content .= '<td class="col4"></td>';
                                        $content .= '<td class="col5"></td>';
                                    $content .= '</tr>';
                                    // If std hrs
                                    if($this->finalEstimate['categoryList'][$i]['services'][$j]['stdHrsFtn'] > 0) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent">Standard hours</td></tr>';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['stdVisits'] . '</td></tr>';
                                                $content .= '</table>';
                                            $content .= '</td>';
                                            $content .= '<td class="col2">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['stdHrsFtn'], 2) . 'hrs</td>';
                                            $content .= '<td class="col3">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['stdCostFtn'], 2) . '</td>';
                                            $content .= '<td class="col4">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['stdHrsMonth'], 2) . 'hrs</td>';
                                            $content .= '<td class="col5">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['stdCostMonth'], 2) . '</td>';
                                        $content .= '</tr>';
                                    }
                                    // If sat a/h hrs
                                    if($this->finalEstimate['categoryList'][$i]['services'][$j]['satAHHrsFtn'] > 0) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent">Saturday or after hours</td></tr>';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['satAHVisits'] . '</td></tr>';
                                                $content .= '</table>';
                                            $content .= '</td>';
                                            $content .= '<td class="col2">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['satAHHrsFtn'], 2) . 'hrs</td>';
                                            $content .= '<td class="col3">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['satAHCostFtn'], 2) . '</td>';
                                            $content .= '<td class="col4">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['satAHHrsMonth'], 2) . 'hrs</td>';
                                            $content .= '<td class="col5">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['satAHCostMonth'], 2) . '</td>';
                                        $content .= '</tr>';
                                    }
                                    // If sun hrs
                                    if($this->finalEstimate['categoryList'][$i]['services'][$j]['sunHrsFtn'] > 0) {
                                        $content .= '<tr>';
                                            $content .= '<td class="col1">';
                                                $content .= '<table class="indent-table">';
                                                    $content .= '<tr><td class="indent">Sunday hours</td></tr>';
                                                    $content .= '<tr><td class="indent">' . $this->finalEstimate['categoryList'][$i]['services'][$j]['sunVisits'] . '</td></tr>';
                                                $content .= '</table>';
                                            $content .= '</td>';
                                            $content .= '<td class="col2">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['sunHrsFtn'], 2) . 'hrs</td>';
                                            $content .= '<td class="col3">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['sunCostFtn'], 2) . '</td>';
                                            $content .= '<td class="col4">' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['sunHrsMonth'], 2) . 'hrs</td>';
                                            $content .= '<td class="col5">$' . number_format($this->finalEstimate['categoryList'][$i]['services'][$j]['sunCostMonth'], 2) . '</td>';
                                        $content .= '</tr>';
                                    }
                                }
                            }
                        }

                        if($funded) {
                            // Planning and management
                            $content .= '<tr>';
                                $content .= '<th class="col1h table-heading">Planning and management</th>';
                                $content .= '<th class="col2h table-heading" colspan="2"></th>';
                                $content .= '<th class="col3h table-heading" colspan="2"></th>';
                            $content .= '</tr>';
                            // Package management
                            $content .= '<tr>';
                                $content .= '<td class="col1">Package management</td>';
                                $content .= '<td class="col2"></td>';
                                $content .= '<td class="col3">$' . number_format($this->finalEstimate['packageManagementFtn'], 2) . '</td>';
                                $content .= '<td class="col4"></td>';
                                $content .= '<td class="col5">$' . number_format($this->finalEstimate['packageManagementMonth'], 2) . '</td>';
                            $content .= '</tr>';
                            // Care management
                            $content .= '<tr>';
                                $content .= '<td class="col1">Care management</td>';
                                $content .= '<td class="col2"></td>';
                                $content .= '<td class="col3">$' . number_format($this->finalEstimate['careManagementFtn'], 2) . '</td>';
                                $content .= '<td class="col4"></td>';
                                $content .= '<td class="col5">$' . number_format($this->finalEstimate['careManagementMonth'], 2) . '</td>';
                            $content .= '</tr>';
                        }
                        
                        $content .= '<tr>';
                            $content .= '<th class="col1 total">Total for all services</th>';
                            $content .= '<th class="col2 total">' . number_format($this->finalEstimate['totalHrsFtn'], 2) . 'hrs</th>';
                            $content .= '<th class="col3 total">$' . number_format($this->finalEstimate['totalCostFtn'], 2) . '</th>';
                            $content .= '<th class="col4 total">' . number_format($this->finalEstimate['totalHrsMonth'], 2) . 'hrs</th>';
                            $content .= '<th class="col5 total">$' . number_format($this->finalEstimate['totalCostMonth'], 2) . '</th>';
                        $content .= '</tr>';

                    }
                $content .= '</tbody>';

            $content .= '</table>';

            $content .= "<br /><br />";
            $content .= "<p>If you need help to understand this document please don't hesitate to contact our friendly team on 1300 000 161.</p>";
            $content .= "<p>We will review and, if necessary, revise this budget if:</p>";
            $content .= "<ol type=\"a\">";
                $content .= "<li>a change to the care and services to be provided is proposed; or</li>";
                $content .= "<li>the costs of providing the care and services change; or</li>";
                $content .= "<li>you request a revision</li>";
            $content .= "</ol>";
            $content .= "<p>You will be provided with a revised copy of the budget if any changes are made.</p>";
            if($funded) {
                $content .= "<p><strong>Care Fees</strong></p>";
                $content .= "<p>The My Aged Care Fee Estimator may have been utilised to provide you with an estimate of fees (basic daily fee & income tested fee) for your Home Care Package. This estimate is based on the information you provided and should be utilised as a guide for your general information only.</p>";
                $content .= "<p>The actual amount of fees payable will depend on your personal situation, the time you enter care, the information you provide to the relevant Australian Government Departments and your personal and financial information at the time of the assessment.</p>";
                $content .= "<p>You should consider obtaining independent legal, financial, taxation or other advice to check how the My Aged Care website information relates to your particular circumstances.</p>";
            }
            
        $content .= '</div>';

        $this->pdf->WriteHTML($headerFooter);
        $this->pdf->WriteHTML($content);

        return;
    }

}
