<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Log;

class PDFDownloadController extends Controller
{
    public function checkUser(Request $request)
    {
        
        if(Auth::check()) {
            $fullUrl = '../storage/app/public/pdf/' . $request->filename;
            return response()->download($fullUrl);
        } else {
            return 'You do not have permission to access this file.';
        }

    }
}
