<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChangeLog extends Model
{
    
    /**
     * Set the table name because for some reason it thinks it's change_logs
     */
    protected $table = 'changelog';

}
