<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Saml2MessageId extends Model
{
    protected $table = 'saml2_message_id';
}
